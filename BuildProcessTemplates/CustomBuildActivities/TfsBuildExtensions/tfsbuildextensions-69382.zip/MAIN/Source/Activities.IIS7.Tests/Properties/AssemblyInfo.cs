﻿//-----------------------------------------------------------------------
// <copyright file="AssemblyInfo.cs">(c) http://TfsBuildExtensions.codeplex.com/. This source is subject to the Microsoft Permissive License. See http://www.microsoft.com/resources/sharedsource/licensingbasics/sharedsourcelicenses.mspx. All other rights reserved.</copyright>
//-----------------------------------------------------------------------
using System;
using System.Reflection;

[assembly: AssemblyTitle("Community TFS Build Extensions IIS7 Tests")]
[assembly: AssemblyDescription("Community TFS Build Extensions IIS7 Tests")]
[assembly: CLSCompliant(true)]
