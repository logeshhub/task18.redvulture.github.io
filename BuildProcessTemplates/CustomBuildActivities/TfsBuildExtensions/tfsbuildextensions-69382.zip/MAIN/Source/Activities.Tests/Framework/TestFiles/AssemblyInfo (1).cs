﻿//-----------------------------------------------------------------------
// <copyright file="AssemblyInfo (1).cs">(c) http://TfsBuildExtensions.codeplex.com/. This source is subject to the Microsoft Permissive License. See http://www.microsoft.com/resources/sharedsource/licensingbasics/sharedsourcelicenses.mspx. All other rights reserved.</copyright>
//-----------------------------------------------------------------------

using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyCompany("AssemblyCompanyValue")]
[assembly: AssemblyConfiguration("AssemblyConfigurationValue")]
[assembly: AssemblyCopyright("AssemblyCopyrightValue")]
[assembly: AssemblyCulture("AssemblyCultureValue")]
[assembly: AssemblyDescription("AssemblyDescriptionValue")]
[assembly: AssemblyProduct("AssemblyProductValue")]
[assembly: AssemblyTitle("AssemblyTitleValue")]
[assembly: AssemblyTrademark("AssemblyTrademarkValue")]

// line comment
// [assembly: AssemblyDefaultAlias("AssemblyDefaultAlias")]
[assembly: AssemblyDelaySign(true)]
[assembly: AssemblyKeyFile("AssemblyKeyFileValue")]
[assembly: AssemblyKeyName("AssemblyKeyNameValue")]

[assembly: AssemblyVersion("1.2.0.0")]
[assembly: AssemblyFileVersion("1.2.3.4")]
[assembly: AssemblyInformationalVersion("AssemblyInformationalVersionValue")]

/* block comment
 * [assembly: AssemblyFlags(AssemblyNameFlags.None)]
 */
[assembly: CLSCompliant(true)]
[assembly: Guid("B0EAC358-5AB5-45DE-9975-E1D8D8030944")]
[assembly: ComVisible(true)]
