﻿Imports System
Imports System.Reflection
Imports System.Runtime.CompilerServices
Imports System.Runtime.InteropServices

<Assembly: AssemblyCompany("AssemblyCompanyValue")> 
<Assembly: AssemblyConfiguration("AssemblyConfigurationValue")> 
<Assembly: AssemblyCopyright("AssemblyCopyrightValue")> 
<Assembly: AssemblyCulture("AssemblyCultureValue")> 
<Assembly: AssemblyDescription("AssemblyDescriptionValue")> 
<Assembly: AssemblyProduct("AssemblyProductValue")> 
<Assembly: AssemblyTitle("AssemblyTitleValue")> 
<Assembly: AssemblyTrademark("AssemblyTrademarkValue")> 

' line comment
'<assembly: AssemblyDefaultAlias("AssemblyDefaultAlias")>

<Assembly: AssemblyDelaySign(True)> 
<Assembly: AssemblyKeyFile("AssemblyKeyFileValue")> 
<Assembly: AssemblyKeyName("AssemblyKeyNameValue")> 

<Assembly: AssemblyVersion("1.2.0.0")> 
<Assembly: AssemblyFileVersion("1.2.3.4")> 
<Assembly: AssemblyInformationalVersion("AssemblyInformationalVersionValue")> 

<Assembly: CLSCompliant(True)> 

<Assembly: Guid("B0EAC358-5AB5-45DE-9975-E1D8D8030944")> 
<Assembly: ComVisible(True)> 
