﻿//-----------------------------------------------------------------------
// <copyright file="AssemblyInfo.cs">(c) http://TfsBuildExtensions.codeplex.com/. This source is subject to the Microsoft Permissive License. See http://www.microsoft.com/resources/sharedsource/licensingbasics/sharedsourcelicenses.mspx. All other rights reserved.</copyright>
//-----------------------------------------------------------------------
using System;
using System.Reflection;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Community TFS Build Extensions Tests for VirtualPC")]
[assembly: AssemblyDescription("Community TFS Build Extensions Tests for VirtualPC")]
[assembly: CLSCompliant(false)]