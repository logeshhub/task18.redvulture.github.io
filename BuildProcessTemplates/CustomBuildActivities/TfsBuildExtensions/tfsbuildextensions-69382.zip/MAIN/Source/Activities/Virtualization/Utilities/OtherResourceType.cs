//-----------------------------------------------------------------------
// <copyright file="OtherResourceType.cs">(c) http://TfsBuildExtensions.codeplex.com/. This source is subject to the Microsoft Permissive License. See http://www.microsoft.com/resources/sharedsource/licensingbasics/sharedsourcelicenses.mspx. All other rights reserved.</copyright>
//-----------------------------------------------------------------------
namespace TfsBuildExtensions.Activities.Virtualization.Utilities
{
    internal static class OtherResourceType
    {
        public const string DisketteController = "Microsoft Virtual Diskette Controller";
    }
}
