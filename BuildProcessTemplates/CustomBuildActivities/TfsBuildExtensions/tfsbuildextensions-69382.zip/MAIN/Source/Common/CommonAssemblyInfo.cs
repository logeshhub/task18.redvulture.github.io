﻿//-----------------------------------------------------------------------
// <copyright file="CommonAssemblyInfo.cs">(c) http://TfsBuildExtensions.codeplex.com/. This source is subject to the Microsoft Permissive License. See http://www.microsoft.com/resources/sharedsource/licensingbasics/sharedsourcelicenses.mspx. All other rights reserved.</copyright>
//-----------------------------------------------------------------------
using System.Reflection;
using System.Resources;
using System.Runtime.InteropServices;

[assembly: AssemblyVersion("1.1.0.0")]
[assembly: AssemblyFileVersion("1.1.0.0")]
[assembly: AssemblyInformationalVersion("1.1.0.0")]
[assembly: AssemblyCompany("Community TFS Build Extensions http://TfsBuildExtensions.codeplex.com/")]
[assembly: AssemblyCopyright("Copyright ©s Community TFS Build Extensions http://TfsBuildExtensions.codeplex.com/")]
[assembly: AssemblyTrademark("Community TFS Build Extensions http://TfsBuildExtensions.codeplex.com/")]
[assembly: NeutralResourcesLanguage("en-US")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyProduct("Community TFS Build Extensions")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]