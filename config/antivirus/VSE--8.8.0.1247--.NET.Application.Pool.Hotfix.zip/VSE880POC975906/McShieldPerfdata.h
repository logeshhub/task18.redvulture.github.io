#define NTGUARD_OBJECT                   0
#define SCAN_REQUESTS                    2
#define FILES_SCANNED                    4
#define INFECTIONS_FOUND                 6
#define HEURISTIC_INFECTIONS_FOUND       8
#define DISINFECTIONS_ATTEMPTED         10
#define DISINFECTIONS_SUCCEEDED         12
#define DELETES_SUCCEEDED               14
#define MOVES_SUCCEEDED                 16
#define THREADS_ACTIVE                  18
#define TAGGED_FILES                    20
#define MAXTAGGED_FILES                 22
#define TAGGED_HANDLES                  24
#define MAXTAGGED_HANDLES               26
#define SIDCOUNT                        28
#define MAXSIDCOUNT                     30

                       