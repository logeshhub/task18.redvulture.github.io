Components.utils.import("resource://gre/modules/ctypes.jsm")

var lib = ctypes.open("scriptff.dll"); 

var SSInitialize = lib.declare("SSInitialize",ctypes.winapi_abi,ctypes.void_t);
var SSUnInitialize = lib.declare("SSUnInitialize",ctypes.winapi_abi,ctypes.void_t);

window.addEventListener("load", startScriptFF, false);
window.addEventListener("unload", cleanup, false);

function startScriptFF()
{
    try{
	SSInitialize();
    }catch(e){
	    alert(e.message);
    }
}

function cleanup() 
{
    try{
	SSUnInitialize();
    }catch(e){
	    alert(e.message);
    }
}