# Code-Search
Code Search Admin scripts (SQL and PS) for managing a Code Search on-prem instance

## Troubleshooting

To find help on troubleshooting TFS follow this [link](https://www.visualstudio.com/en-us/docs/search/administration#trouble-tfs).