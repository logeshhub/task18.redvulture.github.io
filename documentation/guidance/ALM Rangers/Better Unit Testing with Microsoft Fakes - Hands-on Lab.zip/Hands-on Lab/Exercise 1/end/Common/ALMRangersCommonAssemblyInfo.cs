﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright company="Microsoft Corporation" file="ALMRangersCommonAssemblyInfo.cs">
//   Copyright Microsoft Corporation. All Rights Reserved. This code released under the terms of the Microsoft Public License (MS-PL, http://opensource.org/licenses/ms-pl.html.) This is sample code only, do not use in production environments.
// </copyright>
// <summary>
//   The ALMRangersCommonAssemblyInfo
// </summary>
// --------------------------------------------------------------------------------------------------------------------
using System.Reflection;

[assembly: AssemblyCompany("Microsoft Corporation")]
[assembly: AssemblyCopyright("Copyright ©  Microsoft Corporation")]
[assembly: AssemblyTrademark("Microsoft Visual Studio ALM Rangers")]