﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright company="Microsoft Corporation" file="AssemblyInfo.cs">
//   Copyright Microsoft Corporation. All Rights Reserved. This code released under the terms of the Microsoft Public License (MS-PL, http://opensource.org/licenses/ms-pl.html.) This is sample code only, do not use in production environments.
// </copyright>
// <summary>
//   The AssemblyInfo
// </summary>
// --------------------------------------------------------------------------------------------------------------------

using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Microsoft ALM Rangers Fakes MainWeb Tests")]

[assembly: AssemblyDescription("Microsoft ALM Rangers Fakes MainWeb Tests")]

[assembly: AssemblyProduct("Microsoft ALM Rangers Fakes MainWeb")]

[assembly: Guid("38888697-f6c1-48af-ab17-ccb6f760714f")]
