﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright company="Microsoft Corporation" file="AssemblyInfo.cs">
//   Copyright Microsoft Corporation. All Rights Reserved. This code released under the terms of the Microsoft Public License (MS-PL, http://opensource.org/licenses/ms-pl.html.) This is sample code only, do not use in production environments.
// </copyright>
// <summary>
//   The AssemblyInfo
// </summary>
// --------------------------------------------------------------------------------------------------------------------

using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Microsoft ALM Rangers Fakes MainWeb")]

[assembly: AssemblyDescription("Microsoft ALM Rangers Fakes MainWeb")]

[assembly: AssemblyProduct("Microsoft ALM Rangers Fakes MainWeb")]

[assembly: Guid("f918c5f2-4ed0-43f0-86c3-acb90e222e1d")]

[assembly: ComVisible(false)]
