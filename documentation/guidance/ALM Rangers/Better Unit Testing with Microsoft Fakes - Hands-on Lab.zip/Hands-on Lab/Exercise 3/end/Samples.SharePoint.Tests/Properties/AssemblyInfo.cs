﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright company="Microsoft Corporation" file="AssemblyInfo.cs">
//   Copyright Microsoft Corporation. All Rights Reserved. This code released under the terms of the Microsoft Public License (MS-PL, http://opensource.org/licenses/ms-pl.html.) This is sample code only, do not use in production environments.
// </copyright>
// <summary>
//   The AssemblyInfo
// </summary>
// --------------------------------------------------------------------------------------------------------------------
using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Microsoft ALM Rangers Fakes Guide Sharepoint Sample Tests")]
[assembly: AssemblyDescription("Microsoft ALM Rangers Fakes Guide Sharepoint Sample Tests")]
[assembly: AssemblyProduct("Microsoft ALM Rangers Fakes Guide")]
[assembly: Guid("5cb306cf-21a0-4e0a-818c-609743819928")]
