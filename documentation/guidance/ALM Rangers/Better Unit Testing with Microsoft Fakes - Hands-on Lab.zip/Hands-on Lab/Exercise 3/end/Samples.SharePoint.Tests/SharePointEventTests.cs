﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright company="Microsoft Corporation" file="SharePointEventTests.cs">
//   Copyright Microsoft Corporation. All Rights Reserved. This code released under the terms of the Microsoft Public License (MS-PL, http://opensource.org/licenses/ms-pl.html.) This is sample code only, do not use in production environments.
// </copyright>
// <summary>
//   The SharePointEventTests
// </summary>
// --------------------------------------------------------------------------------------------------------------------
namespace Microsoft.ALMRangers.FakesGuide.Sharepoint.Tests
{
    using System;
    using Microsoft.QualityTools.Testing.Fakes;
    using Microsoft.SharePoint.Fakes;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    
    [TestClass]
    public class SharePointEventTests
    {
        [TestMethod]
        public void The_item_title_is_set_to_the_content_type_when_event_fires()
        {
            using (ShimsContext.Create())
            {
                // arrange
                // create the local variables we will write into to check that the correct methods are called
                var systemUpdateHasBeenCalled = false;
                var itemTitleValue = string.Empty;

                // create the fake properties
                var fakeProperties = new ShimSPItemEventProperties()
                {
                    WebUrlGet = () => "http://fake.url",
                    ListIdGet = () => Guid.NewGuid(),
                    ListItemIdGet = () => 1234
                };

                // create the fake site 
                ShimSPSite.ConstructorString = (@this, @string) =>
                {
                    new ShimSPSite(@this)
                    {
                        OpenWeb = () => new ShimSPWeb()
                        {
                            ListsGet = () => new ShimSPListCollection()
                            {
                                ItemGetGuid = (guid) => new ShimSPList()
                                {
                                    GetItemByIdInt32 = (id) => new ShimSPListItem() 
                                    {
                                        ItemGetString = (name) => string.Format("Field is {0}", name),
                                        SystemUpdateBoolean = (update) => systemUpdateHasBeenCalled = true,
                                        ItemSetStringObject = (name, value) => itemTitleValue = value.ToString()
                                    }
                                }
                            }
                        }
                    };
                };

                // create the instance of the class under test
                var cut = new ContentTypeItemEventReceiver();

                // act
                cut.ItemAdded(fakeProperties);

                // assert
                Assert.AreEqual(true, systemUpdateHasBeenCalled);
                Assert.AreEqual("Field is ContentType", itemTitleValue);
            }
        }
    }
}
