﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright company="Microsoft Corporation" file="ContentTypeItemEventReceiver.cs">
//   Copyright Microsoft Corporation. All Rights Reserved. This code released under the terms of the Microsoft Public License (MS-PL, http://opensource.org/licenses/ms-pl.html.) This is sample code only, do not use in production environments.
// </copyright>
// <summary>
//   The ContentTypeItemEventReceiver
// </summary>
// --------------------------------------------------------------------------------------------------------------------
namespace Microsoft.ALMRangers.FakesGuide.Sharepoint
{
    using Microsoft.SharePoint;

    public class ContentTypeItemEventReceiver : SPItemEventReceiver
    {
        public void UpdateTitle(SPItemEventProperties properties)
        {
            using (SPWeb web = new SPSite(properties.WebUrl).OpenWeb())
            {
                SPList list = web.Lists[properties.ListId];
                SPListItem item = list.GetItemById(properties.ListItemId);
                item["Title"] = item["ContentType"];
                item.SystemUpdate(false);
            }
        }

        public override void ItemAdded(SPItemEventProperties properties)
        {
            this.EventFiringEnabled = false;
            this.UpdateTitle(properties);
            this.EventFiringEnabled = true;
        }
    }
}
