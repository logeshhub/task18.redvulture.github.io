﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright company="Microsoft Corporation" file="AssemblyInfo.cs">
//   Copyright Microsoft Corporation. All Rights Reserved. This code released under the terms of the Microsoft Public License (MS-PL, http://opensource.org/licenses/ms-pl.html.) This is sample code only, do not use in production environments.
// </copyright>
// <summary>
//   The AssemblyInfo
// </summary>
// --------------------------------------------------------------------------------------------------------------------
using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Microsoft ALM Rangers Fakes Guide Sharepoint Sample")]
[assembly: AssemblyDescription("Microsoft ALM Rangers Fakes Guide Sharepoint Sample")]
[assembly: AssemblyProduct("Microsoft ALM Rangers Fakes Guide")]

[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("343a2ff7-4719-46a1-a3d5-fd758a6baa74")]
