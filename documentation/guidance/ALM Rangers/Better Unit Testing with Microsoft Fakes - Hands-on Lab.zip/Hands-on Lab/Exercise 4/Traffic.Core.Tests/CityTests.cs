﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright company="Microsoft Corporation" file="CityTests.cs">
//   Copyright Microsoft Corporation. All Rights Reserved. This code released under the terms of the Microsoft Public License (MS-PL, http://opensource.org/licenses/ms-pl.html.) This is sample code only, do not use in production environments.
// </copyright>
// <summary>
//   Contains unit tests for the City class.
// </summary>
// --------------------------------------------------------------------------------------------------------------------
namespace Microsoft.ALMRangers.FakesGuide.ComplexDependencies.Traffic.Core.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading;
    using System.Threading.Fakes;
    using Microsoft.ALMRangers.FakesGuide.ComplexDependencies.Traffic.Core.Models;
    using Microsoft.ALMRangers.FakesGuide.ComplexDependencies.Traffic.Core.RoadworkServiceReference.Fakes;
    using Microsoft.QualityTools.Testing.Fakes;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class CityTests
    {
        /// <summary>
        /// Test to ensure that the City Run property can be set to true.
        /// </summary>
        [TestMethod, Ignore]
        public void City_CanSetRunProperty_True()
        {
            using (ShimsContext.Create())
            {
                City cityUnderTest = new City();
                const bool Expected = true;
                bool hasServiceBeenInvoked = false;
                ShimRoadworkServiceClient.Constructor = x => { };
                ShimRoadworkServiceClient.AllInstances.RetrieveCurrentBlockArray = (instance, blocks) =>
                    {
                        hasServiceBeenInvoked = true;
                        return new List<StubImpediment>
                        {
                            new StubImpediment
                            {
                                description = string.Empty,
                                location = blocks.FirstOrDefault(),
                                relativeSpeed = double.MinValue
                            }
                        }.ToArray();
                    };

                cityUnderTest.Run = Expected;
                Thread.Sleep(TimeSpan.FromSeconds(5));

                Assert.AreEqual(Expected, cityUnderTest.Run, "City.Run property should be set to true.");
                Assert.IsTrue(hasServiceBeenInvoked, "City.Run should invoke the Roadwork service.");
            }
        }

        /// <summary>
        /// Test to ensure that the City Run property can be set to true.
        /// </summary>
        [TestMethod]
        public void City_CanSetRunProperty_True_Modified()
        {
            using (ShimsContext.Create())
            {
                City cityUnderTest = new City();
                const bool Expected = true;
                bool hasTimerBeenInvoked = false;

                ShimTimer.ConstructorTimerCallbackObjectTimeSpanTimeSpan = (timer, callback, state, dueTime, period) =>
                    {
                        // Do nothing else but confirm that our implementation was called here.
                        hasTimerBeenInvoked = true;
                    };

                cityUnderTest.Run = Expected;

                Assert.AreEqual(Expected, cityUnderTest.Run, "City.Run property should be set to true.");
                Assert.IsTrue(hasTimerBeenInvoked, "City.Run should invoke instantiate a Timer instance.");
            }
        }
    }
}
