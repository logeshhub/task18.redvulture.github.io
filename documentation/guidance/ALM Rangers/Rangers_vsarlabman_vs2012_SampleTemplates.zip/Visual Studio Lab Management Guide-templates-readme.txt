This package contains lab build process templates for the ALM Rangers Visual Studio Lab Management Guide (http://vsarlabman.codeplex.com/).
