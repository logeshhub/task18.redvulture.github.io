Process Template Customization

	In order to use this control we have to add it to one or more work item types. 	
	
    <Control FieldName="ALMRangers.Bool" Name="CheckBox Type="Microsoft.ALMRangers.CheckBoxControl" Label="I'm a checkbox:" LabelPosition="Left"/>            
    <Control FieldName="ALMRangers.Bool2" Name="CheckBox2" Type="Microsoft.ALMRangers.CheckBoxControl" Label="I'm a checkbox (three state enabled)" LabelPosition="Left" ThreeState="true"/>            

	Don't forget to declare the fields

	
      <FIELD name="Bool Sample" refname="ALMRangers.Bool" type="Boolean">
        <HELPTEXT>bool used as a boolean variable for purposes of a checkbox</HELPTEXT>
      </FIELD>

Custom Control Installation

To install the control copy the .WICC and control assembly file to

	  %ProgramData%\Microsoft\Team Foundation\Work Item Tracking\Custom Controls\11.0




    

