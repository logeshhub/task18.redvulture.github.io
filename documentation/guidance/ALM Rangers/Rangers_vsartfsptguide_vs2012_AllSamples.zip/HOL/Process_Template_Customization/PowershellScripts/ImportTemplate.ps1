
# Copyright � Microsoft Corporation.  All Rights Reserved.

# This code released under the terms of the 

# Microsoft Public License (MS-PL, http://opensource.org/licenses/ms-pl.html.)

# This is sample code only, do not use in production environments



param(
    [parameter(Mandatory=$true, Position=1)]
	[string] $Folder = ".\..\",
    [parameter(Mandatory=$true, Position=2)]
	[psobject] $Server,
    [parameter(Mandatory=$false, Position=3)]
	[psobject] $Collection = "*",
    [parameter(Mandatory=$false, Position=4)]
	[psobject] $Project = "*"
)

begin
{
	Import-Module .\tfs.psm1
	# Path to witadmin.exe
	$witAdminCmd = "c:\Program Files (x86)\Microsoft Visual Studio 11.0\Common7\IDE\witadmin.exe"
	$processBasePath = [System.IO.Path]::GetFullPath($Folder)
	$workItemTrackingPath = [System.IO.Path]::Combine($processBasePath, "WorkItem Tracking")
	$typeDefinitionsPath = [System.IO.Path]::Combine($workItemTrackingPath, "TypeDefinitions")
	$linkTypesPath = [System.IO.Path]::Combine($workItemTrackingPath, "LinkTypes")	
	$processPath = [System.IO.Path]::Combine($workItemTrackingPath, "Process")

	
#	$workItemDefinitions = Get-ChildItem $typeDefinitionsPath\*.xml | % { Get-Content $_ | Out-String }
	# Logfile initializations
	# Logfile is created foreach date in the logs folder e.g. 20120131.log
#	$scriptPath = Get-Location -PSProvider FileSystem;
#	$logFilePath = "$scriptPath\logs";
#	$currentDate = Get-Date -format yyyyMMd
#	$logFile = "$logFilePath\$currentDate.log";

	# Start creating a log file
#	start-transcript -path $logFile -append

    # Command for importing CommonProcessConfig file from Process folder 
    function ImportCommonProcessConfig
    {
          Param([string]$TeamProjectName, [string]$CollectionUrl)
          # team project categories file 
          $filename = "CommonConfiguration.xml"

		  write-host "Uploading CommonProcessConfiguration file to $TeamProjectName";
		  $info = new-object System.Diagnostics.ProcessStartInfo;
		  $info.FileName = $witAdminCmd;
		  $info.Arguments = "importcommonprocessconfig /collection:""$CollectionUrl"" /f:""$processPath\$Filename"" /p:""$TeamProjectName""";
		  $info.UseShellExecute = $false;
		  $info.WorkingDirectory = Get-Location -PSProvider FileSystem;
		  $p = [diagnostics.process]::start($info);
		  $p.WaitForExit();
    }		

    # Command for importing AgileProcessConfig file from Process folder 
    function ImportAgileProcessConfig
    {
          Param([string]$TeamProjectName, [string]$CollectionUrl)
          # team project categories file 
          $filename = "AgileConfiguration.xml"

		  write-host "Uploading AgileProcessConfiguration file to $TeamProjectName";
		  $info = new-object System.Diagnostics.ProcessStartInfo;
		  $info.FileName = $witAdminCmd;
		  $info.Arguments = "importagileprocessconfig /collection:""$CollectionUrl"" /f:""$processPath\$Filename"" /p:""$TeamProjectName""";
		  $info.UseShellExecute = $false;
		  $info.WorkingDirectory = Get-Location -PSProvider FileSystem;
		  $p = [diagnostics.process]::start($info);
		  $p.WaitForExit();
    }
 
}            	
   
process
{

	foreach ($project in Get-Tfs $Server | Get-TfsCollection -Name $Collection | Get-TfsProject -Name $Project)
	{
	    # Importing WITD for the project
		Write-Host "Improting work item type defeinitions into project" $project.Name
		Get-ChildItem $typeDefinitionsPath\*.xml | % { Get-Content $_ | Out-String } | Import-TfsWorkItemTypeXml -Project $project
		
		Write-Host "Improting link types into project" $project.Name
		Get-ChildItem $linkTypesPath\*.xml | % { Get-Content $_ | Out-String } |% { $project.Collection.WIT.WorkItemLinkTypes.Import($_) }

		Write-Host "Improting categories into project" $project.Name
		Get-Content $workItemTrackingPath\Categories.xml | Out-String | % { $project.Collection.WIT.Projects[$project.Name].Categories.Import($_) }
		
		ImportCommonProcessConfig -CollectionUrl $project.Collection.Uri -TeamProjectName $project.Name
		ImportAgileProcessConfig -CollectionUrl $project.Collection.Uri -TeamProjectName $project.Name
	}
}





