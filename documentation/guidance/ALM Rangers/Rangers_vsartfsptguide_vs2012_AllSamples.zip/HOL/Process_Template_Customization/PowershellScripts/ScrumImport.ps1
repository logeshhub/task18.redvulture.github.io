# Copyright � Microsoft Corporation.  All Rights Reserved.
# This code released under the terms of the 
# Microsoft Public License (MS-PL, http://opensource.org/licenses/ms-pl.html.)
# This is sample code only, do not use in production environments

param(
    [string] $serverUrl = $(throw 'serverUrl is required. e.g. http://tfs2010:8080/tfs')
)

begin
{
 # Path to witadmin.exe
 # Use a different path if script is running on a 64bit os
 $supportedBits = Get-WmiObject -Class Win32_Processor | Select-Object AddressWidth
 if ($supportedBits -eq 32)
 {
    # script is running on a 32bit os
    $witAdminCmd = "c:\Program Files\Microsoft Visual Studio 11.0\Common7\IDE\witadmin.exe"
 }
 else
 {
    # script is running on a 64bit os
    $witAdminCmd = "c:\Program Files (x86)\Microsoft Visual Studio 11.0\Common7\IDE\witadmin.exe"
 }

 # Check if Team Explorer 2012 is installed
 if (!(Test-Path $witAdminCmd))
 {
	throw 'Team Explorer 2012 not installed.'
 }
  
 # Deployfolder
 $deployFolder = Get-Location -PSProvider FileSystem;
  
 # Syntax: WorkItemName, WorkItemFileName
 # WorkItemFileName = filename in folder process template folder TypeDefinitions
 $workItemTypeImports = (
	 # Dummy entry to force PowerShell to handle this object as an array
	 # Workaround is only for supporting one element imports
	('',''),
	('Test Case','TestCase.xml'),
	('Bug','Bug.xml'),
	('Code Review Request','CodeReviewRequest.xml'),
	('Code Review Response','CodeReviewResponse.xml'),
	('Feedback Request','FeedbackRequest.xml'),
	('Feedback Response','FeedbackResponse.xml'),
	('Impediment','Impediment.xml'),
	('Product Backlog Item','ProductBacklogItem.xml'),
	('Shared Step','SharedStep.xml'),
	('Task','Task.xml')
  )
    
 # Syntax: LinkTypeName, LinkTypeFileName
 # LinkTypeFileName = filename in folder process template folder WorkItemTracking
 # Comment: if you like to import just one element please add , before the item
 $linkTypeImports = (
	 # Dummy entry to force PowerShell to handle this object as an array
	 # Workaround is only for supporting one element imports
	('',''),
	('Shared Step','SharedStep.xml'),
	('Tested By','TestedBy.xml')
  )  
    
  # Command for importing Work Item Type from TypeDefinitions folder
  function ImportWorkItemTypeDefinition
	{
		  Param([string]$TeamProjectName, [string]$CollectionUrl,[string]$WIName, [string]$Filename)

		  write-host "Uploading $WIName Work Item Type to $TeamProjectName";
		  $info = new-object System.Diagnostics.ProcessStartInfo;
		  $info.FileName = $witAdminCmd;
		  $info.Arguments = "importwitd /collection:""$CollectionUrl"" /f:""..\WorkItem Tracking\TypeDefinitions\$Filename"" /p:""$TeamProjectName""";
		  $info.UseShellExecute = $false;
		  $info.WorkingDirectory = Get-Location -PSProvider FileSystem;
		  $p = [diagnostics.process]::start($info);
		  $p.WaitForExit();
	}
    # Command for importing categories file from WorkItemTracking folder
    function ImportCategories
    {
          Param([string]$TeamProjectName, [string]$CollectionUrl)
          # team project categories file 
          $filename = "categories.xml"

		  write-host "Uploading categories file to $TeamProjectName";
		  $info = new-object System.Diagnostics.ProcessStartInfo;
		  $info.FileName = $witAdminCmd;
		  $info.Arguments = "importcategories /collection:""$CollectionUrl"" /f:""..\WorkItem Tracking\$Filename"" /p:""$TeamProjectName""";
		  $info.UseShellExecute = $false;
		  $info.WorkingDirectory = Get-Location -PSProvider FileSystem;
		  $p = [diagnostics.process]::start($info);
		  $p.WaitForExit();
    }		
    
    # Command for importing Link Type from LinkType folder into Team Project Collection
    Function ImportLinkTypes
    {
          Param( [string]$CollectionUrl, [string]$LinkTypeName, [string]$Filename)
		  write-host "Uploading linktype $LinkTypeName to $TeamProjectName";
		  $info = new-object System.Diagnostics.ProcessStartInfo;
		  $info.FileName = $witAdminCmd;
		  $info.Arguments = "importlinktype /collection:""$CollectionUrl"" /f:""..\WorkItem Tracking\LinkTypes\$Filename""";
		  $info.UseShellExecute = $false;
		  $info.WorkingDirectory = Get-Location -PSProvider FileSystem;
		  $p = [diagnostics.process]::start($info);
		  $p.WaitForExit();
    }

   # Command for importing CommonProcessConfig file from Process folder 
   function ImportCommonProcessConfig
    {
          Param([string]$TeamProjectName, [string]$CollectionUrl)
          # team project categories file 
          $filename = "CommonConfiguration.xml"

		  write-host "Uploading CommonProcessConfiguration file to $TeamProjectName";
		  $info = new-object System.Diagnostics.ProcessStartInfo;
		  $info.FileName = $witAdminCmd;
		  $info.Arguments = "importcommonprocessconfig /collection:""$CollectionUrl"" /f:""..\WorkItem Tracking\Process\$Filename"" /p:""$TeamProjectName""";
		  $info.UseShellExecute = $false;
		  $info.WorkingDirectory = Get-Location -PSProvider FileSystem;
		  $p = [diagnostics.process]::start($info);
		  $p.WaitForExit();
    }		

   # Command for importing AgileProcessConfig file from Process folder 
   function ImportAgileProcessConfig
    {
          Param([string]$TeamProjectName, [string]$CollectionUrl)
          # team project categories file 
          $filename = "AgileConfiguration.xml"

		  write-host "Uploading AgileProcessConfiguration file to $TeamProjectName";
		  $info = new-object System.Diagnostics.ProcessStartInfo;
		  $info.FileName = $witAdminCmd;
		  $info.Arguments = "importagileprocessconfig /collection:""$CollectionUrl"" /f:""..\WorkItem Tracking\Process\$Filename"" /p:""$TeamProjectName""";
		  $info.UseShellExecute = $false;
		  $info.WorkingDirectory = Get-Location -PSProvider FileSystem;
		  $p = [diagnostics.process]::start($info);
		  $p.WaitForExit();
    }
 
    # Get an TFS team project collection instance   
    function Get-TfsCollection
    {
            [CmdletBinding()]
            param (
                [parameter(ParameterSetName="TfsCollectionUrl", Mandatory=$true, Position=0)]
                [alias("Server")]
                [alias("Url")]
                [string] $TfsCollectionUrl = $(throw 'TfsCollectionUrl is required')
                )
            begin
            {
                # load the required dll version independent
                [void][System.Reflection.Assembly]::LoadWithPartialName("Microsoft.TeamFoundation.Client")

                $propertiesToAdd = (
                    ('VCS', 'Microsoft.TeamFoundation.VersionControl.Client', 'Microsoft.TeamFoundation.VersionControl.Client.VersionControlServer'),
                    ('WIT', 'Microsoft.TeamFoundation.WorkItemTracking.Client', 'Microsoft.TeamFoundation.WorkItemTracking.Client.WorkItemStore'),
                    ('CSS', 'Microsoft.TeamFoundation', 'Microsoft.TeamFoundation.Server.ICommonStructureService'),
                    ('GSS', 'Microsoft.TeamFoundation', 'Microsoft.TeamFoundation.Server.IGroupSecurityService')
                )
            }

            process
            {
                # fetch the TFS instance, but add some useful properties to make life easier
                # Make sure to "promote" it to a psobject now to make later modification easier
                [psobject] $tfsCollection = [Microsoft.TeamFoundation.Client.TfsTeamProjectCollectionFactory]::GetTeamProjectCollection($TfsCollectionUrl)
                foreach ($entry in $propertiesToAdd) {
                    $scriptBlock = '
                        [System.Reflection.Assembly]::LoadWithPartialName("{0}") > $null
                        $this.GetService([{1}])
                    ' -f $entry[1],$entry[2]
                    $tfsCollection | add-member scriptproperty $entry[0] $ExecutionContext.InvokeCommand.NewScriptBlock($scriptBlock)
                }
                return $tfsCollection
            }
        }
        
        # Get an TFS server instance   
    function Get-TfsServer
    {
            [CmdletBinding()]
            param (
                [parameter(ParameterSetName="TfsServerUrl", Mandatory=$true, Position=0)]
                [alias("Server")]
                [alias("Url")]
                [string] $TfsServerUrl = $(throw 'TfsServerUrl is required')
                )
            begin
            {
                # load the required dll version independent
                [void][System.Reflection.Assembly]::LoadWithPartialName("Microsoft.TeamFoundation.Client")

                $propertiesToAdd = (
                    ('CSS', 'Microsoft.TeamFoundation', 'Microsoft.TeamFoundation.Server.ICommonStructureService'),
                    ('GSS', 'Microsoft.TeamFoundation', 'Microsoft.TeamFoundation.Server.IGroupSecurityService'),
                    ('TPCS', 'Microsoft.TeamFoundation.Client', 'Microsoft.TeamFoundation.Framework.Client.ITeamProjectCollectionService')
                )
            }

            process
            {
                # fetch the TFS instance, but add some useful properties to make life easier
                # Make sure to "promote" it to a psobject now to make later modification easier
               $tfsServerUri = $TfsServerUrl -as [System.URI]
               [psobject] $tfsConfigurationServer = [Microsoft.TeamFoundation.Client.TfsConfigurationServerFactory]::GetConfigurationServer($tfsServerUri)
                foreach ($entry in $propertiesToAdd) {
                    $scriptBlock = '
                        [System.Reflection.Assembly]::LoadWithPartialName("{0}") > $null
                        $this.GetService([{1}])
                    ' -f $entry[1],$entry[2]
                    $tfsConfigurationServer| add-member scriptproperty $entry[0] $ExecutionContext.InvokeCommand.NewScriptBlock($scriptBlock)
                }
                return $tfsConfigurationServer
            }
        }
}            	
   
process
{

# Logfile initializations
# Logfile is created foreach date in the logs folder e.g. 20120131.log
$scriptPath = Get-Location -PSProvider FileSystem;
$logFilePath = "$scriptPath\logs";
$currentDate = Get-Date -format yyyyMMd
$logFile = "$logFilePath\$currentDate.log";

# Check if logfolder exists or create a new one
if (!(Test-Path $logFilePath))
{
	write-host "Creating new log folder"
	new-item $logFilePath -type Directory
}


# Team Projects which must be ignored are listed in the ignoreprojects.csv 
$ignoreProjectFilename = "$scriptPath\ignoreprojects.csv";
$ignoreProjectsFile = import-csv $ignoreProjectFilename;

# Team Project Collections which must be ignored are listed in the ignorecollections.csv
$ignoreCollectionsFilename = "$scriptPath\ignorecollections.csv";
$ignoreCollectionsFile = import-csv $ignoreCollectionsFilename;

# Start creating a log file
start-transcript -path $logFile -append

# Get an instance of TFS server (not Team Project Collection)
 $tfs = get-TfsServer $serverUrl

# Check if ITeamProjectCollectionService service is available
if ($tfs.TPCS -ne $null)
	{ 
		# Go through all team project collections
		# http://msdn.microsoft.com/en-en/library/ff732762.aspx
		 $tfs.TPCS.GetCollections() | % {
         
			  # Get the Team Project Collection name
			  $collectionName = $_.Name

               # Check if Team Project name is listed on ignore file
              foreach ($collection in $ignoreCollectionsFile)
			  {
				$ignoreCollection = $false;
				$ignoreTeamProjectCollectionName = $collection.TeamProjectCollectionName;
				write-host $collection.Name
				
				if ($collectionName -eq $ignoreTeamProjectCollectionName)
				{
	
					$ignoreCollection = $true;
					break;
				}
			  }
              
               if ($ignoreCollection -eq $false)
					  {	
						  write-host "Processing Team Project Collection $collectionName";
						  
						  # Generate collection url
						  $virtualDirectory = $_.VirtualDirectory.SubString(1,$_.VirtualDirectory.Length -2);
						  $collectionUrl = $serverUrl + $virtualDirectory
						  
						  # Get an tpc instance 
						  $tpc = get-TfsCollection $collectionUrl
						  
						  # Get an instance of structure service
						  $css = $tpc.CSS;
						  
						  #Check if ICommonStructureService service is available
						  if ($css -ne $null)
						  {
							  # Go through all team projects of the collection
							  $css.ListAllProjects() | % {
								  # Get the Team Project name
								  $teamProjectName = $_.Name;
								  # Check if Team Project name is listed on ignore file
								  foreach ($project in $ignoreProjectsFile)
								  {

									$ignoreProject = $false;
									$ignoreTeamProjectName = $project.TeamProjectName;
									
									if ($teamProjectName -eq $ignoreTeamProjectName)
									{
						
										$ignoreProject = $true;
										break;
									}
								  }

								  if ($ignoreProject -eq $false)
								  {	 
									  write-host "Processing Team Project $teamProjectName";
									  # Import each Work Item Type from workItemTypeImports array (begin section)
									  foreach ($wi in $workItemTypeImports) {
										if (!([string]::IsNullOrEmpty($wi[1])))
										{																	  
											ImportWorkItemTypeDefinition $teamProjectName $collectionUrl $wi[0] $wi[1];             
									
										}  
									   }		
									  
										# Import each Link Type from linkTypeImports array (begin section)
										foreach ($linkType in $linkTypeImports) {

					  						if (!([string]::IsNullOrEmpty($linktype[1])))
												{
													ImportLinkTypes $collectionUrl $linkType[0] $linkType[1];             
												}
										}	

										# Importing categories
										ImportCategories $teamProjectName $collectionUrl;
										# Importing commonprocessconfig file
										ImportCommonProcessConfig $teamProjectName $collectionUrl;
										# Importing agileprocessconfig file
										ImportAgileProcessConfig $teamProjectName $collectionUrl;									  
								  }
								  else
								  {
									  write-host "Ignoring import for Team Project $ignoreTeamProjectName"
								  }
								}
							  }
							  else
							  {
								write-host "CommonStructure Service is not available."
							  }
						}	
				else
				  {
					  write-host "Ignoring import for Team Project Collection $ignoreTeamProjectCollectionName"
				  }
        }
	}
	else
	{
		write-host "TeamProjectCollection Service is not available."
	}
    
stop-transcript

# Fixing log output / Workaround for new-line issue
$content = Get-Content $logFile | ForEach-Object {$_.Split("`r`n")}
$fixedLogOutput = [string]::Join("`r`n",$content)
$fixedLogOutput > "$logFile"
}