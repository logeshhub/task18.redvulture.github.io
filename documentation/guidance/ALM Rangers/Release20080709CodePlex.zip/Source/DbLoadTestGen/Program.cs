//---------------------------------------------------------------------
// <copyright file="Program.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
//     THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
//     OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
//     LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//     FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>The main program.</summary>
//---------------------------------------------------------------------

namespace DatabaseLoadTestGenerator
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    using Microsoft.DatabaseLoadTest.Library;

    /// <summary>
    /// The main program.
    /// </summary>
    public static class Program
    {
        private static IList<string> rejectedDatabaseNames = new string[] { "master", "model", "msdb", "" };
        private static IList<string> rejectedQueries = new string[] { "exec sp_reset_connection" };
        
        /// <summary>
        /// Entry point.
        /// </summary>
        /// <param name="args">Command line parameters.</param>
        public static void Main(string[] args)
        {
            if (args.Length != 2 && args.Length != 3)
            {
                Console.WriteLine("Usage: dbloadtestgen ScenarioName TraceFileName [ConfigurationFileName]");
                Console.WriteLine("Example: dbloadtestgen LoginScenario login.trc myconfig.xml");
            }
            else
            {
                string scenarioName = args[0];
                string traceFile = args[1];
                string configFile = (args.Length == 3) ? args[2] : null;

                try
                {
                    TraceFileProcessor.ProcessingTraceRecord += delegate(object sender, TraceRecordFilterEventArgs trfea)
                    {
                        trfea.Process = !rejectedDatabaseNames.Contains(trfea.TraceRecord.DatabaseName) && !rejectedQueries.Contains(trfea.TraceRecord.TextData);
                        if (!trfea.Process)
                        {
                            Console.WriteLine("{0} [FILTERED OUT]", trfea.TraceRecord.TextData);
                        }
                    };

                    TraceFileProcessor.ParsingSql += delegate(object sender, SqlEventArgs sea)
                    {
                        Console.WriteLine("Processing: {0}", sea.Sql);
                    };

                    DbLoadTestConfiguration config = ConfigurationReader.Read(configFile);
                    TraceFileProcessor.ProcessTraceFile(scenarioName, traceFile, config);
                }
                catch (InvalidOperationException ioe)
                {
                    Console.WriteLine(ioe.Message);
                    Exception e = ioe.InnerException;
                    while (e != null)
                    {
                        Console.WriteLine(e.Message);
                        e = e.InnerException;
                    }

                    Environment.Exit(1);
                }
            }
        }
    }
}
