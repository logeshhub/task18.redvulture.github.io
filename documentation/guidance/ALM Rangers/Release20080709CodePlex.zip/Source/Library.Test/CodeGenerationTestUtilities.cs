//---------------------------------------------------------------------
// <copyright file="CodeGenerationTestUtilities.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
//     THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
//     OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
//     LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//     FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>The CodeGenerationTestUtilities type.</summary>
//---------------------------------------------------------------------

namespace Microsoft.DatabaseLoadTest.Library.Test
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Text;

    using Microsoft.VisualStudio.TestTools.UnitTesting;

    public static class CodeGenerationTestUtilities
    {
        public static void CompareCodeWithFile(string actualCodeFileName, string expectedCode)
        {
            string actualCode = File.ReadAllText(actualCodeFileName);
            CompareCode(actualCode, expectedCode);
        }

        public static void CompareCode(string actualCode, string expectedCode)
        {
            string strippedExpectedCode = StripHeaderComment(expectedCode);
            string strippedActualCode = StripHeaderComment(actualCode);

            StringBuilder actualCodeBuilder = new StringBuilder(strippedActualCode);
            if (strippedExpectedCode != strippedActualCode)
            {
                // Find the first difference and insert a marker
                int i;
                for (i = 0; i < Math.Min(strippedExpectedCode.Length, strippedActualCode.Length); i++)
                {
                    if (strippedExpectedCode[i] != strippedActualCode[i])
                    {
                        break;
                    }
                }

                actualCodeBuilder.Insert(i, "<HERE>");
            }

            Assert.AreEqual<string>(strippedExpectedCode, actualCodeBuilder.ToString());
        }

        private static string StripHeaderComment(string code)
        {
            string ans = code;
            int index;
            index = code.IndexOf("// </auto-generated>" + Environment.NewLine);
            if (index >= 0)
            {
                index = code.IndexOf(Environment.NewLine, index);
            }

            if (index >= 0)
            {
                ans = code.Substring(index);
            }

            return ans;
        }
    }
}
