﻿//---------------------------------------------------------------------
// <copyright file="ConfigurationTests.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
//     THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
//     OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
//     LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//     FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>The ConfigurationTests type.</summary>
//---------------------------------------------------------------------

namespace Microsoft.DatabaseLoadTest.Library.Test
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using System.IO;

    [TestClass]
    public class ConfigurationTests
    {
        private string configFileName;

        public ConfigurationTests()
        {
        }

        [TestInitialize]
        public void InitConfigFile()
        {
            this.configFileName = Path.GetTempFileName();
        }

        [TestCleanup]
        public void CleanupConfigFile()
        {
            File.Delete(this.configFileName);
        }

        [TestMethod]
        public void ConfigurationSimple()
        {
            this.CreateConfigFile(@"<?xml version='1.0' encoding='utf-8' ?>
<DbLoadTestConfiguration xmlns='http://microsoft.com/DbLoadTest' testMethodMode='ScenarioMethodOnly' operationTimerMode='IncludeOperationTimers'>
  <customCodeGenerator assembly='abc' type='def'/>
</DbLoadTestConfiguration>
");
            DbLoadTestConfiguration config = ConfigurationReader.Read(this.configFileName);

            Assert.IsNotNull(config);
            Assert.AreEqual<TestMethodMode>(TestMethodMode.ScenarioMethodOnly, config.testMethodMode);
            Assert.AreEqual<OperationTimerMode>(OperationTimerMode.IncludeOperationTimers, config.operationTimerMode);
            Assert.IsNotNull(config.customCodeGenerator);
            Assert.AreEqual<string>("abc", config.customCodeGenerator.assembly);
            Assert.AreEqual<string>("def", config.customCodeGenerator.type);
        }

        [TestMethod]
        public void ConfigurationNonDefaultTestMethodModeReturnedCorrectly()
        {
            this.CreateConfigFile(@"<?xml version='1.0' encoding='utf-8' ?>
<DbLoadTestConfiguration xmlns='http://microsoft.com/DbLoadTest' testMethodMode='IncludeIndividualOperations' operationTimerMode='IncludeOperationTimers'>
  <customCodeGenerator assembly='abc' type='def'/>
</DbLoadTestConfiguration>
");
            DbLoadTestConfiguration config = ConfigurationReader.Read(this.configFileName);

            Assert.AreEqual<TestMethodMode>(TestMethodMode.IncludeIndividualOperations, config.testMethodMode);
        }

        [TestMethod]
        public void ConfigurationNullFileNameReturnsDefaultConfiguration()
        {
            DbLoadTestConfiguration config = ConfigurationReader.Read(null);

            Assert.IsNotNull(config);
            Assert.AreEqual<TestMethodMode>(TestMethodMode.ScenarioMethodOnly, config.testMethodMode);
            Assert.AreEqual<OperationTimerMode>(OperationTimerMode.IncludeOperationTimers, config.operationTimerMode);
            Assert.IsNull(config.customCodeGenerator);
        }

        [TestMethod]
        public void ConfigurationEmptyFileNameReturnsDefaultConfiguration()
        {
            DbLoadTestConfiguration config = ConfigurationReader.Read(string.Empty);

            Assert.IsNotNull(config);
            Assert.AreEqual<TestMethodMode>(TestMethodMode.ScenarioMethodOnly, config.testMethodMode);
            Assert.AreEqual<OperationTimerMode>(OperationTimerMode.IncludeOperationTimers, config.operationTimerMode);
            Assert.IsNull(config.customCodeGenerator);
        }

        [TestMethod]
        public void ConfigurationNonDefaultTimerModeReturnedCorrectly()
        {
            this.CreateConfigFile(@"<?xml version='1.0' encoding='utf-8' ?>
<DbLoadTestConfiguration xmlns='http://microsoft.com/DbLoadTest' testMethodMode='ScenarioMethodOnly' operationTimerMode='NoOperationTimers'>
  <customCodeGenerator assembly='abc' type='def'/>
</DbLoadTestConfiguration>
");
            DbLoadTestConfiguration config = ConfigurationReader.Read(this.configFileName);

            Assert.AreEqual<OperationTimerMode>(OperationTimerMode.NoOperationTimers, config.operationTimerMode);
        }

        [TestMethod]
        public void ConfigurationNoCustomCodeGenerationElementReturnsNullForThatElement()
        {
            this.CreateConfigFile(@"<?xml version='1.0' encoding='utf-8' ?>
<DbLoadTestConfiguration xmlns='http://microsoft.com/DbLoadTest' testMethodMode='ScenarioMethodOnly' operationTimerMode='IncludeOperationTimers'>
</DbLoadTestConfiguration>
");
            DbLoadTestConfiguration config = ConfigurationReader.Read(this.configFileName);

            Assert.IsNotNull(config);
            Assert.IsNull(config.customCodeGenerator);
        }

        [TestMethod]
        public void ConfigurationMissingTestMethodModeDefaultsToScenarioMethodOnly()
        {
            this.CreateConfigFile(@"<?xml version='1.0' encoding='utf-8' ?>
<DbLoadTestConfiguration xmlns='http://microsoft.com/DbLoadTest' operationTimerMode='IncludeOperationTimers'>
</DbLoadTestConfiguration>
");
            DbLoadTestConfiguration config = ConfigurationReader.Read(this.configFileName);

            Assert.AreEqual<TestMethodMode>(TestMethodMode.ScenarioMethodOnly, config.testMethodMode);
        }

        [TestMethod]
        public void ConfigurationMissingTimerModeDefaultsToIncludeOperationTimers()
        {
            this.CreateConfigFile(@"<?xml version='1.0' encoding='utf-8' ?>
<DbLoadTestConfiguration xmlns='http://microsoft.com/DbLoadTest' testMethodMode='ScenarioMethodOnly'>
</DbLoadTestConfiguration>
");
            DbLoadTestConfiguration config = ConfigurationReader.Read(this.configFileName);

            Assert.AreEqual<OperationTimerMode>(OperationTimerMode.IncludeOperationTimers, config.operationTimerMode);
        }

        [TestMethod]
        public void ConfigurationMoreThanOneCustomCodeGenerationElementIsInvalid()
        {
            this.CreateConfigFile(@"<?xml version='1.0' encoding='utf-8' ?>
<DbLoadTestConfiguration xmlns='http://microsoft.com/DbLoadTest' testMethodMode='ScenarioMethodOnly' operationTimerMode='IncludeOperationTimers'>
  <customCodeGenerator assembly='abc' type='def'/>
  <customCodeGenerator assembly='abc' type='def'/>
</DbLoadTestConfiguration>
");
            TestHelper.TestForInvalidOperationException(delegate()
            {
                DbLoadTestConfiguration config = ConfigurationReader.Read(this.configFileName);
            });
        }

        [TestMethod]
        public void ConfigurationInvalidNamespace()
        {
            this.CreateConfigFile(@"<?xml version='1.0' encoding='utf-8' ?>
<DbLoadTestConfiguration xmlns='http://microsoft.com/DbLoadTestX' testMethodMode='ScenarioMethodOnly' operationTimerMode='IncludeOperationTimers'>
  <customCodeGenerator assembly='abc' type='def'/>
</DbLoadTestConfiguration>
");
            TestHelper.TestForInvalidOperationException(delegate()
            {
                DbLoadTestConfiguration config = ConfigurationReader.Read(this.configFileName);
            });
        }

        [TestMethod]
        public void ConfigurationBinaryFile()
        {
            TestHelper.TestForInvalidOperationException(delegate()
            {
                DbLoadTestConfiguration config = ConfigurationReader.Read("Microsoft.DatabaseLoadTest.Library.Test.dll");
            });
        }

        [TestMethod]
        public void ConfigurationFileNotFound()
        {
            TestHelper.TestForInvalidOperationException(delegate()
            {
                DbLoadTestConfiguration config = ConfigurationReader.Read("NoSuchFile.xml");
            });
        }

        private void CreateConfigFile(string xml)
        {
            StreamWriter sw = new StreamWriter(this.configFileName);
            sw.Write(xml);
            sw.Close();
        }
    }
}
