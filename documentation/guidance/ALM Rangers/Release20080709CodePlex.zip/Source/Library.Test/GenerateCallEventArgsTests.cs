﻿//---------------------------------------------------------------------
// <copyright file="GenerateCallEventArgsTests.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
//     THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
//     OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
//     LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//     FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>The GenerateCallEventArgsTests type.</summary>
//---------------------------------------------------------------------

namespace Microsoft.DatabaseLoadTest.Library.Test
{
    using System;
    using System.CodeDom;
    using System.Collections.Generic;
    using System.Text;

    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class GenerateCallEventArgsTests
    {
        private GenerateCallEventArgs args;

        [TestInitialize]
        public void InitializeTest()
        {
            ParsedSqlCommand cmd = TestHelper.ArbitraryParsedSqlCommand();
            CodeMemberMethod scenarioMethod = new CodeMemberMethod();
            CodeTypeDeclaration stubType = new CodeTypeDeclaration();

            this.args = new GenerateCallEventArgs(cmd, scenarioMethod, stubType);
        }

        [TestMethod]
        public void GenerateCallEventArgs_Constructor()
        {
            ParsedSqlCommand cmd = TestHelper.ArbitraryParsedSqlCommand();
            CodeMemberMethod scenarioMethod = new CodeMemberMethod();
            CodeTypeDeclaration stubType = new CodeTypeDeclaration();

            GenerateCallEventArgs localArgs = new GenerateCallEventArgs(cmd, scenarioMethod, stubType);

            Assert.AreSame(cmd, localArgs.Command);
            Assert.AreSame(scenarioMethod, localArgs.ScenarioMethod);
            Assert.AreSame(stubType, localArgs.StubType);
            Assert.IsFalse(localArgs.Handled);
        }

        [TestMethod]
        public void GenerateCallEventArgs_CanSetHandledOnce()
        {
            this.args.Handled = true;

            Assert.IsTrue(this.args.Handled);
        }

        [TestMethod]
        public void GenerateCallEventArgs_CanResetHandledIfNeverSet()
        {
            this.args.Handled = false;

            Assert.IsFalse(this.args.Handled);
        }

        [TestMethod]
        public void GenerateCallEventArgs_CannotSetHandledTwice()
        {
            this.args.Handled = true;

            TestHelper.TestForInvalidOperationException(delegate()
            {
                this.args.Handled = true;
            });
        }

        [TestMethod]
        public void GenerateCallEventArgs_CannotResetHandledOnceSet()
        {
            this.args.Handled = true;

            TestHelper.TestForInvalidOperationException(delegate()
            {
                this.args.Handled = false;
            });
        }
    }
}
