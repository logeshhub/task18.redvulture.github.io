//---------------------------------------------------------------------
// <copyright file="IntegrationTests.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
//     THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
//     OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
//     LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//     FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>The IntegrationTests type.</summary>
//---------------------------------------------------------------------

namespace Microsoft.DatabaseLoadTest.Library.Test
{
    using System;
    using System.Data;
    using System.IO;
    using System.Text;
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    using Microsoft.DatabaseLoadTest.Library;
    using System.Globalization;

    /// <summary>
    /// Performs an overall integration test.
    /// </summary>
    /// <remarks>
    /// <para>
    /// To cover all combinations there are two tests. One test uses a mock trace so that parsing is included. But this
    /// does not exercise all the possibilities that could be covered becuase right now the tool does not get stored
    /// procedure meta-data to help when parameters are NULL etc. So the second test generates parsed SQL commands that
    /// cover combinations not yet possible with parsing.
    /// </para>
    /// <para>
    /// The tests produce code that is included in the test project so that a second run of
    /// the unit tests will exercise the generated code.
    /// </para>
    /// </remarks>
    [TestClass]
    public class IntegrationTests : ICustomCodeGeneration
    {
        private static string sql = "SQL:BatchStarting";
        private static string rpc = "RPC:Starting";
        private static string database = "test";
        private static int spid = 1;

        /// <summary>
        /// Produces test code that exercises all combinations of default, null and actual value for all data types
        /// and all parameter directions, SQL, stored procedure etc. The tests are generated from parsed SQL commands.
        /// </summary>
        [TestMethod]
        public void INT_GenerateIntegrationTestFromParsed()
        {
            UnitTestGenerator utg = new UnitTestGenerator("INTG_GeneratedIntegrationTestFromParsed", "Microsoft.DatabaseLoadTest.Library.Test", "GeneratedIntegrationTestsFromParsed", TestMethodMode.ScenarioMethodOnly, OperationTimerMode.IncludeOperationTimers);

            GenerateTestsForTypeFromParsed(utg, "bigint", DbType.Int64, (Int64)1);
            GenerateTestsForTypeFromParsed(utg, "int",  DbType.Int32, (Int32)1);
            GenerateTestsForTypeFromParsed(utg, "smallint", DbType.Int16, (Int16)1);
            GenerateTestsForTypeFromParsed(utg, "tinyint", DbType.Byte, (Byte)1);
            GenerateTestsForTypeFromParsed(utg, "bit", DbType.Boolean, true);
            GenerateTestsForTypeFromParsed(utg, "decimal(10,2)", DbType.Decimal, 5.1m);
            GenerateTestsForTypeFromParsed(utg, "numeric(5,1)", DbType.Decimal, 5.2m);
            GenerateTestsForTypeFromParsed(utg, "money", DbType.Decimal, 5.3m);
            GenerateTestsForTypeFromParsed(utg, "smallmoney", DbType.Decimal, 5.4m);
            GenerateTestsForTypeFromParsed(utg, "float", DbType.Double, (double)6.5E15);
            GenerateTestsForTypeFromParsed(utg, "real", DbType.Single, (Single)6.1E10);
            GenerateTestsForTypeFromParsed(utg, "datetime", DbType.DateTime, new DateTime(2007, 6, 18, 12, 0, 0));
            GenerateTestsForTypeFromParsed(utg, "smalldatetime", DbType.DateTime, new DateTime(2007, 6, 18, 12, 0, 0));
            GenerateTestsForTypeFromParsed(utg, "char(10)", DbType.String, "abc");
            GenerateTestsForTypeFromParsed(utg, "nchar(10)", DbType.String, "abc");
            GenerateTestsForTypeFromParsed(utg, "varchar(10)", DbType.String, "abc");
            GenerateTestsForTypeFromParsed(utg, "nvarchar(10)", DbType.String, "abc");
            GenerateTestsForTypeFromParsed(utg, "text", DbType.String, "abc");
            GenerateTestsForTypeFromParsed(utg, "ntext", DbType.String, "abc");
            GenerateTestsForTypeFromParsed(utg, "binary", DbType.Binary, new byte[] { 0, 1, 2, 3 });
            GenerateTestsForTypeFromParsed(utg, "varbinary", DbType.Binary, new byte[] { 0, 1, 2, 3 });
            GenerateTestsForTypeFromParsed(utg, "image", DbType.Binary, new byte[] { 0, 1, 2, 3 });
            GenerateTestsForTypeFromParsed(utg, "timestamp", DbType.Binary, new byte[] { 0, 1, 2, 3 });
            GenerateTestsForTypeFromParsed(utg, "sql_variant", DbType.Object, 1);
            GenerateTestsForTypeFromParsed(utg, "uniqueidentifier", DbType.Guid, Guid.NewGuid());

            StreamWriter mainFile = new StreamWriter("GeneratedIntegrationTestFromParsed.cs");
            StreamWriter stubFile = new StreamWriter("GeneratedIntegrationTestFromParsed.stubs");
            utg.WriteCode(mainFile, stubFile);

            File.Copy("GeneratedIntegrationTestFromParsed.cs", "..\\..\\..\\Library.Test\\GeneratedIntegrationTestFromParsed.cs", true);
            File.Copy("GeneratedIntegrationTestFromParsed.stubs", "..\\..\\..\\Library.Test\\GeneratedIntegrationTestFromParsed.stubs", true);
        }

        [TestMethod]
        public void INT_GenerateIntegrationTestFromTrace()
        {
            MockTraceReader reader = new MockTraceReader();

            GenerateTestsForTypeFromTrace(reader, "bigint", DbType.Int64, "1");
            GenerateTestsForTypeFromTrace(reader, "int", DbType.Int32, "1");
            GenerateTestsForTypeFromTrace(reader, "smallint", DbType.Int16, "1");
            GenerateTestsForTypeFromTrace(reader, "tinyint", DbType.Byte, "1");
            GenerateTestsForTypeFromTrace(reader, "bit", DbType.Boolean, "1");
            GenerateTestsForTypeFromTrace(reader, "decimal(10,2)", DbType.Decimal, "5.1");
            GenerateTestsForTypeFromTrace(reader, "numeric(5,1)", DbType.Decimal, "5.2");
            GenerateTestsForTypeFromTrace(reader, "money", DbType.Decimal, "5.3");
            GenerateTestsForTypeFromTrace(reader, "smallmoney", DbType.Decimal, "5.4");
            GenerateTestsForTypeFromTrace(reader, "float", DbType.Double, "6.5E15");
            GenerateTestsForTypeFromTrace(reader, "real", DbType.Single, "6.1E10");
            GenerateTestsForTypeFromTrace(reader, "datetime", DbType.DateTime, "'JUN 6 2007 8:25:00:000AM'");
            GenerateTestsForTypeFromTrace(reader, "smalldatetime", DbType.DateTime, "'JUN 6 2007 8:25:00:000AM'");
            GenerateTestsForTypeFromTrace(reader, "char(10)", DbType.String, "'abc'");
            GenerateTestsForTypeFromTrace(reader, "nchar(10)", DbType.String, "'abc'");
            GenerateTestsForTypeFromTrace(reader, "varchar(10)", DbType.String, "'abc'");
            GenerateTestsForTypeFromTrace(reader, "nvarchar(10)", DbType.String, "'abc'");
            GenerateTestsForTypeFromTrace(reader, "text", DbType.String, "'abc'");
            GenerateTestsForTypeFromTrace(reader, "ntext", DbType.String, "'abc'");
            GenerateTestsForTypeFromTrace(reader, "binary", DbType.Binary, "0x000102030405");
            GenerateTestsForTypeFromTrace(reader, "varbinary", DbType.Binary, "0x000102030405");
            GenerateTestsForTypeFromTrace(reader, "image", DbType.Binary, "0x000102030405");
            GenerateTestsForTypeFromTrace(reader, "timestamp", DbType.Binary, "0x000102030405");
            GenerateTestsForTypeFromTrace(reader, "sql_variant", DbType.Object, "1");
            GenerateTestsForTypeFromTrace(reader, "uniqueidentifier", DbType.Guid, "'" + Guid.NewGuid().ToString() + "'");

            DbLoadTestConfiguration config = new DbLoadTestConfiguration();
            config.operationTimerMode = OperationTimerMode.IncludeOperationTimers;
            config.testMethodMode = TestMethodMode.ScenarioMethodOnly;
            config.customCodeGenerator = new typeType();
            config.customCodeGenerator.assembly = "Microsoft.DatabaseLoadTest.Library.Test";
            config.customCodeGenerator.type = this.GetType().FullName;
            TraceFileProcessor.ProcessTraceFile("INTG_GeneratedIntegrationTestFromTrace", reader, config);

            File.Copy("INTG_GeneratedIntegrationTestFromTrace.cs", "..\\..\\..\\Library.Test\\GeneratedIntegrationTestFromTrace.cs", true);
            File.Copy("INTG_GeneratedIntegrationTestFromTrace.stubs", "..\\..\\..\\Library.Test\\GeneratedIntegrationTestFromTrace.stubs", true);
        }

        #region ICustomCodeGeneration Members

        public bool GenerateCall(ParsedSqlCommand command, System.CodeDom.CodeMemberMethod scenarioMethod, System.CodeDom.CodeTypeDeclaration stubType)
        {
            if ((command.CommandText.Contains("binary")
                 ||
                 command.CommandText.Contains("image")
                 ||
                 command.CommandText.Contains("timestamp"))
                &&
                command.Parameters.Count == 1
                &&
                command.Parameters[0].Value == DBNull.Value)
            {
                ParsedSqlParameter old = command.Parameters[0];
                command.Parameters[0] = new ParsedSqlParameter(old.Name, DbType.Binary, old.Value, old.Direction);
            }

            return false;
        }

        #endregion
        #region General methods

        private static string GenerateSqlStatementComment(string sqlType, DbType dbType, ParameterDirection direction, object value)
        {
            string valueType;
            if (value == null)
            {
                valueType = "Default";
            }
            else if (value == DBNull.Value)
            {
                valueType = "Null";
            }
            else
            {
                valueType = "Value";
            }

            string comment = string.Format(CultureInfo.InvariantCulture, "-- Sql {0} {1} {2} {3}]", sqlType, dbType.ToString(), direction.ToString(), valueType);
            return comment;
        }

        private static string GenerateStoredProcedureName(string sqlType, DbType dbType, ParameterDirection direction, object value)
        {
            string valueType;
            if (value == null)
            {
                valueType = "Default";
            }
            else if (value == DBNull.Value)
            {
                valueType = "Null";
            }
            else
            {
                valueType = "Value";
            }

            string spName = string.Format(CultureInfo.InvariantCulture, "[p_Test_{0}_{1}_{2}_{3}]", sqlType, dbType.ToString(), direction.ToString(), valueType);
            return spName;
        }

        private static string GenerateStoredProcedureDropStatement(string spName)
        {
            return "IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'" + spName + "') AND type in (N'P', N'PC')) DROP PROCEDURE " + spName;
        }

        #endregion

        #region From Parsed

        private static void GenerateTestsForTypeFromParsed(UnitTestGenerator utg, string sqlType, DbType dbType, object value)
        {
            GenerateStoredProcedureInputParameterTestsFromParsed(utg, sqlType, dbType, value);
            GenerateStoredProcedureOutputParameterTestsFromParsed(utg, sqlType, dbType);
            GenerateStoredProcedureInputOutputParameterTestsFromParsed(utg, sqlType, dbType, value);
            GenerateSqlStatementInputParameterTestsFromParsed(utg, sqlType, dbType, value);
            GenerateSqlStatementOutputParameterTestsFromParsed(utg, sqlType, dbType);
            GenerateSqlStatementInputOutputParameterTestsFromParsed(utg, sqlType, dbType, value);
        }

        private static void GenerateStoredProcedureInputParameterTestsFromParsed(UnitTestGenerator utg, string sqlType, DbType dbType, object value)
        {
            GenerateStoredProcedureInputParameterTestFromParsed(utg, sqlType, dbType, null);
            GenerateStoredProcedureInputParameterTestFromParsed(utg, sqlType, dbType, DBNull.Value);
            GenerateStoredProcedureInputParameterTestFromParsed(utg, sqlType, dbType, value);
        }

        private static void GenerateStoredProcedureOutputParameterTestsFromParsed(UnitTestGenerator utg, string sqlType, DbType dbType)
        {
            ParameterDirection direction = ParameterDirection.Output;
            string spName = GenerateStoredProcedureNameAndCommentFromParsed(utg, sqlType, dbType, direction, null);
            GenerateStoredProcedureDropStatementFromParsed(utg, spName);
            utg.GenerateCall(new ParsedSqlCommand("CREATE PROCEDURE " + spName + " @p " + sqlType + " OUTPUT AS ", CommandType.Text, new List<ParsedSqlParameter>()));
            utg.GenerateCall(new ParsedSqlCommand(spName, CommandType.StoredProcedure, new List<ParsedSqlParameter>(new ParsedSqlParameter[] { new ParsedSqlParameter("@p", dbType, null, direction) })));
            GenerateStoredProcedureDropStatementFromParsed(utg, spName);
        }

        private static void GenerateStoredProcedureInputOutputParameterTestsFromParsed(UnitTestGenerator utg, string sqlType, DbType dbType, object value)
        {
            GenerateStoredProcedureInputOutputParameterTestFromParsed(utg, sqlType, dbType, null);
            GenerateStoredProcedureInputOutputParameterTestFromParsed(utg, sqlType, dbType, DBNull.Value);
            GenerateStoredProcedureInputOutputParameterTestFromParsed(utg, sqlType, dbType, value);
        }

        private static void GenerateStoredProcedureInputParameterTestFromParsed(UnitTestGenerator utg, string sqlType, DbType dbType, object value)
        {
            ParameterDirection direction = ParameterDirection.Input;
            string spName = GenerateStoredProcedureNameAndCommentFromParsed(utg, sqlType, dbType, direction, value);
            GenerateStoredProcedureDropStatementFromParsed(utg, spName);
            utg.GenerateCall(new ParsedSqlCommand("CREATE PROCEDURE " + spName + " @p " + sqlType + " = NULL AS ", CommandType.Text, new List<ParsedSqlParameter>()));
            utg.GenerateCall(new ParsedSqlCommand(spName, CommandType.StoredProcedure, new List<ParsedSqlParameter>(new ParsedSqlParameter[] { new ParsedSqlParameter("@p", dbType, value, direction) })));
            GenerateStoredProcedureDropStatementFromParsed(utg, spName);
        }

        private static void GenerateStoredProcedureInputOutputParameterTestFromParsed(UnitTestGenerator utg, string sqlType, DbType dbType, object value)
        {
            ParameterDirection direction = ParameterDirection.InputOutput;
            string spName = GenerateStoredProcedureNameAndCommentFromParsed(utg, sqlType, dbType, direction, value);
            GenerateStoredProcedureDropStatementFromParsed(utg, spName);
            utg.GenerateCall(new ParsedSqlCommand("CREATE PROCEDURE " + spName + " @p " + sqlType + " = NULL OUTPUT AS ", CommandType.Text, new List<ParsedSqlParameter>()));
            utg.GenerateCall(new ParsedSqlCommand(spName, CommandType.StoredProcedure, new List<ParsedSqlParameter>(new ParsedSqlParameter[] { new ParsedSqlParameter("@p", dbType, value, direction) })));
            GenerateStoredProcedureDropStatementFromParsed(utg, spName);
        }

        private static string GenerateStoredProcedureNameAndCommentFromParsed(UnitTestGenerator utg, string sqlType, DbType dbType, ParameterDirection direction, object value)
        {
            string spName = GenerateStoredProcedureName(sqlType, dbType, direction, value);
            utg.GenerateCall(new ParsedSqlCommand("-- " + spName, CommandType.Text, new List<ParsedSqlParameter>()));
            return spName;
        }

        private static void GenerateStoredProcedureDropStatementFromParsed(UnitTestGenerator utg, string spName)
        {
            utg.GenerateCall(new ParsedSqlCommand(GenerateStoredProcedureDropStatement(spName), CommandType.Text, new List<ParsedSqlParameter>()));
        }

        private static void GenerateSqlStatementInputParameterTestsFromParsed(UnitTestGenerator utg, string sqlType, DbType dbType, object value)
        {
            GenerateSqlStatementInputParameterTestFromParsed(utg, sqlType, dbType, DBNull.Value);
            GenerateSqlStatementInputParameterTestFromParsed(utg, sqlType, dbType, value);
        }

        private static void GenerateSqlStatementOutputParameterTestsFromParsed(UnitTestGenerator utg, string sqlType, DbType dbType)
        {
            ParameterDirection direction = ParameterDirection.Output;
            GenerateSqlStatementCommentFromParsed(utg, sqlType, dbType, direction, null);
            utg.GenerateCall(new ParsedSqlCommand("SELECT @p=NULL", CommandType.Text, new List<ParsedSqlParameter>(new ParsedSqlParameter[] { new ParsedSqlParameter("@p", dbType, null, direction) })));
        }

        private static void GenerateSqlStatementInputOutputParameterTestsFromParsed(UnitTestGenerator utg, string sqlType, DbType dbType, object value)
        {
            GenerateSqlStatementInputOutputParameterTestFromParsed(utg, sqlType, dbType, DBNull.Value);
            GenerateSqlStatementInputOutputParameterTestFromParsed(utg, sqlType, dbType, value);
        }

        private static void GenerateSqlStatementInputParameterTestFromParsed(UnitTestGenerator utg, string sqlType, DbType dbType, object value)
        {
            ParameterDirection direction = ParameterDirection.Input;
            GenerateSqlStatementCommentFromParsed(utg, sqlType, dbType, direction, value);
            utg.GenerateCall(new ParsedSqlCommand("PRINT @p", CommandType.Text, new List<ParsedSqlParameter>(new ParsedSqlParameter[] { new ParsedSqlParameter("@p", dbType, value, direction) })));
        }

        private static void GenerateSqlStatementInputOutputParameterTestFromParsed(UnitTestGenerator utg, string sqlType, DbType dbType, object value)
        {
            ParameterDirection direction = ParameterDirection.InputOutput;
            GenerateSqlStatementCommentFromParsed(utg, sqlType, dbType, direction, value);
            utg.GenerateCall(new ParsedSqlCommand("SELECT @p=NULL", CommandType.Text, new List<ParsedSqlParameter>(new ParsedSqlParameter[] { new ParsedSqlParameter("@p", dbType, value, direction) })));
        }

        private static void GenerateSqlStatementCommentFromParsed(UnitTestGenerator utg, string sqlType, DbType dbType, ParameterDirection direction, object value)
        {
            string comment = GenerateSqlStatementComment(sqlType, dbType, direction, value);
            utg.GenerateCall(new ParsedSqlCommand("-- " + comment, CommandType.Text, new List<ParsedSqlParameter>()));
        }

        #endregion

        #region From Trace

        private static void GenerateTestsForTypeFromTrace(MockTraceReader reader, string sqlType, DbType dbType, string value)
        {
            GenerateStoredProcedureInputParameterTestsFromTrace(reader, sqlType, dbType, value);
            GenerateStoredProcedureOutputParameterTestsFromTrace(reader, sqlType, dbType);
            GenerateStoredProcedureInputOutputParameterTestsFromTrace(reader, sqlType, dbType, value);
            GenerateSqlStatementInputParameterTestsFromTrace(reader, sqlType, dbType, value);
            GenerateSqlStatementOutputParameterTestsFromTrace(reader, sqlType, dbType, value);
            GenerateSqlStatementInputOutputParameterTestsFromTrace(reader, sqlType, dbType, value);
        }

        private static void GenerateStoredProcedureInputParameterTestsFromTrace(MockTraceReader reader, string sqlType, DbType dbType, string value)
        {
            GenerateStoredProcedureInputParameterTestFromTrace(reader, sqlType, dbType, null);
            GenerateStoredProcedureInputParameterTestFromTrace(reader, sqlType, dbType, DBNull.Value);
            GenerateStoredProcedureInputParameterTestFromTrace(reader, sqlType, dbType, value);
        }

        private static void GenerateStoredProcedureOutputParameterTestsFromTrace(MockTraceReader reader, string sqlType, DbType dbType)
        {
            string spName = GenerateStoredProcedureNameAndCommentFromTrace(reader, sqlType, dbType, ParameterDirection.Output, null);
            GenerateStoredProcedureDropStatementFromTrace(reader, spName);
            reader.TraceData.Rows.Add(sql, "CREATE PROCEDURE " + spName + " @p " + sqlType + " OUTPUT AS ", database, spid);
            string statement =
@"declare @p1 {1}
set @p1=NULL
exec {0} @p=@p1 output
select @p1
";
            string formattedStatement = string.Format(
                    CultureInfo.InvariantCulture,
                    statement,
                    spName,
                    sqlType);
            reader.TraceData.Rows.Add(
                rpc,
                formattedStatement,
                database,
                spid);
            GenerateStoredProcedureDropStatementFromTrace(reader, spName);
        }

        private static void GenerateStoredProcedureInputOutputParameterTestsFromTrace(MockTraceReader reader, string sqlType, DbType dbType, object value)
        {
            GenerateStoredProcedureInputOutputParameterTestFromTrace(reader, sqlType, dbType, null);
            GenerateStoredProcedureInputOutputParameterTestFromTrace(reader, sqlType, dbType, DBNull.Value);
            GenerateStoredProcedureInputOutputParameterTestFromTrace(reader, sqlType, dbType, value);
        }

        private static void GenerateStoredProcedureInputParameterTestFromTrace(MockTraceReader reader, string sqlType, DbType dbType, object value)
        {
            ParameterDirection direction = ParameterDirection.Input;
            string spName = GenerateStoredProcedureNameAndCommentFromTrace(reader, sqlType, dbType, direction, value);
            GenerateStoredProcedureDropStatementFromTrace(reader, spName);
            reader.TraceData.Rows.Add(sql, "CREATE PROCEDURE " + spName + " @p " + sqlType + " = NULL AS ", database, spid);
            string statement =
@"exec {0} @p={1}
";
            string formattedStatement = string.Format(
                    CultureInfo.InvariantCulture,
                    statement,
                    spName,
                    GenerateStringValue(value));
            reader.TraceData.Rows.Add(
                rpc,
                formattedStatement,
                database,
                spid);
            GenerateStoredProcedureDropStatementFromTrace(reader, spName);
        }

        private static void GenerateStoredProcedureInputOutputParameterTestFromTrace(MockTraceReader reader, string sqlType, DbType dbType, object value)
        {
            string spName = GenerateStoredProcedureNameAndCommentFromTrace(reader, sqlType, dbType, ParameterDirection.InputOutput, null);
            GenerateStoredProcedureDropStatementFromTrace(reader, spName);
            reader.TraceData.Rows.Add(sql, "CREATE PROCEDURE " + spName + " @p " + sqlType + " = NULL OUTPUT AS ", database, spid);
            string statement =
@"declare @p1 {1}
set @p1={2}
exec {0} @p=@p1 output
select @p1
";
            string formattedStatement = string.Format(
                    CultureInfo.InvariantCulture,
                    statement,
                    spName,
                    sqlType,
                    GenerateStringValue(value));
            reader.TraceData.Rows.Add(
                rpc,
                formattedStatement,
                database,
                spid);
            GenerateStoredProcedureDropStatementFromTrace(reader, spName);
        }

        private static string GenerateStoredProcedureNameAndCommentFromTrace(MockTraceReader reader, string sqlType, DbType dbType, ParameterDirection direction, object value)
        {
            string spName = GenerateStoredProcedureName(sqlType, dbType, direction, value);
            reader.TraceData.Rows.Add(sql, "-- " + spName, database, spid);
            return spName;
        }

        private static string GenerateStringValue(object value)
        {
            return GenerateStringValue(value, false);
        }

        private static string GenerateStringValue(object value, bool doubleUpQuotes)
        {
            string ans;
            if (value == null)
            {
                ans = "default";
            }
            else if (value == DBNull.Value)
            {
                ans = "NULL";
            }
            else
            {
                if (doubleUpQuotes)
                {
                    ans = value.ToString().Replace("'", "''");
                }
                else
                {
                    ans = value.ToString();
                }
            }

            return ans;
        }

        private static void GenerateStoredProcedureDropStatementFromTrace(MockTraceReader reader, string spName)
        {
            reader.TraceData.Rows.Add(sql, GenerateStoredProcedureDropStatement(spName), database, spid);
        }

        private static void GenerateSqlStatementInputParameterTestsFromTrace(MockTraceReader reader, string sqlType, DbType dbType, object value)
        {
            GenerateSqlStatementInputParameterTestFromTrace(reader, sqlType, dbType, DBNull.Value);
            GenerateSqlStatementInputParameterTestFromTrace(reader, sqlType, dbType, value);
        }

        private static void GenerateSqlStatementOutputParameterTestsFromTrace(MockTraceReader reader, string sqlType, DbType dbType, object value)
        {
            ParameterDirection direction = ParameterDirection.Output;
            GenerateSqlStatementCommentFromTrace(reader, sqlType, dbType, direction, null);
            string statement =
@"declare @p3 {0}
set @p3=NULL
exec sp_executesql N'SELECT @p={1}',N'@p {0} output',@p=@p3 output
select @p3
";
            string formattedStatement = string.Format(
                    CultureInfo.InvariantCulture,
                    statement,
                    sqlType,
                    GenerateStringValue(value, true));
            reader.TraceData.Rows.Add(
                rpc,
                formattedStatement,
                database,
                spid);
        }

        private static void GenerateSqlStatementInputOutputParameterTestsFromTrace(MockTraceReader reader, string sqlType, DbType dbType, object value)
        {
            GenerateSqlStatementInputOutputParameterTestFromTrace(reader, sqlType, dbType, DBNull.Value);
            GenerateSqlStatementInputOutputParameterTestFromTrace(reader, sqlType, dbType, value);
        }

        private static void GenerateSqlStatementInputParameterTestFromTrace(MockTraceReader reader, string sqlType, DbType dbType, object value)
        {
            ParameterDirection direction = ParameterDirection.Input;
            GenerateSqlStatementCommentFromTrace(reader, sqlType, dbType, direction, value);
            string formattedStatement = string.Format(
                    CultureInfo.InvariantCulture,
                    @"exec sp_executesql N'PRINT @p',N'@p {0}',@p={1}",
                    sqlType,
                    GenerateStringValue(value));
            reader.TraceData.Rows.Add(
                rpc,
                formattedStatement,
                database,
                spid);
        }

        private static void GenerateSqlStatementInputOutputParameterTestFromTrace(MockTraceReader reader, string sqlType, DbType dbType, object value)
        {
            ParameterDirection direction = ParameterDirection.InputOutput;
            GenerateSqlStatementCommentFromTrace(reader, sqlType, dbType, direction, value);
            string statement =
@"declare @p3 {0}
set @p3={1}
exec sp_executesql N'SELECT @p={2}',N'@p {0} output',@p=@p3 output
select @p3
";
            string formattedStatement = string.Format(
                    CultureInfo.InvariantCulture,
                    statement,
                    sqlType,
                    GenerateStringValue(value, false),
                    GenerateStringValue(value, true));

            reader.TraceData.Rows.Add(
                rpc,
                formattedStatement,
                database,
                spid);
        }

        private static void GenerateSqlStatementCommentFromTrace(MockTraceReader reader, string sqlType, DbType dbType, ParameterDirection direction, object value)
        {
            string comment = GenerateSqlStatementComment(sqlType, dbType, direction, value);
            reader.TraceData.Rows.Add(sql, comment, database, spid);
        }

        #endregion
    }
}
