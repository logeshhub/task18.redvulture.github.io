//---------------------------------------------------------------------
// <copyright file="ItemCodeGeneratorTestBase.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
//     THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
//     OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
//     LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//     FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>The ItemCodeGeneratorTestBase type.</summary>
//---------------------------------------------------------------------

namespace Microsoft.DatabaseLoadTest.Library.Test
{
    using System;
    using System.CodeDom;
    using System.CodeDom.Compiler;
    using System.Collections.Generic;
    using System.IO;
    using System.Reflection;
    using System.Text;

    using Microsoft.VisualStudio.TestTools.UnitTesting;

    /// <summary>
    /// Base class for testing code generation at the item level.
    /// </summary>
    public abstract class ItemCodeGeneratorTestBase
    {
        private CodeStatementCollection methodBody;

        private CodeDomProvider provider = new Microsoft.CSharp.CSharpCodeProvider();
        private CodeCompileUnit ccu;
        private CodeNamespaceImportCollection imports;
        private bool useFullQualification = false;

        protected CodeStatementCollection MethodBody
        {
            get { return this.methodBody; }
            set { this.methodBody = value; }
        }

        /// <summary>
        /// Sets up the CodeDom objects required to test the item generator
        /// </summary>
        protected void SetupTest()
        {
            this.ccu = new CodeCompileUnit();
            CodeNamespace testNamespace = new CodeNamespace();
            this.ccu.Namespaces.Add(testNamespace);
            CodeTypeDeclaration testType = new CodeTypeDeclaration("Test");
            testNamespace.Types.Add(testType);
            testType.IsClass = true;
            testType.TypeAttributes = TypeAttributes.Public;

            CodeMemberMethod testMethod = new CodeMemberMethod();
            testMethod.Name = "TestMethod";
            testMethod.Attributes = MemberAttributes.Public | MemberAttributes.Final;

            testType.Members.Add(testMethod);

            this.imports = testNamespace.Imports;
            this.methodBody = testMethod.Statements;
            this.useFullQualification = false;
        }

        /// <summary>
        /// Resolves code type references by adding namespace imports.
        /// </summary>
        /// <param name="sender">The object that raised the event.</param>
        /// <param name="o">The <see cref="CodeTypeReferenceRequestEventArgs"/> object to be resolved.</param>
        protected void CodeTypeReferenceRequestEventHandler(object sender, CodeTypeReferenceRequestEventArgs o)
        {
            if (this.useFullQualification)
            {
                o.CodeTypeReference = new CodeTypeReference(o.RequestedType);
            }
            else
            {
                bool alreadyImported = false;
                foreach (CodeNamespaceImport import in this.imports)
                {
                    if (import.Namespace == o.RequestedType.Namespace)
                    {
                        alreadyImported = true;
                    }
                }

                if (!alreadyImported)
                {
                    this.imports.Add(new CodeNamespaceImport(o.RequestedType.Namespace));
                }

                Type t;
                if (o.RequestedType.IsArray)
                {
                    t = o.RequestedType.GetElementType();
                }
                else
                {
                    t = o.RequestedType;
                }

                string typeName = string.Empty;
                while (t != null)
                {
                    if (typeName.Length == 0)
                    {
                        typeName = t.Name;
                    }
                    else
                    {
                        typeName = t.Name + "." + typeName;
                    }

                    t = t.DeclaringType;
                }

                if (o.RequestedType.IsArray)
                {
                    typeName += "[]";
                }

                o.CodeTypeReference = new CodeTypeReference(typeName, o.GenericParameters);
            }
        }

        /// <summary>
        /// Generates the code that has been created and compares it to the expected result.
        /// </summary>
        /// <param name="expectedCode"></param>
        protected void GenerateAndCompareCode(string expectedCode)
        {
            StringBuilder actualCode = new StringBuilder();
            using (IndentedTextWriter tw = new IndentedTextWriter(new StringWriter(actualCode), "    "))
            {
                CodeGeneratorOptions cgo = new CodeGeneratorOptions();
                cgo.BracingStyle = "C";
                this.provider.GenerateCodeFromCompileUnit(this.ccu, tw, cgo);
                tw.Close();
            }

            CodeGenerationTestUtilities.CompareCode(actualCode.ToString(), expectedCode);
        }
    }
}
