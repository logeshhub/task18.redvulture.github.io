//---------------------------------------------------------------------
// <copyright file="MockTraceReader.IDataReader.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
//     THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
//     OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
//     LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//     FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>The MockTraceReader class.</summary>
//---------------------------------------------------------------------

namespace Microsoft.DatabaseLoadTest.Library.Test
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Text;

    internal partial class MockTraceReader
    {
        public bool IsClosed
        {
            get { throw new Exception("The method or operation is not implemented."); }
        }

        public int RecordsAffected
        {
            get { throw new Exception("The method or operation is not implemented."); }
        }

        public int Depth
        {
            get { throw new Exception("The method or operation is not implemented."); }
        }

        public void Close()
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public DataTable GetSchemaTable()
        {
            return this.schema;
        }

        public bool NextResult()
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public bool Read()
        {
            bool ans = this.currentRow < this.traceData.Rows.Count - 1;
            if (ans)
            {
                this.currentRow++;
            }

            return ans;
        }
    }
}
