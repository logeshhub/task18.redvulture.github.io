//---------------------------------------------------------------------
// <copyright file="MockTraceReader.IDataRecord.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
//     THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
//     OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
//     LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//     FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>The MockTraceReader class.</summary>
//---------------------------------------------------------------------

namespace Microsoft.DatabaseLoadTest.Library.Test
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Text;

    using Microsoft.SqlServer.Management.Trace;

    internal partial class MockTraceReader
    {
        public int FieldCount
        {
            get { throw new Exception("The method or operation is not implemented."); }
        }

        public object this[string name]
        {
            get { return this.traceData.Rows[this.currentRow][name]; }
        }

        public object this[int i]
        {
            get { return this.traceData.Rows[this.currentRow][i]; }
        }

        public bool GetBoolean(int i)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public byte GetByte(int i)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public long GetBytes(int i, long fieldOffset, byte[] buffer, int bufferoffset, int length)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public char GetChar(int i)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public long GetChars(int i, long fieldoffset, char[] buffer, int bufferoffset, int length)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public IDataReader GetData(int i)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public string GetDataTypeName(int i)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public DateTime GetDateTime(int i)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public decimal GetDecimal(int i)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public double GetDouble(int i)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public Type GetFieldType(int i)
        {
            return this.traceData.Rows[this.currentRow][i].GetType();
        }

        public float GetFloat(int i)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public Guid GetGuid(int i)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public short GetInt16(int i)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public int GetInt32(int i)
        {
            return (Int32)this.traceData.Rows[this.currentRow][i];
        }

        public long GetInt64(int i)
        {
            return (Int64)this.traceData.Rows[this.currentRow][i];
        }

        public string GetName(int i)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public int GetOrdinal(string name)
        {
            int ans = -1;
            for (int i = 0; i < this.schema.Rows.Count; i++)
            {
                if ((string)(this.schema.Rows[i]["ColumnName"]) == name)
                {
                    ans = i;
                    break;
                }
            }

            if (ans < 0)
            {
                throw new SqlTraceException();
            }

            return ans;
        }

        public string GetString(int i)
        {
            return (string)this.traceData.Rows[this.currentRow][i];
        }

        public object GetValue(int i)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public int GetValues(object[] values)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public bool IsDBNull(int i)
        {
            return this.traceData.Rows[this.currentRow][i] == DBNull.Value;
        }
    }
}
