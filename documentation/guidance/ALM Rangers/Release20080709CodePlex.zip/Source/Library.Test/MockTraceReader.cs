//---------------------------------------------------------------------
// <copyright file="MockTraceReader.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
//     THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
//     OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
//     LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//     FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>The MockTraceReader class.</summary>
//---------------------------------------------------------------------

namespace Microsoft.DatabaseLoadTest.Library.Test
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Text;

    internal partial class MockTraceReader : IDataReader
    {
        private DataTable schema;
        private int currentRow = -1;
        private DataTable traceData;

        public MockTraceReader()
        {
            this.schema = new DataTable();

            this.schema.Columns.Add("ColumnName", typeof(string));
            this.schema.Columns.Add("DataType", typeof(Type));

            this.schema.Rows.Add("EventClass", typeof(string));
            this.schema.Rows.Add("TextData", typeof(string));
            this.schema.Rows.Add("DatabaseName", typeof(string));
            this.schema.Rows.Add("SPID", typeof(int));

            this.CreateDataTable();
        }

        public MockTraceReader(DataTable schema)
        {
            this.schema = schema;
            this.CreateDataTable();
        }

        public DataTable TraceData
        {
            get { return this.traceData; }
            set { this.traceData = value; }
        }

        #region IDisposable Members

        public void Dispose()
        {
            throw new Exception("The method or operation is not implemented.");
        }

        #endregion

        private void CreateDataTable()
        {
            this.traceData = new DataTable();
            foreach (DataRow r in this.schema.Rows)
            {
                this.traceData.Columns.Add((string)r[0], (Type)r[1]);
            }
        }
    }
}
