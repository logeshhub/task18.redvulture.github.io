﻿//---------------------------------------------------------------------
// <copyright file="NonCustomCodeGeneratorType.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
//     THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
//     OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
//     LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//     FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>The NonCustomCodeGeneratorType type.</summary>
//---------------------------------------------------------------------

namespace Microsoft.DatabaseLoadTest.Library.Test
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    /// <summary>
    /// Looks like a custom code generator but does not have the interface.
    /// </summary>
    public class NonCustomCodeGeneratorType
    {
        public bool GenerateCall(ParsedSqlCommand command, System.CodeDom.CodeMemberMethod scenarioMethod, System.CodeDom.CodeTypeDeclaration stubType)
        {
            return false;
        }
    }
}
