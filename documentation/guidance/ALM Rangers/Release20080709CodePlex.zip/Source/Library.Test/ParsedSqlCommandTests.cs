//---------------------------------------------------------------------
// <copyright file="ParsedSqlCommandTests.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
//     THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
//     OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
//     LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//     FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>The ParsedSqlCommandTests type.</summary>
//---------------------------------------------------------------------

namespace Microsoft.DatabaseLoadTest.Library.Test
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Text;

    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class ParsedSqlCommandTests
    {
        [TestMethod]
        public void PSC_ParameterListCanBeModified()
        {
            List<ParsedSqlParameter> parameters = new List<ParsedSqlParameter>();
            ParsedSqlCommand cmd = new ParsedSqlCommand("abc", CommandType.Text, parameters);
            IList<ParsedSqlParameter> retrievedParameters = cmd.Parameters;
            retrievedParameters.Add(new ParsedSqlParameter("@a", DbType.String, null, ParameterDirection.Input));
        }

        [TestMethod]
        public void PSC_InputParameterListCannotBeModified()
        {
            List<ParsedSqlParameter> parameters = new List<ParsedSqlParameter>();
            ParsedSqlCommand cmd = new ParsedSqlCommand("abc", CommandType.Text, parameters);
            IList<ParsedSqlParameter> retrievedParameters = cmd.InputParameters;
            TestHelper.TestForNotSupportedException(
                delegate()
                {
                    retrievedParameters.Add(new ParsedSqlParameter("@a", DbType.String, null, ParameterDirection.Input));
                });
        }

        [TestMethod]
        public void PSC_OutputParameterListCannotBeModified()
        {
            List<ParsedSqlParameter> parameters = new List<ParsedSqlParameter>();
            ParsedSqlCommand cmd = new ParsedSqlCommand("abc", CommandType.Text, parameters);
            IList<ParsedSqlParameter> retrievedParameters = cmd.OutputParameters;
            TestHelper.TestForNotSupportedException(
                delegate()
                {
                    retrievedParameters.Add(new ParsedSqlParameter("@a", DbType.String, null, ParameterDirection.Output));
                });
        }

        [TestMethod]
        public void PSC_InputOutputParameterListCannotBeModified()
        {
            List<ParsedSqlParameter> parameters = new List<ParsedSqlParameter>();
            ParsedSqlCommand cmd = new ParsedSqlCommand("abc", CommandType.Text, parameters);
            IList<ParsedSqlParameter> retrievedParameters = cmd.InputOutputParameters;
            TestHelper.TestForNotSupportedException(
                delegate()
                {
                    retrievedParameters.Add(new ParsedSqlParameter("@a", DbType.String, null, ParameterDirection.InputOutput));
                });
        }

        [TestMethod]
        public void PSC_NoParametersToConstructorReturnsEmptyParameterList()
        {
            List<ParsedSqlParameter> parameters = new List<ParsedSqlParameter>();
            ParsedSqlCommand cmd = new ParsedSqlCommand("abc", CommandType.Text, parameters);
            Assert.AreEqual<int>(0, cmd.Parameters.Count);
        }

        [TestMethod]
        public void PSC_NoParametersToConstructorReturnsEmptyInputParameterList()
        {
            List<ParsedSqlParameter> parameters = new List<ParsedSqlParameter>();
            ParsedSqlCommand cmd = new ParsedSqlCommand("abc", CommandType.Text, parameters);
            Assert.AreEqual<int>(0, cmd.InputParameters.Count);
        }

        [TestMethod]
        public void PSC_NoParametersToConstructorReturnsEmptyOutputParameterList()
        {
            List<ParsedSqlParameter> parameters = new List<ParsedSqlParameter>();
            ParsedSqlCommand cmd = new ParsedSqlCommand("abc", CommandType.Text, parameters);
            Assert.AreEqual<int>(0, cmd.OutputParameters.Count);
        }

        [TestMethod]
        public void PSC_MixedParameterDirectionsAreSeparatedIntoSeparateLists()
        {
            List<ParsedSqlParameter> parameters = new List<ParsedSqlParameter>();
            parameters.Add(new ParsedSqlParameter("@i1", DbType.Int64, null, ParameterDirection.Input));
            parameters.Add(new ParsedSqlParameter("@io1", DbType.Int64, 1, ParameterDirection.InputOutput));
            parameters.Add(new ParsedSqlParameter("@o1", DbType.Int64, null, ParameterDirection.Output));
            parameters.Add(new ParsedSqlParameter("@o2", DbType.Int64, null, ParameterDirection.Output));
            parameters.Add(new ParsedSqlParameter("@i2", DbType.Int64, null, ParameterDirection.Input));
            parameters.Add(new ParsedSqlParameter("@i3", DbType.Int64, null, ParameterDirection.Input));
            parameters.Add(new ParsedSqlParameter("@io2", DbType.Int64, 2, ParameterDirection.InputOutput));
            parameters.Add(new ParsedSqlParameter("@o3", DbType.Int64, null, ParameterDirection.Output));
            ParsedSqlCommand cmd = new ParsedSqlCommand("abc", CommandType.Text, parameters);

            Assert.AreEqual<int>(8, cmd.Parameters.Count);
            Assert.AreEqual<string>("@i1", cmd.Parameters[0].Name);
            Assert.AreEqual<string>("@io1", cmd.Parameters[1].Name);
            Assert.AreEqual<string>("@o1", cmd.Parameters[2].Name);
            Assert.AreEqual<string>("@o2", cmd.Parameters[3].Name);
            Assert.AreEqual<string>("@i2", cmd.Parameters[4].Name);
            Assert.AreEqual<string>("@i3", cmd.Parameters[5].Name);
            Assert.AreEqual<string>("@io2", cmd.Parameters[6].Name);
            Assert.AreEqual<string>("@o3", cmd.Parameters[7].Name);

            Assert.AreEqual<int>(3, cmd.InputParameters.Count);
            Assert.AreEqual<string>("@i1", cmd.InputParameters[0].Name);
            Assert.AreEqual<string>("@i2", cmd.InputParameters[1].Name);
            Assert.AreEqual<string>("@i3", cmd.InputParameters[2].Name);

            Assert.AreEqual<int>(3, cmd.OutputParameters.Count);
            Assert.AreEqual<string>("@o1", cmd.OutputParameters[0].Name);
            Assert.AreEqual<string>("@o2", cmd.OutputParameters[1].Name);
            Assert.AreEqual<string>("@o3", cmd.OutputParameters[2].Name);

            Assert.AreEqual<int>(2, cmd.InputOutputParameters.Count);
            Assert.AreEqual<string>("@io1", cmd.InputOutputParameters[0].Name);
            Assert.AreEqual<string>("@io2", cmd.InputOutputParameters[1].Name);

        }

        [TestMethod]
        public void PSC_NamedParametersCanBeSet()
        {
            List<ParsedSqlParameter> parameters = new List<ParsedSqlParameter>();
            parameters.Add(new ParsedSqlParameter("@i1", DbType.Int64, null, ParameterDirection.Input));
            parameters.Add(new ParsedSqlParameter("@i2", DbType.Int64, null, ParameterDirection.Output));
            ParsedSqlCommand cmd = new ParsedSqlCommand("abc", CommandType.Text, parameters);

            Assert.AreEqual<int>(2, cmd.Parameters.Count);
            Assert.AreEqual<string>("@i1", cmd.Parameters[0].Name);
            Assert.AreEqual<string>("@i2", cmd.Parameters[1].Name);
        }

        [TestMethod]
        public void PSC_PositionalParametersCanBeSetAndAreAutomaticallyNamed()
        {
            List<ParsedSqlParameter> parameters = new List<ParsedSqlParameter>();
            parameters.Add(new ParsedSqlParameter("", DbType.Int64, null, ParameterDirection.Input));
            parameters.Add(new ParsedSqlParameter("", DbType.Int64, null, ParameterDirection.Output));
            ParsedSqlCommand cmd = new ParsedSqlCommand("abc", CommandType.StoredProcedure, parameters);

            Assert.AreEqual<int>(2, cmd.Parameters.Count);
            Assert.AreEqual<string>("@p1", cmd.Parameters[0].Name);
            Assert.AreEqual<string>("@p2", cmd.Parameters[1].Name);
        }

        [TestMethod]
        public void PSC_CanMixNamedAndPositionalParameters()
        {
            List<ParsedSqlParameter> parameters = new List<ParsedSqlParameter>();
            parameters.Add(new ParsedSqlParameter("@i1", DbType.Int64, null, ParameterDirection.Input));
            parameters.Add(new ParsedSqlParameter("", DbType.Int64, null, ParameterDirection.Output));
            ParsedSqlCommand cmd = new ParsedSqlCommand("abc", CommandType.StoredProcedure, parameters);
            Assert.AreEqual<int>(2, cmd.Parameters.Count);
            Assert.AreEqual<string>("@i1", cmd.Parameters[0].Name);
            Assert.AreEqual<string>("@p2", cmd.Parameters[1].Name);
        }

        [TestMethod]
        public void PSC_ConstructorPreservesPositionality()
        {
            List<ParsedSqlParameter> parameters = new List<ParsedSqlParameter>();
            parameters.Add(new ParsedSqlParameter("@i1", DbType.Int64, null, ParameterDirection.Input, true));
            parameters.Add(new ParsedSqlParameter("@i2", DbType.Int64, null, ParameterDirection.Input, false));
            parameters.Add(new ParsedSqlParameter("", DbType.Int64, null, ParameterDirection.Output, true));
            ParsedSqlCommand cmd = new ParsedSqlCommand("abc", CommandType.StoredProcedure, parameters);

            Assert.IsTrue(cmd.Parameters[0].Positional);
            Assert.IsFalse(cmd.Parameters[1].Positional);
            Assert.IsTrue(cmd.Parameters[2].Positional);
        }

        [TestMethod]
        public void PSC_ConstructorPositionalParametersSuppliedToSqlStatementAreGivenNamesAndBecomeNonPositional()
        {
            List<ParsedSqlParameter> parameters = new List<ParsedSqlParameter>();
            parameters.Add(new ParsedSqlParameter("@i1", DbType.Int64, null, ParameterDirection.Input, true));
            parameters.Add(new ParsedSqlParameter("@i2", DbType.String, null, ParameterDirection.Input, false));
            parameters.Add(new ParsedSqlParameter("", DbType.String, null, ParameterDirection.Input, true));

            ParsedSqlCommand cmd = new ParsedSqlCommand("abc", CommandType.Text, parameters);

            Assert.AreEqual<string>("@p1", cmd.Parameters[0].Name);
            Assert.IsFalse(cmd.Parameters[0].Positional);

            Assert.AreEqual<string>("@i2", cmd.Parameters[1].Name);
            Assert.IsFalse(cmd.Parameters[1].Positional);

            Assert.AreEqual<string>("@p3", cmd.Parameters[2].Name);
            Assert.IsFalse(cmd.Parameters[2].Positional);
        }

        [TestMethod]
        public void PSC_ParameterListCanAddAnInputParameterAfterConstruction()
        {
            List<ParsedSqlParameter> parameters = new List<ParsedSqlParameter>();
            ParsedSqlCommand cmd = new ParsedSqlCommand("abc", CommandType.Text, parameters);
            cmd.Parameters.Add(new ParsedSqlParameter("@a", DbType.String, null, ParameterDirection.Input));
            Assert.AreEqual<int>(1, cmd.InputParameters.Count);
        }

        [TestMethod]
        public void PSC_ParameterListCanAddAnOutputParameterAfterConstruction()
        {
            List<ParsedSqlParameter> parameters = new List<ParsedSqlParameter>();
            ParsedSqlCommand cmd = new ParsedSqlCommand("abc", CommandType.Text, parameters);
            cmd.Parameters.Add(new ParsedSqlParameter("@a", DbType.String, null, ParameterDirection.Output));
            Assert.AreEqual<int>(1, cmd.OutputParameters.Count);
        }

        [TestMethod]
        public void PSC_ParameterListCanAddAnInputOutputParameterAfterConstruction()
        {
            List<ParsedSqlParameter> parameters = new List<ParsedSqlParameter>();
            ParsedSqlCommand cmd = new ParsedSqlCommand("abc", CommandType.Text, parameters);
            cmd.Parameters.Add(new ParsedSqlParameter("@a", DbType.String, null, ParameterDirection.InputOutput));
            Assert.AreEqual<int>(1, cmd.InputOutputParameters.Count);
        }
    }
}
