//---------------------------------------------------------------------
// <copyright file="ParsedSqlParameterTests.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
//     THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
//     OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
//     LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//     FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>The ParsedSqlParameterTests type.</summary>
//---------------------------------------------------------------------

namespace Microsoft.DatabaseLoadTest.Library.Test
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlTypes;
    using System.Text;

    using Microsoft.DatabaseLoadTest.Library;

    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class ParsedSqlParameterTests
    {
        [TestMethod]
        public void PSP_NonPositionalConstructorSetsName()
        {
            ParsedSqlParameter p = new ParsedSqlParameter("@a", DbType.Object, 1, ParameterDirection.Input);
            Assert.AreEqual<string>("@a", p.Name);
        }

        [TestMethod]
        public void PSP_NonPositionalConstructorSetsType()
        {
            ParsedSqlParameter p = new ParsedSqlParameter("@a", DbType.Object, 1, ParameterDirection.Input);
            Assert.AreEqual<DbType>(DbType.Object, p.Type);
        }

        [TestMethod]
        public void PSP_NonPositionalConstructorSetsValue()
        {
            ParsedSqlParameter p = new ParsedSqlParameter("@a", DbType.Object, 1, ParameterDirection.Input);
            Assert.AreEqual<int>(1, (int)p.Value);
        }

        [TestMethod]
        public void PSP_NonPositionalConstructorWithBlankNameReturnsPositionalTrue()
        {
            ParsedSqlParameter p1 = new ParsedSqlParameter(string.Empty, DbType.Object, 1, ParameterDirection.Input);
            Assert.IsTrue(p1.Positional);
        }

        [TestMethod]
        public void PSP_NonPositionalConstructorWithNonBlankNameReturnsPositionalFalse()
        {
            ParsedSqlParameter p1 = new ParsedSqlParameter("@a", DbType.Object, 1, ParameterDirection.Input);
            Assert.IsFalse(p1.Positional);
        }

        [TestMethod]
        public void PSP_PositionalConstructorSetsName()
        {
            ParsedSqlParameter p = new ParsedSqlParameter("@a", DbType.Object, 1, ParameterDirection.Input, true);
            Assert.AreEqual<string>("@a", p.Name);
        }

        [TestMethod]
        public void PSP_PositionalConstructorSetsType()
        {
            ParsedSqlParameter p = new ParsedSqlParameter("@a", DbType.Object, 1, ParameterDirection.Input, true);
            Assert.AreEqual<DbType>(DbType.Object, p.Type);
        }

        [TestMethod]
        public void PSP_PositionalConstructorSetsValue()
        {
            ParsedSqlParameter p = new ParsedSqlParameter("@a", DbType.Object, 1, ParameterDirection.Input, true);
            Assert.AreEqual<int>(1, (int)p.Value);
        }

        [TestMethod]
        public void PSP_PositionalConstructorSetsDirection()
        {
            ParsedSqlParameter p = new ParsedSqlParameter("@a", DbType.Object, 1, ParameterDirection.Input, true);
            Assert.AreEqual<ParameterDirection>(ParameterDirection.Input, p.Direction);
        }

        [TestMethod]
        public void PSP_PositionalConstructorSetsPositional()
        {
            ParsedSqlParameter p = new ParsedSqlParameter("@a", DbType.Object, 1, ParameterDirection.Input, true);
            Assert.IsTrue(p.Positional);
        }

        [TestMethod]
        public void PSP_PositionalConstructorWithBlankNameAndNonPositionalFlagThrowsException()
        {
            TestHelper.TestForInvalidOperationException(
                delegate
                {
                    ParsedSqlParameter p = new ParsedSqlParameter(null, DbType.Object, 1, ParameterDirection.Input, false);
                });
        }

        [TestMethod]
        public void PSP_LegalDbTypesCanBeSet()
        {
            ParsedSqlParameter p;
            p = new ParsedSqlParameter("@a", DbType.Int64, null, ParameterDirection.Input);
            p = new ParsedSqlParameter("@a", DbType.Int32, null, ParameterDirection.Input);
            p = new ParsedSqlParameter("@a", DbType.Int16, null, ParameterDirection.Input);
            p = new ParsedSqlParameter("@a", DbType.Byte, null, ParameterDirection.Input);
            p = new ParsedSqlParameter("@a", DbType.Boolean, null, ParameterDirection.Input);
            p = new ParsedSqlParameter("@a", DbType.Decimal, null, ParameterDirection.Input);
            p = new ParsedSqlParameter("@a", DbType.Double, null, ParameterDirection.Input);
            p = new ParsedSqlParameter("@a", DbType.Single, null, ParameterDirection.Input);
            p = new ParsedSqlParameter("@a", DbType.DateTime, null, ParameterDirection.Input);
            p = new ParsedSqlParameter("@a", DbType.String, null, ParameterDirection.Input);
            p = new ParsedSqlParameter("@a", DbType.Binary, null, ParameterDirection.Input);
            p = new ParsedSqlParameter("@a", DbType.Object, null, ParameterDirection.Input);
            p = new ParsedSqlParameter("@a", DbType.Guid, null, ParameterDirection.Input);
        }

        [TestMethod]
        public void PSP_IllegalDbTypesCannotBeSet()
        {
            this.SetIllegalDbType(DbType.AnsiString);
            this.SetIllegalDbType(DbType.AnsiStringFixedLength);
            this.SetIllegalDbType(DbType.Currency);
            this.SetIllegalDbType(DbType.Date);
            this.SetIllegalDbType(DbType.SByte);
            this.SetIllegalDbType(DbType.StringFixedLength);
            this.SetIllegalDbType(DbType.Time);
            this.SetIllegalDbType(DbType.UInt16);
            this.SetIllegalDbType(DbType.UInt32);
            this.SetIllegalDbType(DbType.UInt64);
            this.SetIllegalDbType(DbType.VarNumeric);
            this.SetIllegalDbType(DbType.Xml);
        }

        [TestMethod]
        public void PSP_ToNetTypeMappingCorrectForNonNullValues()
        {
            this.CheckNetMapping(DbType.Object, (Int64)1, typeof(Nullable<SqlInt64>));
            this.CheckNetMapping(DbType.Object, (Double)1, typeof(Nullable<SqlDouble>));
            this.CheckNetMapping(DbType.Object, "abc", typeof(Nullable<SqlString>));
            this.CheckNetMapping(DbType.Object, new Byte[0], typeof(Nullable<SqlBinary>));
        }

        [TestMethod]
        public void PSP_ToNetTypeMappingCorrectForNonDBNull()
        {
            this.CheckNetMapping(DbType.Int64, null, typeof(Nullable<SqlInt64>));
            this.CheckNetMapping(DbType.Int32, null, typeof(Nullable<SqlInt32>));
            this.CheckNetMapping(DbType.Int16, null, typeof(Nullable<SqlInt16>));
            this.CheckNetMapping(DbType.Byte, null, typeof(Nullable<SqlByte>));
            this.CheckNetMapping(DbType.Boolean, null, typeof(Nullable<SqlBoolean>));
            this.CheckNetMapping(DbType.Decimal, null, typeof(Nullable<SqlDecimal>));
            this.CheckNetMapping(DbType.Double, null, typeof(Nullable<SqlDouble>));
            this.CheckNetMapping(DbType.Single, null, typeof(Nullable<SqlSingle>));
            this.CheckNetMapping(DbType.DateTime, null, typeof(Nullable<SqlDateTime>));
            this.CheckNetMapping(DbType.String, null, typeof(Nullable<SqlString>));
            this.CheckNetMapping(DbType.Binary, null, typeof(Nullable<SqlBinary>));
            this.CheckNetMapping(DbType.Guid, null, typeof(Nullable<SqlGuid>));
            this.CheckNetMapping(DbType.Object, null, typeof(Object));
        }

        [TestMethod]
        public void PSP_ToNetTypeMappingCorrectForDBNull()
        {
            this.CheckNetMapping(DbType.Int64, DBNull.Value, typeof(Nullable<SqlInt64>));
            this.CheckNetMapping(DbType.Int32, DBNull.Value, typeof(Nullable<SqlInt32>));
            this.CheckNetMapping(DbType.Int16, DBNull.Value, typeof(Nullable<SqlInt16>));
            this.CheckNetMapping(DbType.Byte, DBNull.Value, typeof(Nullable<SqlByte>));
            this.CheckNetMapping(DbType.Boolean, DBNull.Value, typeof(Nullable<SqlBoolean>));
            this.CheckNetMapping(DbType.Decimal, DBNull.Value, typeof(Nullable<SqlDecimal>));
            this.CheckNetMapping(DbType.Double, DBNull.Value, typeof(Nullable<SqlDouble>));
            this.CheckNetMapping(DbType.Single, DBNull.Value, typeof(Nullable<SqlSingle>));
            this.CheckNetMapping(DbType.DateTime, DBNull.Value, typeof(Nullable<SqlDateTime>));
            this.CheckNetMapping(DbType.String, DBNull.Value, typeof(Nullable<SqlString>));
            this.CheckNetMapping(DbType.Binary, DBNull.Value, typeof(Nullable<SqlBinary>));
            this.CheckNetMapping(DbType.Guid, DBNull.Value, typeof(Nullable<SqlGuid>));
            this.CheckNetMapping(DbType.Object, DBNull.Value, typeof(object));
        }

        [TestMethod]
        public void PSP_ValueMappingCorrectForNonNullValues()
        {
            this.CheckValueMapping(DbType.Object, (Int64)1, (Int64)1);
            this.CheckValueMapping(DbType.Object, (Double)1, (Double)1);
            this.CheckValueMapping(DbType.Object, "abc", "abc");
        }

        [TestMethod]
        public void PSP_ValueMappingCorrectForNonDBNull()
        {
            this.CheckValueMapping(DbType.Int64, null, null);
            this.CheckValueMapping(DbType.Int32, null, null);
            this.CheckValueMapping(DbType.Int16, null, null);
            this.CheckValueMapping(DbType.Byte, null, null);
            this.CheckValueMapping(DbType.Boolean, null, null);
            this.CheckValueMapping(DbType.Decimal, null, null);
            this.CheckValueMapping(DbType.Double, null, null);
            this.CheckValueMapping(DbType.Single, null, null);
            this.CheckValueMapping(DbType.DateTime, null, null);
            this.CheckValueMapping(DbType.String, null, null);
            this.CheckValueMapping(DbType.Binary, null, null);
            this.CheckValueMapping(DbType.Guid, null, null);
            this.CheckValueMapping(DbType.Object, null, null);
        }

        [TestMethod]
        public void PSP_ValueMappingCorrectForDBNull()
        {
            this.CheckValueMapping(DbType.Int64, DBNull.Value, SqlInt64.Null);
            this.CheckValueMapping(DbType.Int32, DBNull.Value, SqlInt32.Null);
            this.CheckValueMapping(DbType.Int16, DBNull.Value, SqlInt16.Null);
            this.CheckValueMapping(DbType.Byte, DBNull.Value, SqlByte.Null);
            this.CheckValueMapping(DbType.Boolean, DBNull.Value, SqlBoolean.Null);
            this.CheckValueMapping(DbType.Decimal, DBNull.Value, SqlDecimal.Null);
            this.CheckValueMapping(DbType.Double, DBNull.Value, SqlDouble.Null);
            this.CheckValueMapping(DbType.Single, DBNull.Value, SqlSingle.Null);
            this.CheckValueMapping(DbType.DateTime, DBNull.Value, SqlDateTime.Null);
            this.CheckValueMapping(DbType.String, DBNull.Value, SqlString.Null);
            this.CheckValueMapping(DbType.Binary, DBNull.Value, SqlBinary.Null);
            this.CheckValueMapping(DbType.Guid, DBNull.Value, SqlGuid.Null);
            this.CheckValueMapping(DbType.Object, DBNull.Value, DBNull.Value);
        }

        [TestMethod]
        public void PSP_NullIsNotEqual()
        {
            ParsedSqlParameter p = new ParsedSqlParameter("@a", DbType.Object, 1, ParameterDirection.Input);
            Assert.IsFalse(p.Equals(null));
        }

        [TestMethod]
        public void PSP_StringIsNotEqual()
        {
            ParsedSqlParameter p = new ParsedSqlParameter("@a", DbType.Object, 1, ParameterDirection.Input);
            Assert.IsFalse(p.Equals("@a"));
        }

        [TestMethod]
        public void SqlToken_SameValueIsEqual()
        {
            ParsedSqlParameter p1 = new ParsedSqlParameter("@a", DbType.Object, 1, ParameterDirection.Input);
            ParsedSqlParameter p2 = new ParsedSqlParameter("@a", DbType.Object, 1, ParameterDirection.Input);
            CheckEqualityTransitivityAndHashCode(p1, p2);
        }

        [TestMethod]
        public void PSP_SameValueDifferentCaseIsEqual()
        {
            ParsedSqlParameter p1 = new ParsedSqlParameter("@a", DbType.Object, 1, ParameterDirection.Input);
            ParsedSqlParameter p2 = new ParsedSqlParameter("@A", DbType.Object, 1, ParameterDirection.Input);
            CheckEqualityTransitivityAndHashCode(p1, p2);
        }

        [TestMethod]
        public void PSP_EqualToSelf()
        {
            ParsedSqlParameter p1 = new ParsedSqlParameter("@a", DbType.Object, 1, ParameterDirection.Input);
            CheckEqualityTransitivityAndHashCode(p1, p1);
        }

        [TestMethod]
        public void PSP_DifferentDbTypeStillEqual()
        {
            ParsedSqlParameter p1 = new ParsedSqlParameter("@a", DbType.Object, 1, ParameterDirection.Input);
            ParsedSqlParameter p2 = new ParsedSqlParameter("@a", DbType.Byte, 1, ParameterDirection.Input);
            CheckEqualityTransitivityAndHashCode(p1, p2);
        }

        [TestMethod]
        public void PSP_DifferentValueStillEqual()
        {
            ParsedSqlParameter p1 = new ParsedSqlParameter("@a", DbType.Object, 1, ParameterDirection.Input);
            ParsedSqlParameter p2 = new ParsedSqlParameter("@a", DbType.Object, 2, ParameterDirection.Input);
            CheckEqualityTransitivityAndHashCode(p1, p2);
        }

        [TestMethod]
        public void PSP_DifferentParameterDirectionStillEqual()
        {
            ParsedSqlParameter p1 = new ParsedSqlParameter("@a", DbType.Object, 1, ParameterDirection.Input);
            ParsedSqlParameter p2 = new ParsedSqlParameter("@a", DbType.Object, 1, ParameterDirection.Output);
            CheckEqualityTransitivityAndHashCode(p1, p2);
        }

        private static void CheckEqualityTransitivityAndHashCode(ParsedSqlParameter p1, ParsedSqlParameter p2)
        {
            Assert.IsTrue(p1.Equals(p2));
            Assert.AreEqual(p1, p2);
            Assert.AreEqual<ParsedSqlParameter>(p1, p2);

            Assert.IsTrue(p2.Equals(p1));
            Assert.AreEqual(p2, p1);
            Assert.AreEqual<ParsedSqlParameter>(p2, p1);

            Assert.AreEqual<int>(p1.GetHashCode(), p2.GetHashCode());
        }

        private void CheckNetMapping(DbType dbt, object value, Type expectedNetType)
        {
            ParsedSqlParameter p = new ParsedSqlParameter("@a", dbt, value, ParameterDirection.Input);
            Assert.AreEqual<Type>(expectedNetType, p.NetType);
        }

        private void CheckValueMapping(DbType dbt, object value, object expected)
        {
            ParsedSqlParameter p = new ParsedSqlParameter("@a", dbt, value, ParameterDirection.Input);
            Assert.AreEqual(expected, p.Value);
        }

        private void SetIllegalDbType(DbType dbt)
        {
            try
            {
                ParsedSqlParameter p = new ParsedSqlParameter("@a", dbt, null, ParameterDirection.Input);
                Assert.Fail("Was able to set unsupported DbType: " + dbt.ToString());
            }
            catch (InvalidOperationException)
            {
            }
        }
    }
}
