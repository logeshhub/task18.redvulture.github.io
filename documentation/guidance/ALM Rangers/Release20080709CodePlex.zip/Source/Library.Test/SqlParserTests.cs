//---------------------------------------------------------------------
// <copyright file="SqlParserTests.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
//     THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
//     OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
//     LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//     FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>The SqlParserTests type.</summary>
//---------------------------------------------------------------------

namespace Microsoft.DatabaseLoadTest.Library.Test
{
    using System;
    using System.Data;
    using System.Data.SqlTypes;
    using System.Globalization;
    using System.Text;
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    using Microsoft.DatabaseLoadTest.Library;

    [TestClass]
    public class SqlParserTests
    {
        [TestMethod]
        public void SqlParser_NullRecordThrowsException()
        {
            SqlParser p = new SqlParser();
            TestHelper.TestForArgumentNullException(
                "traceRecord",
                delegate
                {
                    p.ParseTraceRecord(null);
                });
        }

        [TestMethod]
        public void SqlParser_NullTextThrowsException()
        {
            SqlParser p = new SqlParser();
            TestHelper.TestForArgumentNullException(
                "traceRecord",
                delegate
                {
                    p.ParseTraceRecord(CreateSqlRecord(null));
                });
        }

        [TestMethod]
        public void SqlParser_EmptyTextThrowsException()
        {
            SqlParser p = new SqlParser();
            TraceRecord arg = CreateSqlRecord("");
            TestHelper.TestForArgumentNullException(
                "traceRecord",
                delegate
                {
                    p.ParseTraceRecord(arg);
                });
        }

        [TestMethod]
        public void SqlParser_InvalidEventClassThrowsException()
        {
            SqlParser p = new SqlParser();
            TestHelper.TestForArgumentOutOfRangeException(
                "traceRecord",
                delegate
                {
                    p.ParseTraceRecord(new TraceRecord("abc", "def", "dummy", 1));
                });
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatementWithUnsupportedTypeThrowsException()
        {
            SqlParser p = new SqlParser();
            TestHelper.TestForInvalidOperationException(
                delegate
                {
                    ParsedSqlCommand cmd = p.ParseTraceRecord(CreateRpcRecord("exec sp_executesql N'dummy',N'@Id stuff)',@Id=1"));
                });
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatementWithXmlTypeThrowsException()
        {
            SqlParser p = new SqlParser();
            TestHelper.TestForInvalidOperationException(
                delegate
                {
                    ParsedSqlCommand cmd = p.ParseTraceRecord(CreateRpcRecord("exec sp_executesql N'dummy',N'@Id xml)',@Id=1"));
                });
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatement()
        {
            SqlParser p = new SqlParser();
            ParsedSqlCommand cmd = p.ParseTraceRecord(CreateRpcRecord("exec sp_executesql N'INSERT Scratch (Id,MyData) VALUES (@Id,@Data); /* embedded comment */ INSERT Scratch (Id,MyData) VALUES (@Id2,@Data2) -- final comment',N'@Id int,@Data nvarchar(5),@Id2 int,@Data2 nvarchar(6)',@Id=1,@Data=N'param',@Id2=2,@Data2=N'param2'"));
            Assert.AreEqual<string>("INSERT Scratch (Id,MyData) VALUES (@Id,@Data); /* embedded comment */ INSERT Scratch (Id,MyData) VALUES (@Id2,@Data2) -- final comment", cmd.CommandText);
            Assert.AreEqual<CommandType>(CommandType.Text, cmd.CommandType);

            Assert.AreEqual<int>(4, cmd.Parameters.Count);

            Assert.AreEqual<string>("@Id", cmd.Parameters[0].Name);
            Assert.AreEqual<DbType>(DbType.Int32, cmd.Parameters[0].Type);
            Assert.AreEqual<int>(1, (int)cmd.Parameters[0].Value);
            Assert.AreEqual<ParameterDirection>(ParameterDirection.Input, cmd.Parameters[0].Direction);

            Assert.AreEqual<string>("@Data", cmd.Parameters[1].Name);
            Assert.AreEqual<DbType>(DbType.String, cmd.Parameters[1].Type);
            Assert.AreEqual<string>("param", (string)cmd.Parameters[1].Value);
            Assert.AreEqual<ParameterDirection>(ParameterDirection.Input, cmd.Parameters[1].Direction);

            Assert.AreEqual<string>("@Id2", cmd.Parameters[2].Name);
            Assert.AreEqual<DbType>(DbType.Int32, cmd.Parameters[2].Type);
            Assert.AreEqual<int>(2, (int)cmd.Parameters[2].Value);
            Assert.AreEqual<ParameterDirection>(ParameterDirection.Input, cmd.Parameters[2].Direction);

            Assert.AreEqual<string>("@Data2", cmd.Parameters[3].Name);
            Assert.AreEqual<DbType>(DbType.String, cmd.Parameters[3].Type);
            Assert.AreEqual<string>("param2", (string)cmd.Parameters[3].Value);
            Assert.AreEqual<ParameterDirection>(ParameterDirection.Input, cmd.Parameters[3].Direction);
        }

        #region ParseParameterisedSqlStatement for each data type

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatementBigInt()
        {
            ParseParameterisedSqlStatement<Nullable<SqlInt64>, Int64>(DbType.Int64, "bigint", "1", (Int64)1);
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatementInt()
        {
            ParseParameterisedSqlStatement<Nullable<SqlInt32>, Int32>(DbType.Int32, "int", "1", (Int32)1);
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatementSmallint()
        {
            ParseParameterisedSqlStatement<Nullable<SqlInt16>, Int16>(DbType.Int16, "smallint", "1", (Int16)1);
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatementTinyint()
        {
            ParseParameterisedSqlStatement<Nullable<SqlByte>, Byte>(DbType.Byte, "tinyint", "1", (Byte)1);
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatementBit()
        {
            ParseParameterisedSqlStatement<Nullable<SqlBoolean>, Boolean>(DbType.Boolean, "bit", "1", true);
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatementDecimal()
        {
            ParseParameterisedSqlStatement<Nullable<SqlDecimal>, Decimal>(DbType.Decimal, "decimal(10,8)", "1", 1m);
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatementNumeric()
        {
            ParseParameterisedSqlStatement<Nullable<SqlDecimal>, Decimal>(DbType.Decimal, "numeric(10,8)", "1", 1m);
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatementMoney()
        {
            ParseParameterisedSqlStatement<Nullable<SqlDecimal>, Decimal>(DbType.Decimal, "money", "1", 1m);
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatementSmallMoney()
        {
            ParseParameterisedSqlStatement<Nullable<SqlDecimal>, Decimal>(DbType.Decimal, "smallmoney", "1", 1m);
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatementFloat()
        {
            ParseParameterisedSqlStatement<Nullable<SqlDouble>, Double>(DbType.Double, "float", "1", (Double)1);
       }

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatementReal()
        {
            ParseParameterisedSqlStatement<Nullable<SqlSingle>, Single>(DbType.Single, "real", "1", (Single)1);
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatementDatetime()
        {
            ParseParameterisedSqlStatement<Nullable<SqlDateTime>, DateTime>(DbType.DateTime, "datetime", "'Jun 18 2007 12:00:00:000PM'", new DateTime(2007, 6, 18, 12, 0, 0));
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatementDatetimeWithNoLeadingDigitOnHours()
        {
            ParseParameterisedSqlStatement<Nullable<SqlDateTime>, DateTime>(DbType.DateTime, "datetime", "'Jun 18 2007 2:00:00:000PM'", new DateTime(2007, 6, 18, 14, 0, 0));
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatementSmallDatetime()
        {
            // extra space between Jun and 1 is significant
            ParseParameterisedSqlStatement<Nullable<SqlDateTime>, DateTime>(DbType.DateTime, "datetime", "'Jun  1 2007 12:00:00:000PM'", new DateTime(2007, 6, 1, 12, 0, 0));
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatementChar()
        {
            ParseParameterisedSqlStatement<Nullable<SqlString>, String>(DbType.String, "char(10)", "'1'", "1");
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatementVarChar()
        {
            ParseParameterisedSqlStatement<Nullable<SqlString>, String>(DbType.String, "varchar(10)", "'1'", "1");
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatementText()
        {
            ParseParameterisedSqlStatement<Nullable<SqlString>, String>(DbType.String, "text", "'1'", "1");
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatementNChar()
        {
            ParseParameterisedSqlStatement<Nullable<SqlString>, String>(DbType.String, "nchar(10)", "'1'", "1");
       }

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatementNVarChar()
        {
            ParseParameterisedSqlStatement<Nullable<SqlString>, String>(DbType.String, "nvarchar(10)", "'1'", "1");
       }

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatementNText()
        {
            ParseParameterisedSqlStatement<Nullable<SqlString>, String>(DbType.String, "ntext", "'1'", "1");
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatementBinary()
        {
            ParseParameterisedSqlStatementByteArray<Nullable<SqlBinary>>(DbType.Binary, "binary", "0x01", new byte[] { 1 });
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatementBinaryEmpty()
        {
            ParseParameterisedSqlStatementByteArray<Nullable<SqlBinary>>(DbType.Binary, "binary", "0x", new byte[] { });
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatementVarBinary()
        {
            ParseParameterisedSqlStatementByteArray<Nullable<SqlBinary>>(DbType.Binary, "varbinary", "0x01", new byte[] { 1 });
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatementImage()
        {
            ParseParameterisedSqlStatementByteArray<Nullable<SqlBinary>>(DbType.Binary, "image", "0x01", new byte[] { 1 });
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatementTimestamp()
        {
            ParseParameterisedSqlStatementByteArray<Nullable<SqlBinary>>(DbType.Binary, "timestamp", "0x01", new byte[] { 1 });
       }

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatementSqlVariantInt()
        {
            ParseParameterisedSqlStatement<Nullable<SqlInt64>, Int64>(DbType.Object, "sql_variant", "1", (Int64)1);
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatementSqlVariantDouble()
        {
            ParseParameterisedSqlStatement<Nullable<SqlDouble>, Double>(DbType.Object, "sql_variant", "1.1", (double)1.1);
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatementSqlVariantString()
        {
            ParseParameterisedSqlStatement<Nullable<SqlString>, String>(DbType.Object, "sql_variant", "'abc'", "abc");
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatementSqlVariantBinary()
        {
            ParseParameterisedSqlStatementByteArray<Nullable<SqlBinary>>(DbType.Object, "sql_variant", "0x010203", new byte[] { 1, 2, 3 });
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatementSqlVariantBinaryEmpty()
        {
            ParseParameterisedSqlStatementByteArray<Nullable<SqlBinary>>(DbType.Object, "sql_variant", "0x", new byte[] { });
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatementUniqueIdentifier1()
        {
            ParseParameterisedSqlStatement<Nullable<SqlGuid>, Guid>(DbType.Guid, "uniqueidentifier", "'6F9619FF-8B86-D011-B42D-00C04FC964FF'", new Guid("6F9619FF-8B86-D011-B42D-00C04FC964FF"));
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatementUniqueIdentifier2()
        {
            ParseParameterisedSqlStatement<Nullable<SqlGuid>, Guid>(DbType.Guid, "uniqueidentifier", "0xff19966f868b11d0b42d00c04fc964ff", new Guid("ff19966f868b11d0b42d00c04fc964ff"));
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatementNullParameterValue()
        {
            SqlParser p = new SqlParser();
            ParsedSqlCommand cmd = p.ParseTraceRecord(CreateRpcRecord("exec sp_executesql N'INSERT Scratch (Id,MyData) VALUES (@Id,@Data)',N'@Id int',@Id=null"));
            Assert.IsTrue(((SqlInt32)cmd.Parameters[0].Value).IsNull);
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatementNonNullParameterValue()
        {
            SqlParser p = new SqlParser();
            ParsedSqlCommand cmd = p.ParseTraceRecord(CreateRpcRecord("exec sp_executesql N'INSERT Scratch (Id,MyData) VALUES (@Id,@Data)',N'@Id int',@Id=1"));
            Assert.IsNotNull(cmd.Parameters[0].Value);
        }

        #endregion

        #region ParseParameterisedStoredProcedure selected types

        [TestMethod]
        public void SqlParser_ParseParameterisedStoredProcedureInt()
        {
            ParseParameterisedStoredProcedure<Nullable<SqlInt64>, Int64>("123", (Int64)123);
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedStoredProcedureDecimal()
        {
            ParseParameterisedStoredProcedure<Nullable<SqlDouble>, Double>("12.3", (Double)12.3);
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedStoredProcedureFloat()
        {
            ParseParameterisedStoredProcedure<Nullable<SqlDouble>, Double>("1000000000000000000000", (Double)1E21);
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedStoredProcedureBinary()
        {
            ParseParameterisedStoredProcedureByteArray("0x01FF", new byte[] { 1, 255 });
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedStoredProcedureBinaryEmpty()
        {
            ParseParameterisedStoredProcedureByteArray("0x", new byte[] { });
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedStoredProcedureNullParameterValue()
        {
            SqlParser p = new SqlParser();
            ParsedSqlCommand cmd = p.ParseTraceRecord(CreateRpcRecord("exec p_test @Id=null"));
            Assert.AreSame(DBNull.Value, cmd.Parameters[0].Value);
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedStoredProcedureMissingParameterValue()
        {
            SqlParser p = new SqlParser();
            ParsedSqlCommand cmd = p.ParseTraceRecord(CreateRpcRecord("exec p_test @Id=default"));
            Assert.IsNull(cmd.Parameters[0].Value);
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedStoredProcedureNullParameterValueUppercase()
        {
            SqlParser p = new SqlParser();
            ParsedSqlCommand cmd = p.ParseTraceRecord(CreateRpcRecord("exec p_test @Id=NULL"));
            Assert.AreSame(DBNull.Value, cmd.Parameters[0].Value);
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedStoredProcedureNonNullParameterValue()
        {
            SqlParser p = new SqlParser();
            ParsedSqlCommand cmd = p.ParseTraceRecord(CreateRpcRecord("exec p_test @Id=1"));
            Assert.IsNotNull(cmd.Parameters[0].Value);
        }

        #endregion

        #region ParseParameterisedStoredProcedure with output parameters of various types

        [TestMethod]
        public void SqlParser_ParseParameterisedStoredProcedureBigIntOutput()
        {
            ParseParameterisedStoredProcedureOutput<Nullable<SqlInt64>, SqlInt64>(DbType.Int64, "bigint");
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedStoredProcedureIntOutput()
        {
            ParseParameterisedStoredProcedureOutput<Nullable<SqlInt32>, SqlInt32>(DbType.Int32, "int");
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedStoredProcedureSmallintOutput()
        {
            ParseParameterisedStoredProcedureOutput<Nullable<SqlInt16>, SqlInt16>(DbType.Int16, "smallint");
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedStoredProcedureTinyintOutput()
        {
            ParseParameterisedStoredProcedureOutput<Nullable<SqlByte>, SqlByte>(DbType.Byte, "tinyint");
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedStoredProcedureBitOutput()
        {
            ParseParameterisedStoredProcedureOutput<Nullable<SqlBoolean>, SqlBoolean>(DbType.Boolean, "bit");
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedStoredProcedureDecimalOutput()
        {
            ParseParameterisedStoredProcedureOutput<Nullable<SqlDecimal>, SqlDecimal>(DbType.Decimal, "decimal(10,2)");
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedStoredProcedureNumericOutput()
        {
            ParseParameterisedStoredProcedureOutput<Nullable<SqlDecimal>, SqlDecimal>(DbType.Decimal, "numeric(10,2)");
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedStoredProcedureMoneyOutput()
        {
            ParseParameterisedStoredProcedureOutput<Nullable<SqlDecimal>, SqlDecimal>(DbType.Decimal, "money");
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedStoredProcedureSmallMoneyOutput()
        {
            ParseParameterisedStoredProcedureOutput<Nullable<SqlDecimal>, SqlDecimal>(DbType.Decimal, "smallmoney");
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedStoredProcedureFloatOutput()
        {
            ParseParameterisedStoredProcedureOutput<Nullable<SqlDouble>, SqlDouble>(DbType.Double, "float");
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedStoredProcedureRealOutput()
        {
            ParseParameterisedStoredProcedureOutput<Nullable<SqlSingle>, SqlSingle>(DbType.Single, "real");
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedStoredProcedureDatetimeOutput()
        {
            ParseParameterisedStoredProcedureOutput<Nullable<SqlDateTime>, SqlDateTime>(DbType.DateTime, "datetime");
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedStoredProcedureSmalldatetimeOutput()
        {
            ParseParameterisedStoredProcedureOutput<Nullable<SqlDateTime>, SqlDateTime>(DbType.DateTime, "smalldatetime");
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedStoredProcedureCharOutput()
        {
            ParseParameterisedStoredProcedureOutput<Nullable<SqlString>, SqlString>(DbType.String, "char(10)");
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedStoredProcedureVarCharOutput()
        {
            ParseParameterisedStoredProcedureOutput<Nullable<SqlString>, SqlString>(DbType.String, "varchar(10)");
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedStoredProcedureTextOutput()
        {
            ParseParameterisedStoredProcedureOutput<Nullable<SqlString>, SqlString>(DbType.String, "text");
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedStoredProcedureNCharOutput()
        {
            ParseParameterisedStoredProcedureOutput<Nullable<SqlString>, SqlString>(DbType.String, "nchar(10)");
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedStoredProcedureNVarCharOutput()
        {
            ParseParameterisedStoredProcedureOutput<Nullable<SqlString>, SqlString>(DbType.String, "nvarchar(10)");
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedStoredProcedureNTextOutput()
        {
            ParseParameterisedStoredProcedureOutput<Nullable<SqlString>, SqlString>(DbType.String, "ntext");
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedStoredProcedureBinaryOutput()
        {
            ParseParameterisedStoredProcedureOutput<Nullable<SqlBinary>, SqlBinary>(DbType.Binary, "binary");
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedStoredProcedureVarBinaryOutput()
        {
            ParseParameterisedStoredProcedureOutput<Nullable<SqlBinary>, SqlBinary>(DbType.Binary, "varbinary");
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedStoredProcedureImageOutput()
        {
            ParseParameterisedStoredProcedureOutput<Nullable<SqlBinary>, SqlBinary>(DbType.Binary, "image");
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedStoredProcedureTimestampOutput()
        {
            ParseParameterisedStoredProcedureOutput<Nullable<SqlBinary>, SqlBinary>(DbType.Binary, "timestamp");
        }

        #endregion

        #region ParseParameterisedSqlStatement with outputs parameters of various types

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatementBigIntOutput()
        {
            ParseParameterisedSqlStatementOutput<Nullable<SqlInt64>, SqlInt64>(DbType.Int64, "bigint");
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatementIntOutput()
        {
            ParseParameterisedSqlStatementOutput<Nullable<SqlInt32>, SqlInt32>(DbType.Int32, "int");
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatementSmallintOutput()
        {
            ParseParameterisedSqlStatementOutput<Nullable<SqlInt16>, SqlInt16>(DbType.Int16, "smallint");
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatementTinyintOutput()
        {
            ParseParameterisedSqlStatementOutput<Nullable<SqlByte>, SqlByte>(DbType.Byte, "tinyint");
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatementBitOutput()
        {
            ParseParameterisedSqlStatementOutput<Nullable<SqlBoolean>, SqlBoolean>(DbType.Boolean, "bit");
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatementDecimalOutput()
        {
            ParseParameterisedSqlStatementOutput<Nullable<SqlDecimal>, SqlDecimal>(DbType.Decimal, "decimal(10,2)");
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatementNumericOutput()
        {
            ParseParameterisedSqlStatementOutput<Nullable<SqlDecimal>, SqlDecimal>(DbType.Decimal, "numeric(10,2)");
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatementMoneyOutput()
        {
            ParseParameterisedSqlStatementOutput<Nullable<SqlDecimal>, SqlDecimal>(DbType.Decimal, "money");
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatementSmallMoneyOutput()
        {
            ParseParameterisedSqlStatementOutput<Nullable<SqlDecimal>, SqlDecimal>(DbType.Decimal, "smallmoney");
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatementFloatOutput()
        {
            ParseParameterisedSqlStatementOutput<Nullable<SqlDouble>, SqlDouble>(DbType.Double, "float");
        }

        [TestMethod]
        public void SqlParser_ParseParameteriseSqlStatementRealOutput()
        {
            ParseParameterisedSqlStatementOutput<Nullable<SqlSingle>, SqlSingle>(DbType.Single, "real");
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatementDatetimeOutput()
        {
            ParseParameterisedSqlStatementOutput<Nullable<SqlDateTime>, SqlDateTime>(DbType.DateTime, "datetime");
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatementSmalldatetimeOutput()
        {
            ParseParameterisedSqlStatementOutput<Nullable<SqlDateTime>, SqlDateTime>(DbType.DateTime, "smalldatetime");
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatementCharOutput()
        {
            ParseParameterisedSqlStatementOutput<Nullable<SqlString>, SqlString>(DbType.String, "char(10)");
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatementVarCharOutput()
        {
            ParseParameterisedSqlStatementOutput<Nullable<SqlString>, SqlString>(DbType.String, "varchar(10)");
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatementTextOutput()
        {
            ParseParameterisedSqlStatementOutput<Nullable<SqlString>, SqlString>(DbType.String, "text");
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatementNCharOutput()
        {
            ParseParameterisedSqlStatementOutput<Nullable<SqlString>, SqlString>(DbType.String, "nchar(10)");
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatementNVarCharOutput()
        {
            ParseParameterisedSqlStatementOutput<Nullable<SqlString>, SqlString>(DbType.String, "nvarchar(10)");
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatementNTextOutput()
        {
            ParseParameterisedSqlStatementOutput<Nullable<SqlString>, SqlString>(DbType.String, "ntext");
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatementBinaryOutput()
        {
            ParseParameterisedSqlStatementOutput<Nullable<SqlBinary>, SqlBinary>(DbType.Binary, "binary");
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatementVarBinaryOutput()
        {
            ParseParameterisedSqlStatementOutput<Nullable<SqlBinary>, SqlBinary>(DbType.Binary, "varbinary");
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatementImageOutput()
        {
            ParseParameterisedSqlStatementOutput<Nullable<SqlBinary>, SqlBinary>(DbType.Binary, "image");
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedSqlStatementTimestampOutput()
        {
            ParseParameterisedSqlStatementOutput<Nullable<SqlBinary>, SqlBinary>(DbType.Binary, "timestamp");
        }

        #endregion

        #region Positionality tests

        [TestMethod]
        public void SqlParser_ParseSqlStatementWithNamedInputParametersCheckParametersNotPositional()
        {
            SqlParser p = new SqlParser();
            ParsedSqlCommand cmd = p.ParseTraceRecord(CreateRpcRecord("exec sp_executesql N'dummy',N'@Id int,@Data nvarchar(5),@Id2 int,@Data2 nvarchar(6)',@Id=1,@Data=N'param',@Id2=2,@Data2=N'param2'"));
            Assert.IsFalse(cmd.Parameters[0].Positional);
            Assert.IsFalse(cmd.Parameters[1].Positional);
            Assert.IsFalse(cmd.Parameters[2].Positional);
            Assert.IsFalse(cmd.Parameters[3].Positional);
        }

        [TestMethod]
        public void SqlParser_ParseSqlStatementWithNamedOutputParametersCheckParametersNotPositional()
        {
            SqlParser p = new SqlParser();
            ParsedSqlCommand cmd = p.ParseTraceRecord(CreateRpcRecord("exec sp_executesql N'dummy',N'@Id int output,@Data nvarchar(5) output',@Id=1,@Data=N'param'"));
            Assert.IsFalse(cmd.Parameters[0].Positional);
            Assert.IsFalse(cmd.Parameters[1].Positional);
        }

        [TestMethod]
        public void SqlParser_ParseStoredProcedureWithNamedInputParametersCheckParametersNotPositional()
        {
            SqlParser p = new SqlParser();
            ParsedSqlCommand cmd = p.ParseTraceRecord(CreateRpcRecord("exec [p_InsertScratch] @Id=1,@Data=N'param'"));
            Assert.IsFalse(cmd.Parameters[0].Positional);
            Assert.IsFalse(cmd.Parameters[1].Positional);
        }

        [TestMethod]
        public void SqlParser_ParseStoredProcedureWithNamedOutputParametersCheckParametersNotPositional()
        {
            SqlParser p = new SqlParser();
            ParsedSqlCommand cmd = p.ParseTraceRecord(CreateRpcRecord(@"
declare @p1 int
set @p1=NULL
declare @p2 int
set @p2=NULL
exec [p_OutParameter] @ap1=@p1 output,@ap2=@p2 output
select @p1, @p2"));
            Assert.IsFalse(cmd.Parameters[0].Positional);
            Assert.IsFalse(cmd.Parameters[1].Positional);
        }

        [TestMethod]
        public void SqlParser_ParseStoredProcedureWithPositionalParametersCheckParametersArePositional()
        {
            SqlParser p = new SqlParser();
            ParsedSqlCommand cmd = p.ParseTraceRecord(CreateRpcRecord("exec p_Test NULL, N'abc'"));
            Assert.IsTrue(cmd.Parameters[0].Positional);
            Assert.IsTrue(cmd.Parameters[1].Positional);
        }

        [TestMethod]
        public void SqlParser_ParseStoredProcedureWithMixedNamedAndPositionalParametersCheckParameterPositionality()
        {
            SqlParser p = new SqlParser();
            ParsedSqlCommand cmd = p.ParseTraceRecord(CreateRpcRecord("exec p_Test 123,@n1=456,N'234',@n2=N'dfg'"));

            Assert.IsTrue(cmd.Parameters[0].Positional);
            Assert.IsFalse(cmd.Parameters[1].Positional);
            Assert.IsTrue(cmd.Parameters[2].Positional);
            Assert.IsFalse(cmd.Parameters[3].Positional);
        }

        [TestMethod]
        public void SqlParser_ParseStoredProcedureWithMixedNamedAndPositionalOutputParametersCheckParameterPositionality()
        {
            SqlParser p = new SqlParser();
            ParsedSqlCommand cmd = p.ParseTraceRecord(CreateRpcRecord(@"
declare @p1 int
set @p1=0
declare @p3 int
set @p3=8
exec dummy @p1 output,N'temp',@p3 output,NULL
select @p1, @p3"));

            Assert.IsFalse(cmd.Parameters[0].Positional);
            Assert.IsTrue(cmd.Parameters[1].Positional);
            Assert.IsFalse(cmd.Parameters[2].Positional);
            Assert.IsTrue(cmd.Parameters[3].Positional);
        }

        #endregion

        [TestMethod]
        public void SqlParser_ParseStoredProcedureCallNoParameters()
        {
            SqlParser p = new SqlParser();
            ParsedSqlCommand cmd = p.ParseTraceRecord(CreateRpcRecord("exec [p_NoParameters] "));
            Assert.AreEqual<string>("[p_NoParameters]", cmd.CommandText);
            Assert.AreEqual<CommandType>(CommandType.StoredProcedure, cmd.CommandType);
            Assert.AreEqual<int>(0, cmd.Parameters.Count);
        }

        [TestMethod]
        public void SqlParser_ParseStoredProcedureCallNoParametersWithDboInName()
        {
            SqlParser p = new SqlParser();
            ParsedSqlCommand cmd = p.ParseTraceRecord(CreateRpcRecord("exec [dbo].[p_NoParameters] "));
            Assert.AreEqual<string>("[dbo].[p_NoParameters]", cmd.CommandText);
            Assert.AreEqual<CommandType>(CommandType.StoredProcedure, cmd.CommandType);
            Assert.AreEqual<int>(0, cmd.Parameters.Count);
        }

        [TestMethod]
        public void SqlParser_ParseStoredProcedureCall()
        {
            SqlParser p = new SqlParser();
            ParsedSqlCommand cmd = p.ParseTraceRecord(CreateRpcRecord("exec [p_InsertScratch] @Id=1,@Data=N'param'"));
            Assert.AreEqual<string>("[p_InsertScratch]", cmd.CommandText);
            Assert.AreEqual<CommandType>(CommandType.StoredProcedure, cmd.CommandType);

            Assert.AreEqual<int>(2, cmd.Parameters.Count);

            Assert.AreEqual<string>("@Id", cmd.Parameters[0].Name);
            Assert.AreEqual<DbType>(DbType.Object, cmd.Parameters[0].Type);
            Assert.AreEqual<Int64>(1, (Int64)cmd.Parameters[0].Value);
            Assert.AreEqual<ParameterDirection>(ParameterDirection.Input, cmd.Parameters[0].Direction);

            Assert.AreEqual<string>("@Data", cmd.Parameters[1].Name);
            Assert.AreEqual<DbType>(DbType.Object, cmd.Parameters[1].Type);
            Assert.AreEqual<string>("param", (string)cmd.Parameters[1].Value);
            Assert.AreEqual<ParameterDirection>(ParameterDirection.Input, cmd.Parameters[1].Direction);
        }

        [TestMethod]
        public void SqlParser_ParseStoredProcedureCallWithOutputParameters()
        {
            SqlParser p = new SqlParser();
            ParsedSqlCommand cmd = p.ParseTraceRecord(CreateRpcRecord(@"
declare @p1 int
set @p1=NULL
declare @p2 int
set @p2=NULL
exec [p_OutParameter] @ap1=@p1 output,@ap2=@p2 output
select @p1, @p2"));
            Assert.AreEqual<string>("[p_OutParameter]", cmd.CommandText);
            Assert.AreEqual<CommandType>(CommandType.StoredProcedure, cmd.CommandType);

            Assert.AreEqual<int>(2, cmd.Parameters.Count);

            Assert.AreEqual<string>("@ap1", cmd.Parameters[0].Name);
            Assert.AreEqual<DbType>(DbType.Int32, cmd.Parameters[0].Type);
            Assert.IsTrue(((SqlInt32)cmd.Parameters[0].Value).IsNull);
            Assert.AreEqual<ParameterDirection>(ParameterDirection.Output, cmd.Parameters[0].Direction);

            Assert.AreEqual<string>("@ap2", cmd.Parameters[1].Name);
            Assert.AreEqual<DbType>(DbType.Int32, cmd.Parameters[1].Type);
            Assert.IsTrue(((SqlInt32)cmd.Parameters[1].Value).IsNull);
            Assert.AreEqual<ParameterDirection>(ParameterDirection.Output, cmd.Parameters[1].Direction);
        }

        [TestMethod]
        public void SqlParser_ParseStoredProcedureCallWithInputOutputParametersInitialisedToNonNullValue()
        {
            SqlParser p = new SqlParser();
            ParsedSqlCommand cmd = p.ParseTraceRecord(CreateRpcRecord(@"
declare @p1 int
set @p1=2
declare @p2 int
set @p2=5
exec [p_OutParameter] @ap1=@p1 output,@ap2=@p2 output
select @p1, @p2"));
            Assert.AreEqual<string>("[p_OutParameter]", cmd.CommandText);
            Assert.AreEqual<CommandType>(CommandType.StoredProcedure, cmd.CommandType);

            Assert.AreEqual<int>(2, cmd.Parameters.Count);

            Assert.AreEqual<string>("@ap1", cmd.Parameters[0].Name);
            Assert.AreEqual<DbType>(DbType.Int32, cmd.Parameters[0].Type);
            Assert.AreEqual<int>(2, (int)cmd.Parameters[0].Value);
            Assert.AreEqual<ParameterDirection>(ParameterDirection.InputOutput, cmd.Parameters[0].Direction);

            Assert.AreEqual<string>("@ap2", cmd.Parameters[1].Name);
            Assert.AreEqual<DbType>(DbType.Int32, cmd.Parameters[1].Type);
            Assert.AreEqual<int>(5, (int)cmd.Parameters[1].Value);
            Assert.AreEqual<ParameterDirection>(ParameterDirection.InputOutput, cmd.Parameters[1].Direction);
        }

        [TestMethod]
        public void SqlParser_ParseStoredProcedureCallWithInputOutputParametersInitialisedToNullValue()
        {
            SqlParser p = new SqlParser();
            ParsedSqlCommand cmd = p.ParseTraceRecord(CreateRpcRecord(@"
declare @p1 int
set @p1=default
declare @p2 int
set @p2=default
exec [p_OutParameter] @ap1=@p1 output,@ap2=@p2 output
select @p1, @p2"));
            Assert.AreEqual<string>("[p_OutParameter]", cmd.CommandText);
            Assert.AreEqual<CommandType>(CommandType.StoredProcedure, cmd.CommandType);

            Assert.AreEqual<int>(2, cmd.Parameters.Count);

            Assert.AreEqual<string>("@ap1", cmd.Parameters[0].Name);
            Assert.AreEqual<DbType>(DbType.Int32, cmd.Parameters[0].Type);
            Assert.IsNull(cmd.Parameters[0].Value);
            Assert.AreEqual<ParameterDirection>(ParameterDirection.InputOutput, cmd.Parameters[0].Direction);

            Assert.AreEqual<string>("@ap2", cmd.Parameters[1].Name);
            Assert.AreEqual<DbType>(DbType.Int32, cmd.Parameters[1].Type);
            Assert.IsNull(cmd.Parameters[1].Value);
            Assert.AreEqual<ParameterDirection>(ParameterDirection.InputOutput, cmd.Parameters[1].Direction);
        }

        [TestMethod]
        public void SqlParser_ParseSqlStatementWithOutputParameters()
        {
            SqlParser p = new SqlParser();
            ParsedSqlCommand cmd = p.ParseTraceRecord(CreateRpcRecord(@"
declare @p3 int
set @p3=NULL
declare @p4 int
set @p4=NULL
exec sp_executesql N'SELECT @p=COUNT(*), @p2=2 FROM Scratch',N'@p int output,@p2 int output',@p=@p3 output,@p2=@p4 output
select @p3, @p4"));
            Assert.AreEqual<string>("SELECT @p=COUNT(*), @p2=2 FROM Scratch", cmd.CommandText);
            Assert.AreEqual<CommandType>(CommandType.Text, cmd.CommandType);

            Assert.AreEqual<int>(2, cmd.Parameters.Count);

            Assert.AreEqual<string>("@p", cmd.Parameters[0].Name);
            Assert.AreEqual<DbType>(DbType.Int32, cmd.Parameters[0].Type);
            Assert.IsTrue(((SqlInt32)cmd.Parameters[0].Value).IsNull);
            Assert.AreEqual<ParameterDirection>(ParameterDirection.Output, cmd.Parameters[0].Direction);

            Assert.AreEqual<string>("@p2", cmd.Parameters[1].Name);
            Assert.AreEqual<DbType>(DbType.Int32, cmd.Parameters[1].Type);
            Assert.IsTrue(((SqlInt32)cmd.Parameters[1].Value).IsNull);
            Assert.AreEqual<ParameterDirection>(ParameterDirection.Output, cmd.Parameters[1].Direction);
        }

        [TestMethod]
        public void SqlParser_ParseSqlStatementWithInputOutputParametersInitialisedToNonNullValue()
        {
            SqlParser p = new SqlParser();
            ParsedSqlCommand cmd = p.ParseTraceRecord(CreateRpcRecord(@"
declare @p3 int
set @p3=3
declare @p4 int
set @p4=6
exec sp_executesql N'SELECT @p=COUNT(*), @p2=2 FROM Scratch',N'@p int output,@p2 int output',@p=@p3 output,@p2=@p4 output
select @p3, @p4"));
            Assert.AreEqual<string>("SELECT @p=COUNT(*), @p2=2 FROM Scratch", cmd.CommandText);
            Assert.AreEqual<CommandType>(CommandType.Text, cmd.CommandType);

            Assert.AreEqual<int>(2, cmd.Parameters.Count);

            Assert.AreEqual<string>("@p", cmd.Parameters[0].Name);
            Assert.AreEqual<DbType>(DbType.Int32, cmd.Parameters[0].Type);
            Assert.AreEqual<int>(3, (int)cmd.Parameters[0].Value);
            Assert.AreEqual<ParameterDirection>(ParameterDirection.InputOutput, cmd.Parameters[0].Direction);

            Assert.AreEqual<string>("@p2", cmd.Parameters[1].Name);
            Assert.AreEqual<DbType>(DbType.Int32, cmd.Parameters[1].Type);
            Assert.AreEqual<int>(6, (int)cmd.Parameters[1].Value);
            Assert.AreEqual<ParameterDirection>(ParameterDirection.InputOutput, cmd.Parameters[1].Direction);
        }

        [TestMethod]
        public void SqlParser_ParseSqlStatementWithInputOutputParametersInitialisedToNullValue()
        {
            SqlParser p = new SqlParser();
            ParsedSqlCommand cmd = p.ParseTraceRecord(CreateRpcRecord(@"
declare @p3 int
set @p3=default
declare @p4 int
set @p4=default
exec sp_executesql N'SELECT @p=COUNT(*), @p2=2 FROM Scratch',N'@p int output,@p2 int output',@p=@p3 output,@p2=@p4 output
select @p3, @p4"));
            Assert.AreEqual<string>("SELECT @p=COUNT(*), @p2=2 FROM Scratch", cmd.CommandText);
            Assert.AreEqual<CommandType>(CommandType.Text, cmd.CommandType);

            Assert.AreEqual<int>(2, cmd.Parameters.Count);

            Assert.AreEqual<string>("@p", cmd.Parameters[0].Name);
            Assert.AreEqual<DbType>(DbType.Int32, cmd.Parameters[0].Type);
            Assert.IsNull(cmd.Parameters[0].Value);
            Assert.AreEqual<ParameterDirection>(ParameterDirection.InputOutput, cmd.Parameters[0].Direction);

            Assert.AreEqual<string>("@p2", cmd.Parameters[1].Name);
            Assert.AreEqual<DbType>(DbType.Int32, cmd.Parameters[1].Type);
            Assert.IsNull(cmd.Parameters[1].Value);
            Assert.AreEqual<ParameterDirection>(ParameterDirection.InputOutput, cmd.Parameters[1].Direction);
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedStoredProcedureWithPositionalParameterNullValue()
        {
            SqlParser p = new SqlParser();
            ParsedSqlCommand cmd = p.ParseTraceRecord(CreateRpcRecord("exec p_Test NULL"));
            Assert.AreEqual<int>(1, cmd.Parameters.Count);
            Assert.AreEqual<string>("@p1", cmd.Parameters[0].Name);
            Assert.AreEqual<DbType>(DbType.Object, cmd.Parameters[0].Type);
            Assert.AreSame(DBNull.Value, cmd.Parameters[0].Value);
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedStoredProcedureWithPositionalParameterString()
        {
            SqlParser p = new SqlParser();
            ParsedSqlCommand cmd = p.ParseTraceRecord(CreateRpcRecord("exec p_Test N'abc'"));
            Assert.AreEqual<int>(1, cmd.Parameters.Count);
            Assert.AreEqual<string>("@p1", cmd.Parameters[0].Name);
            Assert.AreEqual<DbType>(DbType.Object, cmd.Parameters[0].Type);
            Assert.AreEqual<string>("abc", (string)cmd.Parameters[0].Value);
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedStoredProcedureWithPositionalParameterInt64()
        {
            SqlParser p = new SqlParser();
            ParsedSqlCommand cmd = p.ParseTraceRecord(CreateRpcRecord("exec p_Test 123"));
            Assert.AreEqual<int>(1, cmd.Parameters.Count);
            Assert.AreEqual<string>("@p1", cmd.Parameters[0].Name);
            Assert.AreEqual<DbType>(DbType.Object, cmd.Parameters[0].Type);
            Assert.AreEqual<Int64>(123, (Int64)cmd.Parameters[0].Value);
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedStoredProcedureWithPositionalParameterDouble()
        {
            SqlParser p = new SqlParser();
            ParsedSqlCommand cmd = p.ParseTraceRecord(CreateRpcRecord("exec p_Test 123.0"));
            Assert.AreEqual<int>(1, cmd.Parameters.Count);
            Assert.AreEqual<string>("@p1", cmd.Parameters[0].Name);
            Assert.AreEqual<DbType>(DbType.Object, cmd.Parameters[0].Type);
            Assert.AreEqual<Double>(123, (Double)cmd.Parameters[0].Value);
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedStoredProcedureWithPositionalParameterBinary()
        {
            SqlParser p = new SqlParser();
            ParsedSqlCommand cmd = p.ParseTraceRecord(CreateRpcRecord("exec p_Test 0x0001"));
            Assert.AreEqual<int>(1, cmd.Parameters.Count);
            Assert.AreEqual<string>("@p1", cmd.Parameters[0].Name);
            Assert.AreEqual<DbType>(DbType.Object, cmd.Parameters[0].Type);
            CompareByteArray(new Byte[] { 0, 1 }, (Byte[])cmd.Parameters[0].Value);
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedStoredProcedureWithTwoPositionalParameters()
        {
            SqlParser p = new SqlParser();
            ParsedSqlCommand cmd = p.ParseTraceRecord(CreateRpcRecord("exec p_Test 123,456"));
            Assert.AreEqual<int>(2, cmd.Parameters.Count);
            Assert.AreEqual<string>("@p1", cmd.Parameters[0].Name);
            Assert.AreEqual<DbType>(DbType.Object, cmd.Parameters[0].Type);
            Assert.AreEqual<Int64>(123, (Int64)cmd.Parameters[0].Value);
            Assert.AreEqual<string>("@p2", cmd.Parameters[1].Name);
            Assert.AreEqual<DbType>(DbType.Object, cmd.Parameters[1].Type);
            Assert.AreEqual<Int64>(456, (Int64)cmd.Parameters[1].Value);
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedStoredProcedureWithMixedNamedAndPositionalParameters()
        {
            SqlParser p = new SqlParser();
            ParsedSqlCommand cmd = p.ParseTraceRecord(CreateRpcRecord("exec p_Test 123,@n1=456,N'234',@n2=N'dfg'"));
            Assert.AreEqual<int>(4, cmd.Parameters.Count);

            Assert.AreEqual<string>("@p1", cmd.Parameters[0].Name);
            Assert.AreEqual<DbType>(DbType.Object, cmd.Parameters[0].Type);
            Assert.AreEqual<Int64>(123, (Int64)cmd.Parameters[0].Value);
            Assert.IsTrue(cmd.Parameters[0].Positional);

            Assert.AreEqual<string>("@n1", cmd.Parameters[1].Name);
            Assert.AreEqual<DbType>(DbType.Object, cmd.Parameters[1].Type);
            Assert.AreEqual<Int64>(456, (Int64)cmd.Parameters[1].Value);
            Assert.IsFalse(cmd.Parameters[1].Positional);

            Assert.AreEqual<string>("@p3", cmd.Parameters[2].Name);
            Assert.AreEqual<DbType>(DbType.Object, cmd.Parameters[2].Type);
            Assert.AreEqual<string>("234", (string)cmd.Parameters[2].Value);
            Assert.IsTrue(cmd.Parameters[2].Positional);

            Assert.AreEqual<string>("@n2", cmd.Parameters[3].Name);
            Assert.AreEqual<DbType>(DbType.Object, cmd.Parameters[3].Type);
            Assert.AreEqual<string>("dfg", (string)cmd.Parameters[3].Value);
            Assert.IsFalse(cmd.Parameters[3].Positional);
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedStoredProcedureWithOuputParametersInitialisedOnlyBeforeTheCall()
        {
            SqlParser p = new SqlParser();
            ParsedSqlCommand cmd = p.ParseTraceRecord(CreateRpcRecord(@"
declare @p1 int
set @p1=0
declare @p2 int
set @p2=8
exec sp_test @p1 output,@p2 output
select @p1, @p2"));
            Assert.AreEqual<int>(2, cmd.Parameters.Count);

            Assert.AreEqual<string>("@p1", cmd.Parameters[0].Name);
            Assert.AreEqual<DbType>(DbType.Int32, cmd.Parameters[0].Type);
            Assert.AreEqual<int>(0, (int)cmd.Parameters[0].Value);
            Assert.AreEqual<ParameterDirection>(ParameterDirection.Output, cmd.Parameters[0].Direction);

            Assert.AreEqual<string>("@p2", cmd.Parameters[1].Name);
            Assert.AreEqual<DbType>(DbType.Int32, cmd.Parameters[1].Type);
            Assert.AreEqual<int>(8, (int)cmd.Parameters[1].Value);
            Assert.AreEqual<ParameterDirection>(ParameterDirection.Output, cmd.Parameters[1].Direction);
        }

        [TestMethod]
        public void SqlParser_ParseParameterisedStoredProcedureWithMixedNamedAndPositionalOutputParameters()
        {
            SqlParser p = new SqlParser();
            ParsedSqlCommand cmd = p.ParseTraceRecord(CreateRpcRecord(@"
declare @p1 int
set @p1=0
declare @p3 int
set @p3=8
exec dummy @p1 output,N'temp',@p3 output,NULL
select @p1, @p3"));
            Assert.AreEqual<int>(4, cmd.Parameters.Count);

            Assert.AreEqual<string>("@p1", cmd.Parameters[0].Name);
            Assert.AreEqual<DbType>(DbType.Int32, cmd.Parameters[0].Type);
            Assert.AreEqual<int>(0, (int)cmd.Parameters[0].Value);
            Assert.AreEqual<ParameterDirection>(ParameterDirection.Output, cmd.Parameters[0].Direction);

            Assert.AreEqual<string>("@p2", cmd.Parameters[1].Name);
            Assert.AreEqual<DbType>(DbType.Object, cmd.Parameters[1].Type);
            Assert.AreEqual<string>("temp", (string)cmd.Parameters[1].Value);
            Assert.AreEqual<ParameterDirection>(ParameterDirection.Input, cmd.Parameters[1].Direction);

            Assert.AreEqual<string>("@p3", cmd.Parameters[2].Name);
            Assert.AreEqual<DbType>(DbType.Int32, cmd.Parameters[2].Type);
            Assert.AreEqual<int>(8, (int)cmd.Parameters[2].Value);
            Assert.AreEqual<ParameterDirection>(ParameterDirection.Output, cmd.Parameters[2].Direction);

            Assert.AreEqual<string>("@p4", cmd.Parameters[3].Name);
            Assert.AreEqual<DbType>(DbType.Object, cmd.Parameters[3].Type);
            Assert.AreSame(DBNull.Value, cmd.Parameters[3].Value);
            Assert.AreEqual<ParameterDirection>(ParameterDirection.Input, cmd.Parameters[3].Direction);
        }

        [TestMethod]
        public void SqlParser_BatchStartingToParsedSqlCommandMakesNoChangesToSqlCommand()
        {
            SqlParser p = new SqlParser();
            string cmdText = "INSERT Scratch (Id,MyData) VALUES (1,'insert1'); INSERT Scratch (Id,MyData) VALUES (2,'insert2')";
            ParsedSqlCommand cmd = p.ParseTraceRecord(CreateSqlRecord(cmdText));
            Assert.AreEqual<string>(cmdText, cmd.CommandText);
            Assert.AreEqual<CommandType>(CommandType.Text, cmd.CommandType);
            Assert.AreEqual<int>(0, cmd.Parameters.Count);
        }

        [TestMethod]
        public void SqlParser_BatchStartingToParsedSqlCommandMakesNoChangesToSqlCommandNotEvenExecCommand()
        {
            SqlParser p = new SqlParser();
            string cmdText = "exec p_InsertScratch 1, 'sp'";
            ParsedSqlCommand cmd = p.ParseTraceRecord(CreateSqlRecord(cmdText));
            Assert.AreEqual<string>(cmdText, cmd.CommandText);
            Assert.AreEqual<CommandType>(CommandType.Text, cmd.CommandType);
            Assert.AreEqual<int>(0, cmd.Parameters.Count);
        }

        [TestMethod]
        public void SqlParser_RpcStartingToParsedSqlCommand()
        {
            SqlParser p = new SqlParser();
            ParsedSqlCommand cmd = p.ParseTraceRecord(CreateRpcRecord("exec dummy"));
            Assert.AreEqual<string>("dummy", cmd.CommandText);
            Assert.AreEqual<CommandType>(CommandType.StoredProcedure, cmd.CommandType);
            Assert.AreEqual<int>(0, cmd.Parameters.Count);
        }

        [TestMethod]
        public void SqlParser_RpcCommentTurnedIntoUnparameterisedSql()
        {
            // This can occur if sp_setapprole is called
            SqlParser p = new SqlParser();
            ParsedSqlCommand cmd = p.ParseTraceRecord(CreateRpcRecord("-- some comment"));
            Assert.AreEqual<string>("-- some comment", cmd.CommandText);
            Assert.AreEqual<CommandType>(CommandType.Text, cmd.CommandType);
            Assert.AreEqual<int>(0, cmd.Parameters.Count);
        }

        private static void ParseParameterisedSqlStatement<ST, NT>(DbType dbtype, string sqlType, string stringValue, object expectedValue)
        {
            SqlParser p = new SqlParser();
            ParsedSqlCommand cmd = p.ParseTraceRecord(CreateRpcRecord(string.Format(CultureInfo.InvariantCulture, "exec sp_executesql N'dummy',N'@p {0}',@p={1}", sqlType, stringValue)));
            Assert.AreEqual<DbType>(dbtype, cmd.Parameters[0].Type);
            Assert.IsInstanceOfType(cmd.Parameters[0].Value, typeof(NT));
            Assert.AreEqual<NT>((NT)expectedValue, (NT)cmd.Parameters[0].Value);
            Assert.AreEqual<Type>(typeof(ST), cmd.Parameters[0].NetType);
            Assert.AreEqual<ParameterDirection>(ParameterDirection.Input, cmd.Parameters[0].Direction);
        }

        private static void ParseParameterisedSqlStatementByteArray<ST>(DbType dbtype, string sqlType, string stringValue, byte[] expectedValue)
        {
            SqlParser p = new SqlParser();
            ParsedSqlCommand cmd = p.ParseTraceRecord(CreateRpcRecord(string.Format(CultureInfo.InvariantCulture, "exec sp_executesql N'dummy',N'@p {0}',@p={1}", sqlType, stringValue)));
            Assert.AreEqual<DbType>(dbtype, cmd.Parameters[0].Type);
            Assert.IsInstanceOfType(cmd.Parameters[0].Value, typeof(Byte[]));
            Assert.AreEqual<Type>(typeof(ST), cmd.Parameters[0].NetType);
            Assert.AreEqual<ParameterDirection>(ParameterDirection.Input, cmd.Parameters[0].Direction);
            CompareByteArray(expectedValue, (byte[])cmd.Parameters[0].Value);
        }

        private static void ParseParameterisedStoredProcedure<ST, NT>(string stringValue, object expectedValue)
        {
            SqlParser p = new SqlParser();
            ParsedSqlCommand cmd = p.ParseTraceRecord(CreateRpcRecord(string.Format(CultureInfo.InvariantCulture, "exec [p_test] @p={0}", stringValue)));
            Assert.AreEqual<DbType>(DbType.Object, cmd.Parameters[0].Type);
            Assert.AreEqual<NT>((NT)expectedValue, (NT)cmd.Parameters[0].Value);
            Assert.AreEqual<Type>(typeof(ST), cmd.Parameters[0].NetType);
            Assert.AreEqual<ParameterDirection>(ParameterDirection.Input, cmd.Parameters[0].Direction);
        }

        private static void ParseParameterisedStoredProcedureByteArray(string stringValue, byte[] expectedValue)
        {
            SqlParser p = new SqlParser();
            ParsedSqlCommand cmd = p.ParseTraceRecord(CreateRpcRecord(string.Format(CultureInfo.InvariantCulture, "exec [p_test] @p={0}", stringValue)));
            Assert.AreEqual<DbType>(DbType.Object, cmd.Parameters[0].Type);
            Assert.AreEqual<ParameterDirection>(ParameterDirection.Input, cmd.Parameters[0].Direction);
            CompareByteArray(expectedValue, (byte[])cmd.Parameters[0].Value);
        }

        private static void ParseParameterisedSqlStatementOutput<ST, NT>(DbType dbtype, string sqlType)
        {
            SqlParser p = new SqlParser();
            ParsedSqlCommand cmd = p.ParseTraceRecord(CreateRpcRecord(string.Format(CultureInfo.InvariantCulture, "declare @a1 {0} set @a1=null exec sp_executesql N'dummy',N'@p {0} output', @p=@a1 output select @p", sqlType)));
            Assert.AreEqual<DbType>(dbtype, cmd.Parameters[0].Type);
            Assert.IsInstanceOfType(cmd.Parameters[0].Value, typeof(NT));
            Assert.AreEqual<Type>(typeof(ST), cmd.Parameters[0].NetType);
            Assert.IsTrue(((INullable)cmd.Parameters[0].Value).IsNull);
            Assert.AreEqual<ParameterDirection>(ParameterDirection.Output, cmd.Parameters[0].Direction);
        }

        private static void ParseParameterisedStoredProcedureOutput<ST, NT>(DbType dbtype, string sqlType)
        {
            SqlParser p = new SqlParser();
            ParsedSqlCommand cmd = p.ParseTraceRecord(CreateRpcRecord(string.Format(CultureInfo.InvariantCulture, "declare @a1 {0} set @a1=null exec [p_Test] @p=@a1 output", sqlType)));
            Assert.AreEqual<DbType>(dbtype, cmd.Parameters[0].Type);
            Assert.IsInstanceOfType(cmd.Parameters[0].Value, typeof(NT));
            Assert.AreEqual<Type>(typeof(ST), cmd.Parameters[0].NetType);
            Assert.IsTrue(((INullable)cmd.Parameters[0].Value).IsNull);
            Assert.AreEqual<ParameterDirection>(ParameterDirection.Output, cmd.Parameters[0].Direction);
        }

        private static TraceRecord CreateRpcRecord(string sql)
        {
            TraceRecord ans = new TraceRecord(TraceRecord.RpcStartingEventClass, "test", sql, 1);
            return ans;
        }

        private static TraceRecord CreateSqlRecord(string sql)
        {
            TraceRecord ans = new TraceRecord(TraceRecord.SqlBatchStartingEventClass, "test", sql, 1);
            return ans;
        }

        private static void CompareByteArray(byte[] expected, byte[] actual)
        {
            Assert.AreEqual<int>(expected.Length, actual.Length);
            for (int i = 0; i < expected.Length; i++)
            {
                Assert.AreEqual<byte>(expected[i], actual[i]);
            }
        }
    }
}
