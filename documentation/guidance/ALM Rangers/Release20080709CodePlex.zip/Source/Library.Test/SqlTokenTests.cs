//---------------------------------------------------------------------
// <copyright file="SqlTokenTests.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
//     THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
//     OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
//     LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//     FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>The SqlTokenTests type.</summary>
//---------------------------------------------------------------------

namespace Microsoft.DatabaseLoadTest.Library.Test
{
    using System;
    using System.Data;
    using System.Text;
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    using Microsoft.DatabaseLoadTest.Library;

    [TestClass]
    public class SqlTokenTests
    {
        private SqlToken a1 = new SqlToken(SqlTokenType.Word, "A");
        private SqlToken a2 = new SqlToken(SqlTokenType.Word, "A");
        private SqlToken b = new SqlToken(SqlTokenType.Word, "B");
        private SqlToken c = new SqlToken(SqlTokenType.Variable, "A");
        private SqlToken l = new SqlToken(SqlTokenType.Word, "a");

        [TestMethod]
        public void SqlToken_NullIsNotEqual()
        {
            Assert.IsFalse(this.a1.Equals(null));
        }

        [TestMethod]
        public void SqlToken_StringIsNotEqual()
        {
            Assert.IsFalse(this.a1.Equals("A"));
        }

        [TestMethod]
        public void SqlToken_SameValueIsEqual()
        {
            Assert.IsTrue(this.a1.Equals(this.a2));
            Assert.AreEqual(this.a1, this.a2);
            Assert.AreEqual<SqlToken>(this.a1, this.a2);

            Assert.IsTrue(this.a2.Equals(this.a1));
            Assert.AreEqual(this.a2, this.a1);
            Assert.AreEqual<SqlToken>(this.a2, this.a1);

            Assert.AreEqual<int>(this.a1.GetHashCode(), this.a2.GetHashCode());
        }

        [TestMethod]
        public void SqlToken_SameValueDifferentCaseIsEqual()
        {
            Assert.IsTrue(this.a1.Equals(this.l));
            Assert.AreEqual(this.a1, this.l);
            Assert.AreEqual<SqlToken>(this.a1, this.l);

            Assert.IsTrue(this.l.Equals(this.a1));
            Assert.AreEqual(this.l, this.a1);
            Assert.AreEqual<SqlToken>(this.l, this.a1);

            Assert.AreEqual<int>(this.a1.GetHashCode(), this.l.GetHashCode());
        }

        [TestMethod]
        public void SqlToken_EqualToSelf()
        {
            Assert.IsTrue(this.a1.Equals(this.a1));
            Assert.AreEqual(this.a1, this.a1);
            Assert.AreEqual<SqlToken>(this.a1, this.a1);
            Assert.AreEqual<int>(this.a1.GetHashCode(), this.a1.GetHashCode());
        }

        [TestMethod]
        public void SqlToken_DifferentTokenTypeNotEqual()
        {
            Assert.IsFalse(this.a1.Equals(this.c));
            Assert.AreNotEqual(this.a1, this.c);
            Assert.AreNotEqual<SqlToken>(this.a1, this.c);
            Assert.AreNotEqual<int>(this.a1.GetHashCode(), this.c.GetHashCode());
        }

        [TestMethod]
        public void SqlToken_DifferentValueNotEqual()
        {
            Assert.IsFalse(this.a1.Equals(this.b));
            Assert.AreNotEqual(this.a1, this.b);
            Assert.AreNotEqual<SqlToken>(this.a1, this.b);
            Assert.AreNotEqual<int>(this.a1.GetHashCode(), this.b.GetHashCode());
        }
    }
}
