//---------------------------------------------------------------------
// <copyright file="SqlTokenizerTests.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
//     THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
//     OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
//     LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//     FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>The SqlTokenizerTests type.</summary>
//---------------------------------------------------------------------

namespace Microsoft.DatabaseLoadTest.Library.Test
{
    using System;
    using System.Data;
    using System.Text;
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    using Microsoft.DatabaseLoadTest.Library;

    [TestClass]
    public class SqlTokenizerTests
    {
        [TestMethod]
        public void SqlTokenizer_NullStringThrowsException()
        {
            TestHelper.TestForArgumentNullException(
                "sql",
                delegate()
                {
                    SqlTokenizer t = new SqlTokenizer(null);
                });
        }

        [TestMethod]
        public void SqlTokenizer_EmptyStringReturnsNull()
        {
            SqlTokenizer t = new SqlTokenizer("");
            Assert.IsNull(t.ParseNextToken());
        }

        [TestMethod]
        public void SqlTokenizer_BlankStringReturnsNull()
        {
            SqlTokenizer t = new SqlTokenizer("       ");
            Assert.IsNull(t.ParseNextToken());
        }

        [TestMethod]
        public void SqlTokenizer_OneLetterWord()
        {
            SqlTokenizer t = new SqlTokenizer("   a   ");
            Assert.AreEqual<SqlToken>(new SqlToken(SqlTokenType.Word, "a"), t.ParseNextToken());
            Assert.IsNull(t.ParseNextToken());
        }

        [TestMethod]
        public void SqlTokenizer_SimpleWord()
        {
            SqlTokenizer t = new SqlTokenizer("   exec   ");
            Assert.AreEqual<SqlToken>(new SqlToken(SqlTokenType.Word, "exec"), t.ParseNextToken());
            Assert.IsNull(t.ParseNextToken());
        }

        [TestMethod]
        public void SqlTokenizer_SimpleWordNoWhitespace()
        {
            SqlTokenizer t = new SqlTokenizer("exec");
            Assert.AreEqual<SqlToken>(new SqlToken(SqlTokenType.Word, "exec"), t.ParseNextToken());
            Assert.IsNull(t.ParseNextToken());
        }

        [TestMethod]
        public void SqlTokenizer_WordWithNumbers()
        {
            SqlTokenizer t = new SqlTokenizer("   proc234   ");
            Assert.AreEqual<SqlToken>(new SqlToken(SqlTokenType.Word, "proc234"), t.ParseNextToken());
            Assert.IsNull(t.ParseNextToken());
        }

        [TestMethod]
        public void SqlTokenizer_WordWithPeriods()
        {
            SqlTokenizer t = new SqlTokenizer("   proc.a.b.a234   ");
            Assert.AreEqual<SqlToken>(new SqlToken(SqlTokenType.Word, "proc.a.b.a234"), t.ParseNextToken());
            Assert.IsNull(t.ParseNextToken());
        }

        [TestMethod]
        public void SqlTokenizer_WordWithUnderscores()
        {
            SqlTokenizer t = new SqlTokenizer("   _proc_a.b.a234   ");
            Assert.AreEqual<SqlToken>(new SqlToken(SqlTokenType.Word, "_proc_a.b.a234"), t.ParseNextToken());
            Assert.IsNull(t.ParseNextToken());
        }

        [TestMethod]
        public void SqlTokenizer_WordWithSquareBrackets()
        {
            SqlTokenizer t = new SqlTokenizer("   [_proc_a].[b].[234]   ");
            Assert.AreEqual<SqlToken>(new SqlToken(SqlTokenType.Word, "[_proc_a].[b].[234]"), t.ParseNextToken());
            Assert.IsNull(t.ParseNextToken());
        }

        [TestMethod]
        public void SqlTokenizer_WordWithDelimitedIdentifierContainingSpecialCharacters()
        {
            SqlTokenizer t = new SqlTokenizer(@"   [$~!%^&()-{}'.\` contains special chars].[b].[234]   ");
            Assert.AreEqual<SqlToken>(new SqlToken(SqlTokenType.Word, @"[$~!%^&()-{}'.\` contains special chars].[b].[234]"), t.ParseNextToken());
            Assert.IsNull(t.ParseNextToken());
        }

        [TestMethod]
        public void SqlTokenizer_WordWithDelimitedIdentifierContainingEscapedDelimiter()
        {
            SqlTokenizer t = new SqlTokenizer(@"   [[[]]].[b].[234]   ");
            Assert.AreEqual<SqlToken>(new SqlToken(SqlTokenType.Word, @"[[[]]].[b].[234]"), t.ParseNextToken());
            Assert.IsNull(t.ParseNextToken());
        }

        [TestMethod]
        public void SqlTokenizer_TwoWords()
        {
            SqlTokenizer t = new SqlTokenizer("   [_proc_a]    [b].[234]   ");
            Assert.AreEqual<SqlToken>(new SqlToken(SqlTokenType.Word, "[_proc_a]"), t.ParseNextToken());
            Assert.AreEqual<SqlToken>(new SqlToken(SqlTokenType.Word, "[b].[234]"), t.ParseNextToken());
            Assert.IsNull(t.ParseNextToken());
        }

        [TestMethod]
        public void SqlTokenizer_NonUnicodeStringLiteral()
        {
            SqlTokenizer t = new SqlTokenizer("   'abc'   ");
            Assert.AreEqual<SqlToken>(new SqlToken(SqlTokenType.StringLiteral, "abc"), t.ParseNextToken());
            Assert.IsNull(t.ParseNextToken());
        }

        [TestMethod]
        public void SqlTokenizer_NonUnicodeStringLiteralWithQuotesInside()
        {
            SqlTokenizer t = new SqlTokenizer("   'a''bc'   ");
            Assert.AreEqual<SqlToken>(new SqlToken(SqlTokenType.StringLiteral, "a'bc"), t.ParseNextToken());
            Assert.IsNull(t.ParseNextToken());
        }

        [TestMethod]
        public void SqlTokenizer_NonUnicodeStringLiteralDoubleQuotes()
        {
            SqlTokenizer t = new SqlTokenizer(@"   ""abc""   ");
            Assert.AreEqual<SqlToken>(new SqlToken(SqlTokenType.StringLiteral, @"abc"), t.ParseNextToken());
            Assert.IsNull(t.ParseNextToken());
        }

        [TestMethod]
        public void SqlTokenizer_NonUnicodeStringLiteralWithQuotesInsideDoubleQuotes()
        {
            SqlTokenizer t = new SqlTokenizer(@"   ""a""""bc""   ");
            Assert.AreEqual<SqlToken>(new SqlToken(SqlTokenType.StringLiteral, @"a""bc"), t.ParseNextToken());
            Assert.IsNull(t.ParseNextToken());
        }

        [TestMethod]
        public void SqlTokenizer_UnicodeStringLiteral()
        {
            SqlTokenizer t = new SqlTokenizer("   N'abc'   ");
            Assert.AreEqual<SqlToken>(new SqlToken(SqlTokenType.StringLiteral, "abc"), t.ParseNextToken());
            Assert.IsNull(t.ParseNextToken());
        }

        [TestMethod]
        public void SqlTokenizer_UnicodeStringLiteralWithQuotesInside()
        {
            SqlTokenizer t = new SqlTokenizer("   N'a''bc'   ");
            Assert.AreEqual<SqlToken>(new SqlToken(SqlTokenType.StringLiteral, "a'bc"), t.ParseNextToken());
            Assert.IsNull(t.ParseNextToken());
        }

        [TestMethod]
        public void SqlTokenizer_UnicodeStringLiteralDoubleQuotes()
        {
            SqlTokenizer t = new SqlTokenizer(@"   N""abc""   ");
            Assert.AreEqual<SqlToken>(new SqlToken(SqlTokenType.StringLiteral, @"abc"), t.ParseNextToken());
            Assert.IsNull(t.ParseNextToken());
        }

        [TestMethod]
        public void SqlTokenizer_UnicodeStringLiteralWithQuotesInsideDoubleQuotes()
        {
            SqlTokenizer t = new SqlTokenizer(@"   N""a""""bc""   ");
            Assert.AreEqual<SqlToken>(new SqlToken(SqlTokenType.StringLiteral, @"a""bc"), t.ParseNextToken());
            Assert.IsNull(t.ParseNextToken());
        }

        [TestMethod]
        public void SqlTokenizer_SimpleInteger()
        {
            SqlTokenizer t = new SqlTokenizer(@"   1  234 ");
            Assert.AreEqual<SqlToken>(new SqlToken(SqlTokenType.NumberLiteral, "1"), t.ParseNextToken());
            Assert.AreEqual<SqlToken>(new SqlToken(SqlTokenType.NumberLiteral, "234"), t.ParseNextToken());
            Assert.IsNull(t.ParseNextToken());
        }

        [TestMethod]
        public void SqlTokenizer_SignedInteger()
        {
            SqlTokenizer t = new SqlTokenizer(@"   +2 -3");
            Assert.AreEqual<SqlToken>(new SqlToken(SqlTokenType.NumberLiteral, "+2"), t.ParseNextToken());
            Assert.AreEqual<SqlToken>(new SqlToken(SqlTokenType.NumberLiteral, "-3"), t.ParseNextToken());
            Assert.IsNull(t.ParseNextToken());
        }

        [TestMethod]
        public void SqlTokenizer_SimpleDecimal()
        {
            SqlTokenizer t = new SqlTokenizer(@"   1.8  23.4 ");
            Assert.AreEqual<SqlToken>(new SqlToken(SqlTokenType.NumberLiteral, "1.8"), t.ParseNextToken());
            Assert.AreEqual<SqlToken>(new SqlToken(SqlTokenType.NumberLiteral, "23.4"), t.ParseNextToken());
            Assert.IsNull(t.ParseNextToken());
        }

        [TestMethod]
        public void SqlTokenizer_SignedDecimal()
        {
            SqlTokenizer t = new SqlTokenizer(@"   +2.0 -3.1");
            Assert.AreEqual<SqlToken>(new SqlToken(SqlTokenType.NumberLiteral, "+2.0"), t.ParseNextToken());
            Assert.AreEqual<SqlToken>(new SqlToken(SqlTokenType.NumberLiteral, "-3.1"), t.ParseNextToken());
            Assert.IsNull(t.ParseNextToken());
        }

        [TestMethod]
        public void SqlTokenizer_SimpleFloat()
        {
            SqlTokenizer t = new SqlTokenizer(@"   101E3  234.5E6 ");
            Assert.AreEqual<SqlToken>(new SqlToken(SqlTokenType.NumberLiteral, "101E3"), t.ParseNextToken());
            Assert.AreEqual<SqlToken>(new SqlToken(SqlTokenType.NumberLiteral, "234.5E6"), t.ParseNextToken());
            Assert.IsNull(t.ParseNextToken());
        }

        [TestMethod]
        public void SqlTokenizer_SignedFloat()
        {
            SqlTokenizer t = new SqlTokenizer(@"   +2.0E+8 -3.1E-2");
            Assert.AreEqual<SqlToken>(new SqlToken(SqlTokenType.NumberLiteral, "+2.0E+8"), t.ParseNextToken());
            Assert.AreEqual<SqlToken>(new SqlToken(SqlTokenType.NumberLiteral, "-3.1E-2"), t.ParseNextToken());
            Assert.IsNull(t.ParseNextToken());
        }

        [TestMethod]
        public void SqlTokenizer_Hexadecimal()
        {
            SqlTokenizer t = new SqlTokenizer(@"   0xa1b2c3d4e5f6A1B2C3D4E5F6    ");
            Assert.AreEqual<SqlToken>(new SqlToken(SqlTokenType.HexadecimalLiteral, "a1b2c3d4e5f6A1B2C3D4E5F6"), t.ParseNextToken());
            Assert.IsNull(t.ParseNextToken());
        }

        [TestMethod]
        public void SqlTokenizer_HexadecimalEmpty()
        {
            SqlTokenizer t = new SqlTokenizer(@"   0x    ");
            Assert.AreEqual<SqlToken>(new SqlToken(SqlTokenType.HexadecimalLiteral, ""), t.ParseNextToken());
            Assert.IsNull(t.ParseNextToken());
        }

        [TestMethod]
        public void SqlTokenizer_HexadecimalEmptyAtEndOfString()
        {
            SqlTokenizer t = new SqlTokenizer(@"   0x");
            Assert.AreEqual<SqlToken>(new SqlToken(SqlTokenType.HexadecimalLiteral, ""), t.ParseNextToken());
            Assert.IsNull(t.ParseNextToken());
        }

        [TestMethod]
        public void SqlTokenizer_Variable()
        {
            SqlTokenizer t = new SqlTokenizer("   @a1 @FGH    ");
            Assert.AreEqual<SqlToken>(new SqlToken(SqlTokenType.Variable, "@a1"), t.ParseNextToken());
            Assert.AreEqual<SqlToken>(new SqlToken(SqlTokenType.Variable, "@FGH"), t.ParseNextToken());
            Assert.IsNull(t.ParseNextToken());
        }

        [TestMethod]
        public void SqlTokenizer_VariableWithEmbeddedUnderscore()
        {
            SqlTokenizer t = new SqlTokenizer("   @a1_FGH    ");
            Assert.AreEqual<SqlToken>(new SqlToken(SqlTokenType.Variable, "@a1_FGH"), t.ParseNextToken());
            Assert.IsNull(t.ParseNextToken());
        }

        [TestMethod]
        public void SqlTokenizer_VariableWithInitialUnderscore()
        {
            SqlTokenizer t = new SqlTokenizer("   @_FGH    ");
            Assert.AreEqual<SqlToken>(new SqlToken(SqlTokenType.Variable, "@_FGH"), t.ParseNextToken());
            Assert.IsNull(t.ParseNextToken());
        }

        [TestMethod]
        public void SqlTokenizer_PunctuationAndOperators()
        {
            SqlTokenizer t = new SqlTokenizer("   ,=()    ");
            Assert.AreEqual<SqlToken>(new SqlToken(SqlTokenType.Operator, ","), t.ParseNextToken());
            Assert.AreEqual<SqlToken>(new SqlToken(SqlTokenType.Operator, "="), t.ParseNextToken());
            Assert.AreEqual<SqlToken>(new SqlToken(SqlTokenType.Operator, "("), t.ParseNextToken());
            Assert.AreEqual<SqlToken>(new SqlToken(SqlTokenType.Operator, ")"), t.ParseNextToken());
            Assert.IsNull(t.ParseNextToken());
        }

        [TestMethod]
        public void SqlTokenizer_OperatorFollowedByNumber()
        {
            SqlTokenizer t = new SqlTokenizer("   =1    ");
            Assert.AreEqual<SqlToken>(new SqlToken(SqlTokenType.Operator, "="), t.ParseNextToken());
            Assert.AreEqual<SqlToken>(new SqlToken(SqlTokenType.NumberLiteral, "1"), t.ParseNextToken());
            Assert.IsNull(t.ParseNextToken());
        }

        [TestMethod]
        public void SqlTokenizer_BookmarkAllowsBacktracking()
        {
            SqlTokenizer t = new SqlTokenizer("   exec   ");
            SqlTokenizerBookmark bookmark = t.Bookmark;
            Assert.AreEqual<SqlToken>(new SqlToken(SqlTokenType.Word, "exec"), t.ParseNextToken());
            Assert.IsNull(t.ParseNextToken());
            t.GoToBookmark(bookmark);
            Assert.AreEqual<SqlToken>(new SqlToken(SqlTokenType.Word, "exec"), t.ParseNextToken());
            Assert.IsNull(t.ParseNextToken());
        }

        [TestMethod]
        public void SqlTokenizer_SampleQuery()
        {
            SqlTokenizer t = new SqlTokenizer("exec [p_InsertScratch] @Id=1,@Data=N'param'");
            Assert.AreEqual<SqlToken>(new SqlToken(SqlTokenType.Word, "exec"), t.ParseNextToken());
            Assert.AreEqual<SqlToken>(new SqlToken(SqlTokenType.Word, "[p_InsertScratch]"), t.ParseNextToken());
            Assert.AreEqual<SqlToken>(new SqlToken(SqlTokenType.Variable, "@Id"), t.ParseNextToken());
            Assert.AreEqual<SqlToken>(new SqlToken(SqlTokenType.Operator, "="), t.ParseNextToken());
            Assert.AreEqual<SqlToken>(new SqlToken(SqlTokenType.NumberLiteral, "1"), t.ParseNextToken());
            Assert.AreEqual<SqlToken>(new SqlToken(SqlTokenType.Operator, ","), t.ParseNextToken());
            Assert.AreEqual<SqlToken>(new SqlToken(SqlTokenType.Variable, "@Data"), t.ParseNextToken());
            Assert.AreEqual<SqlToken>(new SqlToken(SqlTokenType.Operator, "="), t.ParseNextToken());
            Assert.AreEqual<SqlToken>(new SqlToken(SqlTokenType.StringLiteral, "param"), t.ParseNextToken());
            Assert.IsNull(t.ParseNextToken());
        }
    }
}
