﻿//---------------------------------------------------------------------
// <copyright file="TestHelper.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
//     THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
//     OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
//     LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//     FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>The TestHelper type.</summary>
//---------------------------------------------------------------------

namespace Microsoft.DatabaseLoadTest.Library.Test
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    using Microsoft.VisualStudio.TestTools.UnitTesting;

    /// <summary>
    /// General helper methods for unit tests.
    /// </summary>
    public static class TestHelper
    {
        internal delegate void MethodUnderTest();

        internal static void TestForArgumentNullException(string expectedParameterName, MethodUnderTest methodUnderTest)
        {
            try
            {
                methodUnderTest();
                Assert.Fail("Expected ArgumentNullException");
            }
            catch (ArgumentNullException ane)
            {
                Assert.AreEqual<string>(expectedParameterName, ane.ParamName);
            }
        }

        internal static void TestForArgumentException(string expectedParameterName, MethodUnderTest methodUnderTest)
        {
            try
            {
                methodUnderTest();
                Assert.Fail("Expected ArgumentException");
            }
            catch (ArgumentException ae)
            {
                // Can't use Assert.IsInstanceOfType because we want to be sure that the exception is not a derived type
                Assert.IsTrue(ae.GetType() == typeof(ArgumentException));
                Assert.AreEqual<string>(expectedParameterName, ae.ParamName);
            }
        }

        internal static void TestForArgumentOutOfRangeException(string expectedParameterName, MethodUnderTest methodUnderTest)
        {
            try
            {
                methodUnderTest();
                Assert.Fail("Expected ArgumentOutOfRangeException");
            }
            catch (ArgumentOutOfRangeException ae)
            {
                // Can't use Assert.IsInstanceOfType because we want to be sure that the exception is not a derived type
                Assert.IsTrue(ae.GetType() == typeof(ArgumentOutOfRangeException));
                Assert.AreEqual<string>(expectedParameterName, ae.ParamName);
            }
        }

        internal static void TestForInvalidOperationException(MethodUnderTest methodUnderTest)
        {
            try
            {
                methodUnderTest();
                Assert.Fail("Expected InvalidOperationException");
            }
            catch (InvalidOperationException)
            {
            }
        }

        internal static void TestForNotSupportedException(MethodUnderTest methodUnderTest)
        {
            try
            {
                methodUnderTest();
                Assert.Fail("Expected NotSupportedException");
            }
            catch (NotSupportedException)
            {
            }
        }

        internal static ParsedSqlCommand ArbitraryParsedSqlCommand()
        {
            ParsedSqlCommand ans = new ParsedSqlCommand("random", System.Data.CommandType.Text, new List<ParsedSqlParameter>());
            return ans;
        }
    }
}
