//---------------------------------------------------------------------
// <copyright file="TraceFileProcessorTests.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
//     THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
//     OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
//     LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//     FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>The TraceFileProcessorTests class.</summary>
//---------------------------------------------------------------------

namespace Microsoft.DatabaseLoadTest.Library.Test
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Text;

    using Microsoft.SqlServer.Management.Trace;

    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class TraceFileProcessorTests : ICustomCodeGeneration
    {
        private static IList<string> rejectedDatabaseNames = new string[] { "master", "model", "msdb", "" };
        private static IList<string> rejectedQueries = new string[] { "exec sp_reset_connection" };
        
        private static int generatingEventCount = 0; // has to be static because TraceFileProcessor creates own instance of this type
        private int parsingEventCount = 0;

        private DbLoadTestConfiguration defaultConfig;

        [TestInitialize]
        public void InitializeTest()
        {
            generatingEventCount = 0;
            File.Delete("test.cs");
            File.Delete("test.stubs");
            TraceFileProcessor.ParsingSql += new EventHandler<SqlEventArgs>(this.TraceFileProcessor_ParsingSql);
            TraceFileProcessor.ProcessingTraceRecord += new EventHandler<TraceRecordFilterEventArgs>(this.TraceFileProcessor_TraceRecord);
            this.defaultConfig = ConfigurationReader.Read(null);
        }

        [TestCleanup]
        public void CleanupTest()
        {
            TraceFileProcessor.ParsingSql -= new EventHandler<SqlEventArgs>(this.TraceFileProcessor_ParsingSql);
        }

        [TestMethod]
        public void TFP_InvalidScenarioNameThrowsInvalidOperationException()
        {
            TestHelper.TestForInvalidOperationException(
                delegate()
                {
                    TraceFileProcessor.ProcessTraceFile("123", "SampleLoginTrace.trc", this.defaultConfig);
                });
            this.TestThatProcessorDidNothing("123");
        }

        [TestMethod]
        public void TFP_TraceFileDoesNotExistThrowsInvalidOperationException()
        {
            TestHelper.TestForInvalidOperationException(
                delegate()
                {
                    TraceFileProcessor.ProcessTraceFile("test", "XYZSampleLoginTrace.trc", this.defaultConfig);
                });
            this.TestThatProcessorDidNothing("test");
        }

        [TestMethod]
        public void TFP_TraceFileInvalidThrowsInvalidOperationException()
        {
            File.WriteAllText("BadTraceFile.trc", "I am not a trace file");
            TestHelper.TestForInvalidOperationException(
                delegate()
                {
                    TraceFileProcessor.ProcessTraceFile("test", "BadTraceFile.trc", this.defaultConfig);
                });
            this.TestThatProcessorDidNothing("test");
        }

        [TestMethod]
        public void TFP_TraceFileContainsUnsupportedSqlThrowsInvalidOperationException()
        {
            TestHelper.TestForInvalidOperationException(
                delegate()
                {
                    TraceFileProcessor.ProcessTraceFile("test", "UnsupportedSqlTraceFile.trc", this.defaultConfig);
                });
                Assert.IsFalse(File.Exists("test.cs"));
                Assert.IsFalse(File.Exists("test.stubs"));
                Assert.AreEqual<int>(1, this.parsingEventCount);
                Assert.AreEqual<int>(0, generatingEventCount);
        }

        [TestMethod]
        public void TFP_ProcessFilesSuccessfully()
        {
            TraceFileProcessor.ProcessTraceFile("test", "SampleLoginTrace.trc", this.defaultConfig);
            Assert.IsTrue(File.Exists("test.cs"));
            Assert.IsTrue(File.Exists("test.stubs"));
            Assert.AreEqual<int>(16, this.parsingEventCount);
        }

        [TestMethod]
        public void TFP_ProcessFilesSuccessfullyUsingReader()
        {
            using (TraceFile reader = new TraceFile())
            {
                reader.InitializeAsReader("SampleLoginTrace.trc");
                TraceFileProcessor.ProcessTraceFile("test", reader, this.defaultConfig);
                Assert.IsTrue(File.Exists("test.cs"));
                Assert.IsTrue(File.Exists("test.stubs"));
                Assert.AreEqual<int>(16, this.parsingEventCount);
            }
        }

        [TestMethod]
        public void TFP_NonExistentAssemblyCodeGeneratorTypeReferenceThrowsInvalidOperationException()
        {
            DbLoadTestConfiguration config = new DbLoadTestConfiguration();
            config.customCodeGenerator = new typeType();
            config.customCodeGenerator.assembly = "dummy";
            config.customCodeGenerator.type = "dummy";
            TestHelper.TestForInvalidOperationException(
                delegate()
                {
                    TraceFileProcessor.ProcessTraceFile("test", "SampleLoginTrace.trc", config);
                });
            this.TestThatProcessorDidNothing("test");
        }

        [TestMethod]
        public void TFP_NonExistentTypeInExistingAssemblyCodeGeneratorTypeReferenceThrowsInvalidOperationException()
        {
            DbLoadTestConfiguration config = new DbLoadTestConfiguration();
            config.customCodeGenerator = new typeType();
            config.customCodeGenerator.assembly = "Microsoft.DatabaseLoadTest.Samples, Version=1.0.0.0, Culture=neutral, PublicKeyToken=e3a60a94ce272d5c";
            config.customCodeGenerator.type = "dummy";
            TestHelper.TestForInvalidOperationException(
                delegate()
                {
                    TraceFileProcessor.ProcessTraceFile("test", "SampleLoginTrace.trc", config);
                });
            this.TestThatProcessorDidNothing("test");
        }

        [TestMethod]
        public void TFP_NoCustomCodeGenInterfaceCodeGeneratorTypeReferenceThrowsInvalidOperationException()
        {
            DbLoadTestConfiguration config = new DbLoadTestConfiguration();
            config.customCodeGenerator = new typeType();
            config.customCodeGenerator.assembly = "Microsoft.DatabaseLoadTest.Library.Test";
            config.customCodeGenerator.type = "Microsoft.DatabaseLoadTest.Library.Test.NonCustomCodeGeneratorType";
            TestHelper.TestForInvalidOperationException(
                delegate()
                {
                    TraceFileProcessor.ProcessTraceFile("test", "SampleLoginTrace.trc", config);
                });
            this.TestThatProcessorDidNothing("test");
        }

        [TestMethod]
        public void TFP_CodeGenInterfaceCalled()
        {
            DbLoadTestConfiguration config = new DbLoadTestConfiguration();
            config.customCodeGenerator = new typeType();
            config.customCodeGenerator.assembly = "Microsoft.DatabaseLoadTest.Library.Test";
            config.customCodeGenerator.type = this.GetType().FullName;
            TraceFileProcessor.ProcessTraceFile("comment", "SampleLoginTrace.trc", config);
            Assert.AreEqual<int>(16, generatingEventCount);
            string expected = @"//------------------------------------------------------------------------------
// <auto-generated>
//     This code was generated by a tool.
//     Runtime Version:2.0.50727.1434
//
//     Changes to this file may cause incorrect behavior and will be lost if
//     the code is regenerated.
// </auto-generated>
//------------------------------------------------------------------------------

namespace comment
{
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using System;
    using System.Data;
    using System.Data.SqlClient;
    
    
    [TestClass()]
    public partial class commentTests
    {
        
        private TestContext _testContext;
        
        private SqlConnection _connection;
        
        public TestContext TestContext
        {
            get
            {
                return this._testContext;
            }
            set
            {
                this._testContext = value;
            }
        }
        
        [TestMethod()]
        public void comment()
        {
        }
    }
}
";
            CodeGenerationTestUtilities.CompareCodeWithFile("comment.cs", expected);
        }

        public bool GenerateCall(ParsedSqlCommand command, System.CodeDom.CodeMemberMethod scenarioMethod, System.CodeDom.CodeTypeDeclaration stubType)
        {
            generatingEventCount++;
            return true;
        }

        private void TestThatProcessorDidNothing(string scenarioName)
        {
            Assert.IsFalse(File.Exists(scenarioName + ".cs"));
            Assert.IsFalse(File.Exists(scenarioName + ".stubs"));
            Assert.AreEqual<int>(0, this.parsingEventCount);
            Assert.AreEqual<int>(0, generatingEventCount);
        }

        private void TraceFileProcessor_ParsingSql(object sender, SqlEventArgs e)
        {
            Console.WriteLine("Processing: {0}", e.Sql);
            this.parsingEventCount++;
        }

        private void TraceFileProcessor_TraceRecord(object sender, TraceRecordFilterEventArgs e)
        {
            e.Process = !rejectedDatabaseNames.Contains(e.TraceRecord.DatabaseName) && !rejectedQueries.Contains(e.TraceRecord.TextData);
        }
    }
}
