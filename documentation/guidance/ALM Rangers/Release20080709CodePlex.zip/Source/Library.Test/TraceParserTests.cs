//---------------------------------------------------------------------
// <copyright file="TraceParserTests.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
//     THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
//     OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
//     LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//     FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>The TraceParserTests class.</summary>
//---------------------------------------------------------------------

namespace Microsoft.DatabaseLoadTest.Library.Test
{
    using System;
    using System.Data;
    using System.Text;
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    using Microsoft.DatabaseLoadTest.Library;

    /// <summary>
    /// Summary description for UnitTest1
    /// </summary>
    [TestClass]
    public class TraceParserTests
    {
        private string traceStart = "Trace Start";
        private string sql = "SQL:BatchStarting";
        private string rpc = "RPC:Starting";

        public TraceParserTests()
        {
        }

        [TestMethod]
        public void Parser_RejectsNullReader()
        {
            TestHelper.TestForArgumentNullException(
                "reader",
                delegate()
                {
                    TraceParser p = new TraceParser(null);
                });
        }

        [TestMethod]
        public void Parser_RejectsReaderWithoutEventClassColumn()
        {
            DataTable schema = new DataTable();

            schema.Columns.Add("ColumnName", typeof(string));
            schema.Columns.Add("DataType", typeof(Type));

            schema.Rows.Add("TextData", typeof(string));
            schema.Rows.Add("DatabaseName", typeof(string));
            schema.Rows.Add("SPID", typeof(Int32));

            MockTraceReader mockReader = new MockTraceReader(schema);

            TestHelper.TestForInvalidOperationException(
                delegate()
                {
                    TraceParser p = new TraceParser(mockReader);
                });
        }

        [TestMethod]
        public void Parser_RejectsReaderWithoutTextDataColumn()
        {
            DataTable schema = new DataTable();

            schema.Columns.Add("ColumnName", typeof(string));
            schema.Columns.Add("DataType", typeof(Type));

            schema.Rows.Add("EventClass", typeof(string));
            schema.Rows.Add("DatabaseName", typeof(string));
            schema.Rows.Add("SPID", typeof(Int32));

            MockTraceReader mockReader = new MockTraceReader(schema);

            TestHelper.TestForInvalidOperationException(
                delegate()
                {
                    TraceParser p = new TraceParser(mockReader);
                });
        }

        [TestMethod]
        public void Parser_RejectsReaderWithoutSpidColumn()
        {
            DataTable schema = new DataTable();

            schema.Columns.Add("ColumnName", typeof(string));
            schema.Columns.Add("DataType", typeof(Type));

            schema.Rows.Add("EventClass", typeof(string));
            schema.Rows.Add("TextData", typeof(string));
            schema.Rows.Add("DatabaseName", typeof(string));

            MockTraceReader mockReader = new MockTraceReader(schema);

            TestHelper.TestForInvalidOperationException(
                delegate()
                {
                    TraceParser p = new TraceParser(mockReader);
                });
        }

        [TestMethod]
        public void Parser_FilterOutMasterModelAndMsdb()
        {
            MockTraceReader mockReader = new MockTraceReader();

            DataTable traceData = mockReader.TraceData;

            traceData.Rows.Add(this.sql, "dummy", "master", 1);
            traceData.Rows.Add(this.rpc, "dummy", "model", 1);
            traceData.Rows.Add(this.rpc, "dummy", "msdb", 1);

            IList<string> rejectedDatabaseNames = new string[] { "master", "model", "msdb", "" };

            TraceParser p = new TraceParser(mockReader);
            p.ProcessingTraceRecord += delegate(object sender, TraceRecordFilterEventArgs trfea)
            {
                trfea.Process = !rejectedDatabaseNames.Contains(trfea.TraceRecord.DatabaseName);
            };

            int count = 0;
            while (p.Parse() != null)
            {
                count++;
            }

            Assert.AreEqual<int>(0, count);
        }

        [TestMethod]
        public void Parser_ProcessesTraceStartRecord()
        {
            MockTraceReader mockReader = new MockTraceReader();

            DataTable traceData = mockReader.TraceData;

            traceData.Rows.Add(this.traceStart, null, null, null);

            TraceParser p = new TraceParser(mockReader);
            p.ProcessingTraceRecord += delegate(object sender, TraceRecordFilterEventArgs trfea)
            {
                Assert.Fail("Should not raise this event");
            };

            int count = 0;
            while (p.Parse() != null)
            {
                count++;
            }

            Assert.AreEqual<int>(0, count);
        }

        [TestMethod]
        public void Parser_FilterOutQuery()
        {
            MockTraceReader mockReader = new MockTraceReader();

            DataTable traceData = mockReader.TraceData;

            traceData.Rows.Add(this.sql, "exec sp_reset_connection", "dummy", 1);
            traceData.Rows.Add(this.rpc, "exec dummy", "dummy", 1);
            traceData.Rows.Add(this.rpc, "exec dummy", "dummy", 1);

            IList<string> rejectedQueries = new string[] { "exec sp_reset_connection" };

            TraceParser p = new TraceParser(mockReader);
            p.ProcessingTraceRecord += delegate(object sender, TraceRecordFilterEventArgs trfea)
            {
                trfea.Process = !rejectedQueries.Contains(trfea.TraceRecord.TextData);
            };

            int count = 0;
            while (p.Parse() != null)
            {
                count++;
            }

            Assert.AreEqual<int>(2, count);
        }

        [TestMethod]
        public void Parser_ErrorIfDatabaseNameColumnPresentButNullForSQL()
        {
            MockTraceReader mockReader = new MockTraceReader();

            DataTable traceData = mockReader.TraceData;

            traceData.Rows.Add(this.sql, "dummy", DBNull.Value);

            TraceParser p = new TraceParser(mockReader);
            TestHelper.TestForInvalidOperationException(
                delegate()
                {
                    while (p.Parse() != null)
                    {
                    }
                });
        }

        [TestMethod]
        public void Parser_ErrorIfDatabaseNameColumnPresentButNullForRPC()
        {
            MockTraceReader mockReader = new MockTraceReader();

            DataTable traceData = mockReader.TraceData;

            traceData.Rows.Add(this.rpc, "dummy", DBNull.Value);

            TraceParser p = new TraceParser(mockReader);
            TestHelper.TestForInvalidOperationException(
                delegate()
                {
                    while (p.Parse() != null)
                    {
                    }
                });
        }

        [TestMethod]
        public void Parser_ErrorIfDatabaseNameColumnPresentButEmptyForSQL()
        {
            MockTraceReader mockReader = new MockTraceReader();

            DataTable traceData = mockReader.TraceData;

            traceData.Rows.Add(this.sql, "dummy", "");

            TraceParser p = new TraceParser(mockReader);
            TestHelper.TestForInvalidOperationException(
                delegate()
                {
                    while (p.Parse() != null)
                    {
                    }
                });
        }

        [TestMethod]
        public void Parser_ErrorIfDatabaseNameColumnPresentButEmptyForRPC()
        {
            MockTraceReader mockReader = new MockTraceReader();

            DataTable traceData = mockReader.TraceData;

            traceData.Rows.Add(this.rpc, "dummy", "");

            TraceParser p = new TraceParser(mockReader);
            TestHelper.TestForInvalidOperationException(
                delegate()
                {
                    while (p.Parse() != null)
                    {
                    }
                });
        }

        [TestMethod]
        public void Parser_ReturnsSQLandRPCForAllDatabasesIfNoDatabaseNameColumn()
        {
            DataTable schema = new DataTable();

            schema.Columns.Add("ColumnName", typeof(string));
            schema.Columns.Add("DataType", typeof(Type));

            schema.Rows.Add("EventClass", typeof(string));
            schema.Rows.Add("TextData", typeof(string));
            schema.Rows.Add("SPID", typeof(int));

            MockTraceReader mockReader = new MockTraceReader(schema);

            DataTable traceData = mockReader.TraceData;

            traceData.Rows.Add(this.sql, "dummy", 1);
            traceData.Rows.Add(this.rpc, "exec dummy", 1);
            traceData.Rows.Add(this.rpc, "exec dummy", 1);

            TraceParser p = new TraceParser(mockReader);
            int count = 0;
            while (p.Parse() != null)
            {
                count++;
            }

            Assert.AreEqual<int>(3, count);
        }
    }

}
