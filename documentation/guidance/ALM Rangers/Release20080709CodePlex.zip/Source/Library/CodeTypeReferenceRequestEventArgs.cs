//---------------------------------------------------------------------
// <copyright file="CodeTypeReferenceRequestEventArgs.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
//     THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
//     OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
//     LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//     FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>The CodeTypeReferenceRequestEventArgs type.</summary>
//---------------------------------------------------------------------

namespace Microsoft.DatabaseLoadTest.Library
{
    using System;
    using System.CodeDom;
    using System.Collections.Generic;
    using System.Text;

    /// <summary>
    /// Event arguments used to get a <see cref="CodeTypeReference"/> for a type.
    /// </summary>
    public class CodeTypeReferenceRequestEventArgs : EventArgs
    {
        private readonly Type requestedType;
        private readonly CodeTypeReference[] genericParameters;
        private CodeTypeReference codeTypeReference;

        /// <summary>
        /// Initializes an instance with the information about the type.
        /// </summary>
        /// <param name="requestedType">The type being requested.</param>
        /// <param name="genericParameters">The generic parameters for <paramref name="requestedType"/> if it is a generic type.</param>
        public CodeTypeReferenceRequestEventArgs(Type requestedType, CodeTypeReference[] genericParameters)
        {
            this.requestedType = requestedType;
            this.genericParameters = genericParameters;
        }

        /// <summary>
        /// Gets the <see cref="Type"/> that is being requested.
        /// </summary>
        /// <value>The <see cref="Type"/> that is being requested.</value>
        public Type RequestedType
        {
            get { return this.requestedType; }
        }

        /// <summary>
        /// Gets the generic parameters for the type being requested.
        /// </summary>
        /// <value>The generic parameters for the type being requested.</value>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1819")]
        public CodeTypeReference[] GenericParameters
        {
            get { return this.genericParameters; }
        }

        /// <summary>
        /// Gets or sets the <see cref="CodeTypeReference"/> for the <see cref="Type"/> being requested.
        /// </summary>
        /// <remarks>
        /// <para>
        /// Used by event handlers to return the <see cref="CodeTypeReference"/> to the caller.
        /// </para>
        /// </remarks>
        /// <value>The <see cref="CodeTypeReference"/> for the <see cref="Type"/> being requested.</value>
        public CodeTypeReference CodeTypeReference
        {
            get { return this.codeTypeReference; }
            set { this.codeTypeReference = value; }
        }
    }
}
