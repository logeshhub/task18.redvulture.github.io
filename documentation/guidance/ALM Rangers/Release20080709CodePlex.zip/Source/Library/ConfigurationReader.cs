﻿//---------------------------------------------------------------------
// <copyright file="ConfigurationReader.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
//     THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
//     OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
//     LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//     FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>The ConfigurationReader type.</summary>
//---------------------------------------------------------------------

namespace Microsoft.DatabaseLoadTest.Library
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Reflection;
    using System.Text;
    using System.Xml;
    using System.Xml.Schema;
    using System.Xml.Serialization;

    /// <summary>
    /// Reads configuration data.
    /// </summary>
    /// <remarks>
    /// Generic for later unification with WCFLoadTest
    /// </remarks>
    public static class ConfigurationReader
    {
        /// <summary>
        /// Reads the configuration from a file.
        /// </summary>
        /// <remarks>
        /// If the file name is null or the empty string the default configuration is returned.
        /// </remarks>
        /// <param name="fileName">The configuration file to be read.</param>
        /// <returns>The configuration.</returns>
        public static DbLoadTestConfiguration Read(string fileName)
        {
            DbLoadTestConfiguration ans = null;

            if (string.IsNullOrEmpty(fileName))
            {
                ans = new DbLoadTestConfiguration();
                ans.operationTimerMode = OperationTimerMode.IncludeOperationTimers;
                ans.testMethodMode = TestMethodMode.ScenarioMethodOnly;
            }
            else if (!File.Exists(fileName))
            {
                throw new InvalidOperationException(string.Format(CultureInfo.CurrentCulture, Messages.Configuration_FileNotFound, fileName));
            }
            else
            {
                XmlSerializer xs = new XmlSerializer(typeof(DbLoadTestConfiguration));
                using (XmlReader reader = XmlReader.Create(fileName, GetReaderSettings()))
                {
                    try
                    {
                        ans = (DbLoadTestConfiguration)xs.Deserialize(reader);
                    }
                    catch (InvalidOperationException ioe)
                    {
                        throw new InvalidOperationException(string.Format(CultureInfo.CurrentCulture, Messages.Configuration_InvalidFile, fileName), ioe);
                    }
                }
            }

            return ans;
        }

        private static XmlReaderSettings GetReaderSettings()
        {
            XmlReaderSettings readerSettings = new XmlReaderSettings();
            XmlReader schemaReader = XmlReader.Create(Assembly.GetAssembly(typeof(ConfigurationReader)).GetManifestResourceStream("Microsoft.DatabaseLoadTest.Library.ConfigurationSchema.xsd"));
            readerSettings = new XmlReaderSettings();
            ////readerSettings.CheckCharacters = true;
            readerSettings.CloseInput = true;
            readerSettings.Schemas.Add(null, schemaReader);
            readerSettings.ValidationFlags = XmlSchemaValidationFlags.ReportValidationWarnings;
            readerSettings.ValidationType = ValidationType.Schema;
            readerSettings.IgnoreComments = true;
            readerSettings.IgnoreWhitespace = true;
            readerSettings.IgnoreProcessingInstructions = true;
            return readerSettings;
        }
    }
}
