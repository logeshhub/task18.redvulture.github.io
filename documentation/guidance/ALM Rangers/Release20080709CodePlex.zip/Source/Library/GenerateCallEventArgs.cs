﻿//---------------------------------------------------------------------
// <copyright file="GenerateCallEventArgs.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
//     THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
//     OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
//     LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//     FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>The GenerateCallEventArgs type.</summary>
//---------------------------------------------------------------------

namespace Microsoft.DatabaseLoadTest.Library
{
    using System;
    using System.CodeDom;
    using System.Collections.Generic;
    using System.Text;

    /// <summary>
    /// Provides data for the <see cref="UnitTestGenerator.GeneratingCall"/> event.
    /// </summary>
    /// <remarks>
    /// The event data includes a <see cref="Handled"/> property which is used by the event handler to indicate whether it
    /// has processed the event and so the default code generation should be suppressed. Once <see cref="Handled"/> has been
    /// set it can no longer be cleared.
    /// </remarks>
    public class GenerateCallEventArgs : EventArgs
    {
        private readonly ParsedSqlCommand command;
        private readonly CodeMemberMethod scenarioMethod;
        private readonly CodeTypeDeclaration stubType;
        private bool handled;

        /// <summary>
        /// Initializes an instance of <see cref="GenerateCallEventArgs"/> with immutable parameters, the <see cref="Handled"/>
        /// property is initialised to be <c>false</c>.
        /// </summary>
        /// <param name="command">The command for which code is to be generated.</param>
        /// <param name="scenarioMethod">The method that contains the scenario calls.</param>
        /// <param name="stubType">The type that represent the separate customisation code partial type.</param>
        public GenerateCallEventArgs(ParsedSqlCommand command, CodeMemberMethod scenarioMethod, CodeTypeDeclaration stubType)
        {
            this.command = command;
            this.scenarioMethod = scenarioMethod;
            this.stubType = stubType;
        }

        /// <summary>
        /// Gets the command that is to be generated.
        /// </summary>
        /// <value>The command that is to be generated.</value>
        public ParsedSqlCommand Command
        {
            get { return this.command; }
        }

        /// <summary>
        /// Gets the method that contains the whole test scenario.
        /// </summary>
        /// <value>
        /// The method that contains the whole test scenario.
        /// </value>
        public CodeMemberMethod ScenarioMethod
        {
            get { return this.scenarioMethod; }
        }

        /// <summary>
        /// Gets the type that contains the customisation stubs.
        /// </summary>
        /// <value>
        /// The type that contains the customisation stubs.
        /// </value>
        public CodeTypeDeclaration StubType
        {
            get { return this.stubType; }
        }

        /// <summary>
        /// Gets or sets a value indicating whether the generation has been handled by an event handler.
        /// </summary>
        /// <value>A value indicating whether the generation has been handled by an event handler.</value>
        public bool Handled
        {
            get
            {
                return this.handled;
            }
            
            set
            {
                if (this.handled)
                {
                    throw new InvalidOperationException(Messages.CannotSetHandledTwice);
                }

                this.handled = value;
            }
        }
    }
}
