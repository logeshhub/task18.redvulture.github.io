﻿//---------------------------------------------------------------------
// <copyright file="IItemGenerator.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
//     THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
//     OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
//     LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//     FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>The ItemGenerator interface.</summary>
//---------------------------------------------------------------------

namespace Microsoft.DatabaseLoadTest.Library
{
    using System;
    using System.CodeDom;

    // TODO: Refactor to put customisation callback into an event, preferably in the interface so it is generalised and usable for WCF too.

    /// <summary>
    /// Interface implemented by a type that generates code within the context of a larger unit test.
    /// </summary>
    public interface IItemGenerator
    {
        /// <summary>
        /// Raised when the generator needs to get a <see cref="CodeTypeReference"/> for a type.
        /// </summary>
        /// <remarks>
        /// <para>
        /// Allows the generator to delegate the importing of namespaces to the caller.
        /// </para>
        /// </remarks>
        event EventHandler<CodeTypeReferenceRequestEventArgs> CodeTypeRequestEvent;

        /// <summary>
        /// Initialises the generator.
        /// </summary>
        /// <param name="body">The statement body that the generator must add code to.</param>
        void Initialise(CodeStatementCollection body);
    }
}
