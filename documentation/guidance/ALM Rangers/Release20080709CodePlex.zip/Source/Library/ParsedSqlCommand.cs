//---------------------------------------------------------------------
// <copyright file="ParsedSqlCommand.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
//     THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
//     OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
//     LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//     FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>The ParsedSqlCommand type.</summary>
//---------------------------------------------------------------------

namespace Microsoft.DatabaseLoadTest.Library
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Diagnostics;
    using System.Globalization;
    using System.Text;

    /// <summary>
    /// Represents a SQL command that has been parsed.
    /// </summary>
    public class ParsedSqlCommand
    {
        private readonly string commandText;
        private readonly CommandType commandType;
        private readonly IList<ParsedSqlParameter> parameters;
        private IList<ParsedSqlParameter> inputParameters;
        private IList<ParsedSqlParameter> outputParameters;
        private IList<ParsedSqlParameter> inputOutputParameters;

        /// <summary>
        /// Initializes an instance of <see cref="ParsedSqlCommand"/>.
        /// </summary>
        /// <remarks>
        /// <para>
        /// If the parameters are positional (indicated by a blank parameter name), the parameters are
        /// given automatically generated names.
        /// </para>
        /// </remarks>
        /// <param name="commandText">The text of the command.</param>
        /// <param name="commandType">The type of commmand.</param>
        /// <param name="parameters">Collection of parameters. All parameters must be positional or non-positional.</param>
        public ParsedSqlCommand(string commandText, CommandType commandType, IList<ParsedSqlParameter> parameters)
        {
            this.commandText = commandText;
            this.commandType = commandType;

            // Give any positional parameters a name, make positional parameters non-positional if this is a SQL statement

            for (int i = 0; i < parameters.Count; i++)
            {
                if (parameters[i].Positional)
                {
                    parameters[i] = new ParsedSqlParameter(string.Format(CultureInfo.InvariantCulture, "@p{0}", i + 1), parameters[i].Type, parameters[i].Value, parameters[i].Direction, commandType != CommandType.Text);
                }
            }

            this.parameters = parameters;
        }

        /// <summary>
        /// Gets the text of the command.
        /// </summary>
        /// <value>The text of the command.</value>
        public string CommandText
        {
            get { return this.commandText; }
        }

        /// <summary>
        /// Gets the command type.
        /// </summary>
        /// <value>The command type.</value>
        public CommandType CommandType
        {
            get { return this.commandType; }
        }

        /// <summary>
        /// Gets the collection of input and output parameters.
        /// </summary>
        /// <value>The collection of input and output parameters.</value>
        public IList<ParsedSqlParameter> Parameters
        {
            get { return this.parameters; }
        }

        /// <summary>
        /// Gets the collection of input parameters.
        /// </summary>
        /// <value>The collection of input parameters.</value>
        public IList<ParsedSqlParameter> InputParameters
        {
            get
            {
                this.SplitParameters();
                return this.inputParameters;
            }
        }

        /// <summary>
        /// Gets the collection of output parameters.
        /// </summary>
        /// <value>The collection of output parameters.</value>
        public IList<ParsedSqlParameter> OutputParameters
        {
            get
            {
                this.SplitParameters();
                return this.outputParameters;
            }
        }

        /// <summary>
        /// Gets the collection of input-output parameters.
        /// </summary>
        /// <value>The collection of input-output parameters.</value>
        public IList<ParsedSqlParameter> InputOutputParameters
        {
            get
            {
                this.SplitParameters();
                return this.inputOutputParameters;
            }
        }

        private void SplitParameters()
        {
            List<ParsedSqlParameter> inputParsedSqlParameters = new List<ParsedSqlParameter>();
            List<ParsedSqlParameter> outputParsedSqlParameters = new List<ParsedSqlParameter>();
            List<ParsedSqlParameter> inputOutputParsedSqlParameters = new List<ParsedSqlParameter>();
            foreach (ParsedSqlParameter p in this.parameters)
            {
                Debug.Assert(p.Direction == ParameterDirection.Input || p.Direction == ParameterDirection.Output || p.Direction == ParameterDirection.InputOutput);

                if (p.Direction == ParameterDirection.Input)
                {
                    inputParsedSqlParameters.Add(p);
                }
                else if (p.Direction == ParameterDirection.Output)
                {
                    outputParsedSqlParameters.Add(p);
                }
                else
                {
                    inputOutputParsedSqlParameters.Add(p);
                }
            }

            this.inputParameters = inputParsedSqlParameters.AsReadOnly();
            this.outputParameters = outputParsedSqlParameters.AsReadOnly();
            this.inputOutputParameters = inputOutputParsedSqlParameters.AsReadOnly();
        }

    }
}
