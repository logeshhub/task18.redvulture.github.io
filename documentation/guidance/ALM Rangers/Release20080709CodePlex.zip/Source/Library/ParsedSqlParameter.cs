//---------------------------------------------------------------------
// <copyright file="ParsedSqlParameter.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
//     THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
//     OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
//     LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//     FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>The ParsedSqlParameter type.</summary>
//---------------------------------------------------------------------

namespace Microsoft.DatabaseLoadTest.Library
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlTypes;
    using System.Globalization;
    using System.Text;

    /// <summary>
    /// Represents a parsed SQL parameter.
    /// </summary>
    /// <remarks>
    /// By convention the value is <c>null</c> for missing values (using the <c>default</c> keyword) and 
    /// <c>DBNull.Value</c> for NULLs.
    /// </remarks>
    public class ParsedSqlParameter
    {
        private readonly string name;
        private readonly DbType type;
        private readonly object value;
        private readonly ParameterDirection direction;
        private readonly bool positional;

        /// <summary>
        /// Initializes a new instance.
        /// </summary>
        /// <remarks>
        /// The parameter will be positional if the <paramref name="name"/> is null or empty, otherwise it will be oonsidered
        /// non-positional.
        /// </remarks>
        /// <param name="name">The name of the parameter. Empty string for positional parameters.</param>
        /// <param name="type">The type of the parameter.</param>
        /// <param name="value">The value of the parameter.</param>
        /// <param name="direction">The direction of the parameter.</param>
        public ParsedSqlParameter(string name, DbType type, object value, ParameterDirection direction)
            : this(name, type, value, direction, string.IsNullOrEmpty(name))
        {
        }

        /// <summary>
        /// Initializes a new instance, with positionality explicity set.
        /// </summary>
        /// <remarks>
        /// Non-positional parameters must be given a name and an exception is thrown otherwise.
        /// Positional parameters may still have a name.
        /// </remarks>
        /// <param name="name">The name of the parameter. Empty string for positional parameters.</param>
        /// <param name="type">The type of the parameter.</param>
        /// <param name="value">The value of the parameter.</param>
        /// <param name="direction">The direction of the parameter.</param>
        /// <param name="positional">True if the parameter is positional, false otherwise.</param>
        /// <exception cref="InvalidOperationException">Thrown if <paramref name="positional"/> is false and <paramref name="name"/> is null or empty.</exception>
        public ParsedSqlParameter(string name, DbType type, object value, ParameterDirection direction, bool positional)
        {
            switch (type)
            {
                case DbType.Int64:
                case DbType.Int32:
                case DbType.Int16:
                case DbType.Byte:
                case DbType.Boolean:
                case DbType.Decimal:
                case DbType.Double:
                case DbType.Single:
                case DbType.DateTime:
                case DbType.String:
                case DbType.Binary:
                case DbType.Object:
                case DbType.Guid:
                    {
                        this.type = type;
                        break;
                    }

                default:
                    {
                        throw new InvalidOperationException(string.Format(CultureInfo.CurrentCulture, Messages.UnexpectedDbType, type.ToString()));
                    }
            }

            if (string.IsNullOrEmpty(name) && !positional)
            {
                throw new InvalidOperationException(string.Format(CultureInfo.CurrentCulture, Messages.NonPositionalParameterRequiresAName));
            }

            this.name = name;
            this.value = value;
            this.direction = direction;
            this.positional = positional;
        }

        /// <summary>
        /// Gets the name of the parameter.
        /// </summary>
        /// <remarks>
        /// <para>Use the empty string for positional parameters.</para>
        /// </remarks>
        /// <value>The name of the parameter.</value>
        public string Name
        {
            get { return this.name; }
        }

        /// <summary>
        /// Gets the type of the parameter.
        /// </summary>
        /// <value>The type of the parameter.</value>
        public DbType Type
        {
            get { return this.type; }
        }

        /// <summary>
        /// Gets the value of the parameter.
        /// </summary>
        /// <remarks>
        /// If the value is <c>DBNull.Value</c> then the appropriate <c>SqlTypes</c> null value is returned.
        /// </remarks>
        /// <value>The value of the parameter.</value>
        public object Value
        {
            get
            {
                object ans;

                if (this.value == DBNull.Value)
                {
                    ans = GetNullValueForDbType(this.type);
                }
                else
                {
                    ans = this.value;
                }

                return ans;
            }
        }

        /// <summary>
        /// Gets the direction of the parameter.
        /// </summary>
        /// <value>The direction of the parameter.</value>
        public ParameterDirection Direction
        {
            get { return this.direction; }
        }

        /// <summary>
        /// Gets the .NET type that the parameter corresponds to.
        /// </summary>
        /// <value>The .NET type that the parameter corresponds to.</value>
        /// <returns>The .NET type.</returns>
        public Type NetType
        {
            get
            {
                Type ans;

                if (this.type == DbType.Object)
                {
                    if (this.value == null || this.value == DBNull.Value)
                    {
                        ans = typeof(object);
                    }
                    else
                    {
                        ans = typeof(Nullable<>).MakeGenericType(MapNonObjectTypeToNetType(this.value.GetType()));
                    }
                }
                else
                {
                    ans = MapNonObjectDbTypeToNetType(this.type);
                }

                return ans;
            }
        }

        /// <summary>
        /// Gets a value indicating whether the parameter is positional or named.
        /// </summary>
        /// <remarks>
        /// Positional parameters may still have a name.
        /// </remarks>
        /// <value>True if the parameter is positional, false if it is named.</value>
        public bool Positional
        {
            get
            {
                return this.positional;
            }
        }

        /// <summary>
        /// Tests for equality.
        /// </summary>
        /// <para>
        /// Comparison is by parameter name only.
        /// </para>
        /// <param name="obj">The object to compare to.</param>
        /// <returns>True if equal, false otherwise.</returns>
        public override bool Equals(System.Object obj)
        {
            if (obj == null)
            {
                return false;
            }

            ParsedSqlParameter p = obj as ParsedSqlParameter;
            if (p == null)
            {
                return false;
            }

            return string.Compare(this.name, p.name, StringComparison.OrdinalIgnoreCase) == 0;
        }

        /// <summary>
        /// Tests for equality.
        /// </summary>
        /// <remarks>
        /// <para>
        /// Comparison is by parameter name only.
        /// </para>
        /// </remarks>
        /// <param name="p">The parameter to compare to.</param>
        /// <returns>True if equal, false otherwise.</returns>
        public bool Equals(ParsedSqlParameter p)
        {
            if (p == null)
            {
                return false;
            }

            return string.Compare(this.name, p.name, StringComparison.OrdinalIgnoreCase) == 0;
        }

        /// <summary>
        /// Gets the hash code for the token.
        /// </summary>
        /// <returns>The hash code for the token.</returns>
        public override int GetHashCode()
        {
            return this.name.ToLowerInvariant().GetHashCode();
        }

        private static Type MapNonObjectDbTypeToNetType(DbType type)
        {
            Type ans;
            switch (type)
            {
                case DbType.Int64:
                    {
                        ans = typeof(Nullable<SqlInt64>);
                        break;
                    }

                case DbType.Int32:
                    {
                        ans = typeof(Nullable<SqlInt32>);
                        break;
                    }

                case DbType.Int16:
                    {
                        ans = typeof(Nullable<SqlInt16>);
                        break;
                    }

                case DbType.Byte:
                    {
                        ans = typeof(Nullable<SqlByte>);
                        break;
                    }

                case DbType.Boolean:
                    {
                        ans = typeof(Nullable<SqlBoolean>);
                        break;
                    }

                case DbType.Decimal:
                    {
                        ans = typeof(Nullable<SqlDecimal>);
                        break;
                    }

                case DbType.Double:
                    {
                        ans = typeof(Nullable<SqlDouble>);
                        break;
                    }

                case DbType.Single:
                    {
                        ans = typeof(Nullable<SqlSingle>);
                        break;
                    }

                case DbType.DateTime:
                    {
                        ans = typeof(Nullable<SqlDateTime>);
                        break;
                    }

                case DbType.String:
                    {
                        ans = typeof(Nullable<SqlString>);
                        break;
                    }

                case DbType.Binary:
                    {
                        ans = typeof(Nullable<SqlBinary>);
                        break;
                    }

                case DbType.Guid:
                    {
                        ans = typeof(Nullable<SqlGuid>);
                        break;
                    }

                default:
                    {
                        throw new InvalidOperationException(string.Format(CultureInfo.CurrentCulture, Messages.UnexpectedDbType, type.ToString()));
                    }
            }

            return ans;
        }

        private static Type MapNonObjectTypeToNetType(Type type)
        {
            Type ans;

            if (type == typeof(Int64))
            {
                ans = typeof(SqlInt64);
            }
            else if (type == typeof(Int32))
            {
                ans = typeof(SqlInt32);
            }
            else if (type == typeof(Int16))
            {
                ans = typeof(SqlInt16);
            }
            else if (type == typeof(Byte))
            {
                ans = typeof(SqlByte);
            }
            else if (type == typeof(Boolean))
            {
                ans = typeof(SqlBoolean);
            }
            else if (type == typeof(Decimal))
            {
                ans = typeof(SqlDecimal);
            }
            else if (type == typeof(Double))
            {
                ans = typeof(SqlDouble);
            }
            else if (type == typeof(Single))
            {
                ans = typeof(SqlSingle);
            }
            else if (type == typeof(DateTime))
            {
                ans = typeof(SqlDateTime);
            }
            else if (type == typeof(String))
            {
                ans = typeof(SqlString);
            }
            else if (type == typeof(Byte[]))
            {
                ans = typeof(SqlBinary);
            }
            else if (type == typeof(Guid))
            {
                ans = typeof(SqlGuid);
            }
            else
            {
                throw new InvalidOperationException(string.Format(CultureInfo.CurrentCulture, Messages.UnexpectedType, type.ToString()));
            }

            return ans;
        }

        private static object GetNullValueForDbType(DbType dbt)
        {
            object ans;

            switch (dbt)
            {
                case DbType.Int64:
                    {
                        ans = SqlInt64.Null;
                        break;
                    }

                case DbType.Int32:
                    {
                        ans = SqlInt32.Null;
                        break;
                    }

                case DbType.Int16:
                    {
                        ans = SqlInt16.Null;
                        break;
                    }

                case DbType.Byte:
                    {
                        ans = SqlByte.Null;
                        break;
                    }

                case DbType.Boolean:
                    {
                        ans = SqlBoolean.Null;
                        break;
                    }

                case DbType.Decimal:
                    {
                        ans = SqlDecimal.Null;
                        break;
                    }

                case DbType.Double:
                    {
                        ans = SqlDouble.Null;
                        break;
                    }

                case DbType.Single:
                    {
                        ans = SqlSingle.Null;
                        break;
                    }

                case DbType.DateTime:
                    {
                        ans = SqlDateTime.Null;
                        break;
                    }

                case DbType.String:
                    {
                        ans = SqlString.Null;
                        break;
                    }

                case DbType.Binary:
                    {
                        ans = SqlBinary.Null;
                        break;
                    }

                case DbType.Guid:
                    {
                        ans = SqlGuid.Null;
                        break;
                    }

                default:
                    {
                        ans = DBNull.Value;
                        break;
                    }
            }

            return ans;
        }
    }
}
