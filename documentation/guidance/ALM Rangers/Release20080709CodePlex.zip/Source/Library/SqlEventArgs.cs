//---------------------------------------------------------------------
// <copyright file="SqlEventArgs.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
//     THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
//     OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
//     LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//     FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>The SqlEventArgs type.</summary>
//---------------------------------------------------------------------
namespace Microsoft.DatabaseLoadTest.Library
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    /// <summary>
    /// Event relating to some SQL.
    /// </summary>
    public class SqlEventArgs : EventArgs
    {
        private readonly string sql;

        /// <summary>
        /// Initializes an instance with the SQL to which the event relates.
        /// </summary>
        /// <param name="sql">The SQL that the event relates to.</param>
        public SqlEventArgs(string sql)
        {
            this.sql = sql;
        }

        /// <summary>
        /// Gets the SQL that the event relates to.
        /// </summary>
        /// <value>The SQL that the event relates to.</value>
        public string Sql
        {
            get { return this.sql; }
        }
    }
}