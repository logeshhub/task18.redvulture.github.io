//---------------------------------------------------------------------
// <copyright file="SqlParser.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
//     THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
//     OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
//     LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//     FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>The SqlParser type.</summary>
//---------------------------------------------------------------------

namespace Microsoft.DatabaseLoadTest.Library
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Globalization;
    using System.Data;
    using System.Text;

    /// <summary>
    /// Parses trace records containing SQL strings into <see cref="ParsedSqlCommand"/> objects.
    /// </summary>
    /// <remarks>
    /// <para>
    /// The parser takes the SQL in a trace record. If it is given unparameterised SQL it just wraps the SQL. Otherwise it
    /// processes parameterised SQL, this can be a stored procedure invocation or a
    /// batch of SQL commands that are parameterised.
    /// </para>
    /// </remarks>
    public class SqlParser
    {
        private static SqlToken equalsToken = new SqlToken(SqlTokenType.Operator, "=");
        private static SqlToken commaToken = new SqlToken(SqlTokenType.Operator, ",");
        private static SqlToken rightParenthesisToken = new SqlToken(SqlTokenType.Operator, ")");
        private static SqlToken declareToken = new SqlToken(SqlTokenType.Word, "declare");
        private static SqlToken setToken = new SqlToken(SqlTokenType.Word, "set");
        private static SqlToken execToken = new SqlToken(SqlTokenType.Word, "exec");
        private static SqlToken outputToken = new SqlToken(SqlTokenType.Word, "output");
        private static SqlToken nullToken = new SqlToken(SqlTokenType.Word, "null");
        private static SqlToken defaultToken = new SqlToken(SqlTokenType.Word, "default");

        private string sql;
        private SqlTokenizer tokenizer;

        /// <summary>
        /// Parses the SQL string in the trace record into a <see cref="ParsedSqlCommand"/> object.
        /// </summary>
        /// <param name="traceRecord">The trace record containing a SQL string to be parsed.</param>
        /// <returns>A <see cref="ParsedSqlCommand"/> object representing the SQL command.</returns>
        public ParsedSqlCommand ParseTraceRecord(TraceRecord traceRecord)
        {
            if (traceRecord == null)
            {
                throw new ArgumentNullException("traceRecord");
            }
            else if (traceRecord.EventClass != TraceRecord.SqlBatchStartingEventClass && traceRecord.EventClass != TraceRecord.RpcStartingEventClass)
            {
                throw new ArgumentOutOfRangeException("traceRecord");
            }
            else if (string.IsNullOrEmpty(traceRecord.TextData))
            {
                throw new ArgumentNullException("traceRecord");
            }

            ParsedSqlCommand ans = null;
            if (traceRecord.EventClass == TraceRecord.SqlBatchStartingEventClass || traceRecord.TextData.StartsWith("--"))
            {
                ans = new ParsedSqlCommand(traceRecord.TextData, CommandType.Text, new List<ParsedSqlParameter>());
            }
            else
            {
                this.sql = traceRecord.TextData;
                this.tokenizer = new SqlTokenizer(this.sql);

                try
                {
                    IList<ParsedSqlParameter> outputVariables = new List<ParsedSqlParameter>();
                    SqlTokenizerBookmark bookmark = this.tokenizer.Bookmark;
                    SqlToken firstToken = this.tokenizer.ParseNextToken();
                    if (firstToken.Equals(declareToken))
                    {
                        this.tokenizer.GoToBookmark(bookmark);
                        firstToken = this.ParseOutputVariableSetup(outputVariables);
                    }

                    if (!firstToken.Equals(execToken))
                    {
                        throw new InvalidOperationException(Messages.SqlParser_MissingExec);
                    }

                    SqlToken storedProcedure = this.tokenizer.ParseNextToken();
                    if (storedProcedure.Equals(new SqlToken(SqlTokenType.Word, "sp_executesql")))
                    {
                        ans = this.ParseParameterisedSqlCommand(outputVariables);
                    }
                    else
                    {
                        ans = this.ParseStoredProcedureCall(storedProcedure, outputVariables);
                    }
                }
                catch (Exception ex)
                {
                    throw new InvalidOperationException(string.Format(CultureInfo.CurrentCulture, Messages.SqlParser_ParsingError, this.sql, ex.Message), ex);
                }
            }

            return ans;
        }

        private static ParsedSqlParameter FindParameter(IList<ParsedSqlParameter> predeclaredParameters, string parameterName)
        {
            ParsedSqlParameter ans = null;

            foreach (ParsedSqlParameter p in predeclaredParameters)
            {
                if (p.Name == parameterName)
                {
                    ans = p;
                    break;
                }
            }

            return ans;
        }

        /// <summary>
        /// Checks if <paramref name="token"/> represents an actual parameter.
        /// </summary>
        /// <remarks>
        /// <para>
        /// An actual parameter is either a variable reference, a literal value, or a null word.
        /// </para>
        /// </remarks>
        /// <param name="token">The token to check.</param>
        /// <returns>True if the token represents an actual parameter.</returns>
        private static bool IsActualParameter(SqlToken token)
        {
            bool ans = false;
            ans = token != null
                  &&
                  (token.TokenType == SqlTokenType.HexadecimalLiteral
                   ||
                   token.TokenType == SqlTokenType.NumberLiteral
                   ||
                   token.TokenType == SqlTokenType.StringLiteral
                   ||
                   token.TokenType == SqlTokenType.Variable
                   ||
                   token.Equals(nullToken));
            return ans;
        }

        private static IList<ParsedSqlParameter> ParseParameterDeclarationString(string declarations)
        {
            IList<ParsedSqlParameter> declaredParameters = new List<ParsedSqlParameter>();
            SqlTokenizer declTokenizer = new SqlTokenizer(declarations);

            SqlToken name;
            SqlToken type;
            while ((name = declTokenizer.ParseNextToken()) != null)
            {
                type = declTokenizer.ParseNextToken();
                DbType parameterType = MapTypeToDbType(type.Value);
                declaredParameters.Add(new ParsedSqlParameter(name.Value, parameterType, null, ParameterDirection.Input));

                // Discard any other stuff in parentheses
                SqlToken dummy;
                dummy = declTokenizer.ParseNextToken();
                if (dummy != null && !dummy.Equals(commaToken))
                {
                    do
                    {
                        dummy = declTokenizer.ParseNextToken();
                    }
                    while (dummy != null && !dummy.Equals(rightParenthesisToken));
                    dummy = declTokenizer.ParseNextToken(); // comma
                    if (dummy == null)
                    {
                        break;
                    }
                }
            }

            return declaredParameters;
        }

        // TODO: Refactor all mappings and validations into one place

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502")]
        private static DbType MapTypeToDbType(string sqlTypeString)
        {
            DbType ans;
            switch (sqlTypeString)
            {
                case "bigint":
                    {
                        ans = DbType.Int64;
                        break;
                    }

                case "int":
                    {
                        ans = DbType.Int32;
                        break;
                    }

                case "smallint":
                    {
                        ans = DbType.Int16;
                        break;
                    }

                case "tinyint":
                    {
                        ans = DbType.Byte;
                        break;
                    }

                case "bit":
                    {
                        ans = DbType.Boolean;
                        break;
                    }

                case "decimal":
                case "numeric":
                case "money":
                case "smallmoney":
                    {
                        ans = DbType.Decimal;
                        break;
                    }

                case "float":
                    {
                        ans = DbType.Double;
                        break;
                    }

                case "real":
                    {
                        ans = DbType.Single;
                        break;
                    }

                case "datetime":
                case "smalldatetime":
                    {
                        ans = DbType.DateTime;
                        break;
                    }

                case "char":
                case "varchar":
                case "text":
                case "nchar":
                case "nvarchar":
                case "ntext":
                    {
                        ans = DbType.String;
                        break;
                    }

                case "binary":
                case "varbinary":
                case "image":
                case "timestamp":
                    {
                        ans = DbType.Binary;
                        break;
                    }

                case "sql_variant":
                    {
                        ans = DbType.Object;
                        break;
                    }

                case "uniqueidentifier":
                    {
                        ans = DbType.Guid;
                        break;
                    }

                default:
                    {
                        throw new InvalidOperationException(string.Format(CultureInfo.CurrentCulture, Messages.SqlParser_TypeNotImplemented, sqlTypeString));
                    }
            }

            return ans;
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502")]
        private static Object MapValueToObject(DbType sqlType, SqlToken sqlValue)
        {
            Object ans;
            if (sqlValue.Equals(nullToken))
            {
                ans = DBNull.Value;
            }
            else if (sqlValue.Equals(defaultToken))
            {
                ans = null;
            }
            else if (sqlType == DbType.Object)
            {
                switch (sqlValue.TokenType)
                {
                    case SqlTokenType.StringLiteral:
                        {
                            ans = sqlValue.Value;
                            break;
                        }

                    case SqlTokenType.NumberLiteral:
                        {
                            Int64 temp;
                            if (Int64.TryParse(sqlValue.Value, NumberStyles.None, null, out temp))
                            {
                                ans = temp;
                            }
                            else
                            {
                                ans = Double.Parse(sqlValue.Value, null);
                            }

                            break;
                        }

                    case SqlTokenType.HexadecimalLiteral:
                        {
                            ans = ConvertHexLiteralToByteArray(sqlValue);
                            break;
                        }

                    default:
                        {
                            throw new InvalidOperationException(string.Format(CultureInfo.CurrentCulture, Messages.SqlParser_ExpectedLiteralTokenType, sqlValue.TokenType, sqlValue.Value));
                        }
                }
            }
            else
            {
                switch (sqlType)
                {
                    case DbType.Int64:
                        {
                            ans = Int64.Parse(sqlValue.Value, null);
                            break;
                        }

                    case DbType.Int32:
                        {
                            ans = Int32.Parse(sqlValue.Value, null);
                            break;
                        }

                    case DbType.Int16:
                        {
                            ans = Int16.Parse(sqlValue.Value, null);
                            break;
                        }

                    case DbType.Byte:
                        {
                            ans = Byte.Parse(sqlValue.Value, null);
                            break;
                        }

                    case DbType.Boolean:
                        {
                            if (sqlValue.Value == "1")
                            {
                                ans = true;
                            }
                            else
                            {
                                ans = false;
                            }

                            break;
                        }

                    case DbType.Decimal:
                        {
                            ans = Decimal.Parse(sqlValue.Value, null);
                            break;
                        }

                    case DbType.Double:
                        {
                            ans = Double.Parse(sqlValue.Value, null);
                            break;
                        }

                    case DbType.Single:
                        {
                            ans = Single.Parse(sqlValue.Value, null);
                            break;
                        }

                    case DbType.DateTime:
                        {
                            // TODO: Require ExistingConnection event class in the trace to get the language and date format settings
                            ans = DateTime.ParseExact(sqlValue.Value, Resources.DateTimeFormat, null, DateTimeStyles.AllowWhiteSpaces);
                            break;
                        }

                    case DbType.String:
                        {
                            ans = sqlValue.Value;
                            break;
                        }

                    case DbType.Binary:
                        {
                            ans = ConvertHexLiteralToByteArray(sqlValue);
                            break;
                        }

                    case DbType.Object:
                        {
                            ans = sqlValue.Value;
                            break;
                        }

                    case DbType.Guid:
                        {
                            ans = new Guid(sqlValue.Value);
                            break;
                        }

                    default:
                        {
                            throw new InvalidOperationException(string.Format(CultureInfo.CurrentCulture, Messages.SqlParser_DbTypeNotImplemented, sqlType));
                        }
                }
            }

            return ans;
        }

        private static Object ConvertHexLiteralToByteArray(SqlToken sqlValue)
        {
            Object ans;
            List<byte> bytes = new List<byte>();
            for (int i = 0; i < sqlValue.Value.Length / 2; i++)
            {
                bytes.Add(byte.Parse(sqlValue.Value.Substring(i * 2, 2), NumberStyles.AllowHexSpecifier, null));
            }

            ans = bytes.ToArray();
            return ans;
        }

        /// <summary>
        /// Parses the declarations for output parameters in the T-SQL preceding the actual call. Expects a series of declare and set
        /// statements terminated by an exec statement. Expects the first token to be "declare".
        /// </summary>
        /// <param name="parameters">The list to which output parameters are added.</param>
        /// <returns>The token which terminates the declarations of the output parameters.</returns>
        private SqlToken ParseOutputVariableSetup(IList<ParsedSqlParameter> parameters)
        {
            SqlToken statement = this.tokenizer.ParseNextToken();
            Debug.Assert(statement.Equals(declareToken));

            while (!statement.Equals(execToken))
            {
                SqlToken variableName = this.tokenizer.ParseNextToken();
                SqlToken variableType = this.tokenizer.ParseNextToken();

                // Ignore everything up to the next set statement
                do
                {
                    statement = this.tokenizer.ParseNextToken();
                }
                while (!statement.Equals(setToken));

                statement = this.tokenizer.ParseNextToken();
                Debug.Assert(statement.Equals(variableName));
                statement = this.tokenizer.ParseNextToken();
                Debug.Assert(statement.Equals(equalsToken));
                SqlToken value = this.tokenizer.ParseNextToken();

                DbType parameterType = MapTypeToDbType(variableType.Value);
                Object valueObject = MapValueToObject(parameterType, value);

                parameters.Add(new ParsedSqlParameter(variableName.Value, parameterType, valueObject, (value.Equals(nullToken)) ? ParameterDirection.Output : ParameterDirection.InputOutput));

                // Ignore everything up to the next declare or exec
                do
                {
                    statement = this.tokenizer.ParseNextToken();
                }
                while (!statement.Equals(declareToken) && !statement.Equals(execToken));
            }

            return statement;
        }

        // TODO: XML data type?

        private ParsedSqlCommand ParseParameterisedSqlCommand(IList<ParsedSqlParameter> outputVariables)
        {
            SqlToken statement = this.tokenizer.ParseNextToken();
            Debug.Assert(statement.TokenType == SqlTokenType.StringLiteral);

            IList<ParsedSqlParameter> parameters = new List<ParsedSqlParameter>();

            SqlToken comma = this.tokenizer.ParseNextToken();
            if (comma != null)
            {
                Debug.Assert(comma.Equals(commaToken));

                IList<ParsedSqlParameter> declaredParameters = ParseParameterDeclarationString(this.tokenizer.ParseNextToken().Value);
                comma = this.tokenizer.ParseNextToken();
                Debug.Assert(comma.Equals(commaToken));
                parameters = this.ParseActualParameterList(declaredParameters, outputVariables);
            }

            return new ParsedSqlCommand(statement.Value, CommandType.Text, parameters);
        }

        private ParsedSqlCommand ParseStoredProcedureCall(SqlToken storedProcedure, IList<ParsedSqlParameter> predeclaredParameters)
        {
            List<ParsedSqlParameter> parameters = this.ParseActualParameterList(new List<ParsedSqlParameter>(), predeclaredParameters);

            return new ParsedSqlCommand(storedProcedure.Value, CommandType.StoredProcedure, parameters);
        }

        /// <summary>
        /// Parses an actual parameter list, which is a series of comma-separated parameters. 
        /// </summary>
        /// <remarks>
        /// <para>
        /// An actual parameter can take one of two forms. It is either @var=value, or just a
        /// literal value or a null. In the positional case this method assigns empty names to the parameters,
        /// however it assumes that all parameters are of the same form, no mixing is allowed.
        /// </para>
        /// </remarks>
        /// <param name="declaredParameters">Information about any parameters that have already been declared and for which information is already available.</param>
        /// <param name="outputVariables">Information about any variables declared and setup before the statement, for passing initial values to output parameters.</param>
        /// <returns>List of <see cref="ParsedSqlParameter"/>s representing the actual parameters that need to be passed.</returns>
        private List<ParsedSqlParameter> ParseActualParameterList(IList<ParsedSqlParameter> declaredParameters, IList<ParsedSqlParameter> outputVariables)
        {
            List<ParsedSqlParameter> parameters = new List<ParsedSqlParameter>();

            SqlToken actual = this.tokenizer.ParseNextToken();
            while (actual != null)
            {
                Debug.Assert(IsActualParameter(actual));

                string parameterName;
                DbType parameterType = DbType.Object;
                Object parameterValue;
                //ParameterDirection parameterDirection;

                SqlToken value;

                if (actual.TokenType == SqlTokenType.Variable)
                {
                    // Named parameter
                    parameterName = actual.Value;
                    SqlToken next = this.tokenizer.ParseNextToken();

                    if (next.Equals(equalsToken))
                    {
                        // Process a parameter that is assigned a value
                        value = this.tokenizer.ParseNextToken();
                        ParsedSqlParameter existingParameter = FindParameter(declaredParameters, parameterName);
                        if (existingParameter != null)
                        {
                            parameterType = existingParameter.Type;
                            //parameterDirection = existingParameter.Direction;
                        }

                        if (value.TokenType == SqlTokenType.Variable)
                        {
                            // Output parameter with assignment to an output variable
                            ParsedSqlParameter output = FindParameter(outputVariables, value.Value);
                            Debug.Assert(output != null, "Output parameter not assigned a predeclared output variable");
                            parameterType = output.Type;
                            parameterValue = output.Value;
                            SqlToken outputWord = this.tokenizer.ParseNextToken();
                            Debug.Assert(outputWord.Equals(outputToken));
                            parameters.Add(new ParsedSqlParameter(parameterName, parameterType, parameterValue, output.Direction));
                        }
                        else if (value.Equals(outputToken))
                        {
                            // Output parameter with no assignment, used as-is.
                            ParsedSqlParameter output = FindParameter(outputVariables, parameterName);
                            Debug.Assert(output != null, "Output parameter not predeclared");
                            parameters.Add(output);
                        }
                        else
                        {
                            // Literal value
                            parameters.Add(new ParsedSqlParameter(parameterName, parameterType, MapValueToObject(parameterType, value), ParameterDirection.Input));
                        }
                    }
                    else
                    {
                        // Process a parameter that is not assigned in the exec but assigned earlier in the batch as an output
                        Debug.Assert(next.Equals(outputToken));
                        ParsedSqlParameter output = FindParameter(outputVariables, parameterName);
                        Debug.Assert(output != null, "Output parameter not using a predeclared output variable");
                        parameters.Add(new ParsedSqlParameter(output.Name, output.Type, output.Value, ParameterDirection.Output));
                    }
                }
                else
                {
                    // Positional parameter
                    parameterName = string.Empty;
                    value = actual;
                    // Ignore direction as parsed during output variable setup as the parameter is not actually assigned.
                    parameters.Add(new ParsedSqlParameter(parameterName, parameterType, MapValueToObject(parameterType, value), ParameterDirection.Input));
                }

                SqlToken separator = this.tokenizer.ParseNextToken();
                if (separator == null || !separator.Equals(commaToken))
                {
                    break;
                }

                actual = this.tokenizer.ParseNextToken();
            }

            return parameters;
        }
    }
}
