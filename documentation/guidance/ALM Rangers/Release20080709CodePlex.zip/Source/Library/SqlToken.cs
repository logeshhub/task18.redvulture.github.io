//---------------------------------------------------------------------
// <copyright file="SqlToken.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
//     THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
//     OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
//     LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//     FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>The SqlToken types.</summary>
//---------------------------------------------------------------------

namespace Microsoft.DatabaseLoadTest.Library
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.Text;

    /// <summary>
    /// Enumerates the types of tokens.
    /// </summary>
    public enum SqlTokenType
    {
        /// <summary>
        /// An operator.
        /// </summary>
        Operator,

        /// <summary>
        /// Any keyword or object reference.
        /// </summary>
        Word,

        /// <summary>
        /// A variable reference, using the @ syntax.
        /// </summary>
        Variable,

        /// <summary>
        /// A string literal.
        /// </summary>
        StringLiteral,

        /// <summary>
        /// A hexadecimal literal. One that starts 0x.
        /// </summary>
        HexadecimalLiteral,

        /// <summary>
        /// A numeric literal. Includes integers, decimals and floats.
        /// </summary>
        NumberLiteral
    }

    /// <summary>
    /// Represents the unit of tokenization.
    /// </summary>
    public class SqlToken
    {
        private readonly SqlTokenType tokenType;
        private readonly string tokenValue;

        /// <summary>
        /// Initializes an instance with the token details.
        /// </summary>
        /// <param name="tokenType">The type of the token.</param>
        /// <param name="tokenValue">The value of the token.</param>
        public SqlToken(SqlTokenType tokenType, string tokenValue)
        {
            this.tokenType = tokenType;
            this.tokenValue = tokenValue;
        }

        /// <summary>
        /// Gets the type of the token.
        /// </summary>
        /// <value>The type of the token.</value>
        public SqlTokenType TokenType
        {
            get { return this.tokenType; }
        }

        /// <summary>
        /// Gets the value of the token.
        /// </summary>
        /// <value>The value of the token.</value>
        public string Value
        {
            get { return this.tokenValue; }
        }

        /// <summary>
        /// Tests for equality.
        /// </summary>
        /// <para>
        /// The value comparison is case-insensitive.
        /// </para>
        /// <param name="obj">The object to compare to.</param>
        /// <returns>True if equal, false otherwise.</returns>
        public override bool Equals(System.Object obj)
        {
            if (obj == null)
            {
                return false;
            }

            SqlToken t = obj as SqlToken;
            if (t == null)
            {
                return false;
            }

            return (this.tokenType == t.tokenType) && string.Compare(this.tokenValue, t.tokenValue, StringComparison.OrdinalIgnoreCase) == 0;
        }

        /// <summary>
        /// Tests for equality.
        /// </summary>
        /// <remarks>
        /// <para>
        /// The value comparison is case-insensitive.
        /// </para>
        /// </remarks>
        /// <param name="t">The token to compare to.</param>
        /// <returns>True if equal, false otherwise.</returns>
        public bool Equals(SqlToken t)
        {
            if (t == null)
            {
                return false;
            }

            return (this.tokenType == t.tokenType) && string.Compare(this.tokenValue, t.tokenValue, StringComparison.OrdinalIgnoreCase) == 0;
        }

        /// <summary>
        /// Gets the hash code for the token.
        /// </summary>
        /// <returns>The hash code for the token.</returns>
        public override int GetHashCode()
        {
            string agg = this.tokenType.ToString() + this.tokenValue.ToUpperInvariant();
            return agg.GetHashCode();
        }

        /// <summary>
        /// Returns the string representation of the token.
        /// </summary>
        /// <returns>String representation of the token.</returns>
        public override string ToString()
        {
            return string.Format(CultureInfo.CurrentCulture, "{0}: {1}", this.tokenType.ToString(), this.tokenValue);
        }
    }
}
