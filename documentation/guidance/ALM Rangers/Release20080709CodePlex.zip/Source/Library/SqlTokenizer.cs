//---------------------------------------------------------------------
// <copyright file="SqlTokenizer.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
//     THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
//     OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
//     LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//     FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>The SqlTokenizer types.</summary>
//---------------------------------------------------------------------

// TODO: Full SQL syntax for identifiers is not followed (square brackets now done, but check finer points ms-help://MS.SQLCC.v9/MS.SQLSVR.v9.en/udb9/html/171291bb-f57f-4ad1-8cea-0b092d5d150c.htm)

namespace Microsoft.DatabaseLoadTest.Library
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    /// <summary>
    /// Parses a TSQL string for tokens.
    /// </summary>
    /// <remarks>
    /// <para>
    /// A subset of TSQL is tokenized. This tokenizer only deals with:
    /// </para>
    /// <list type="bullet">
    /// <item>Keyword, object references (no distinction is made between these items).</item>
    /// <item>Operators.</item>
    /// <item>Variable names (@ syntax).</item>
    /// <item>String literals.</item>
    /// <item>Numbers (including hexadecimal).</item>
    /// </list>
    /// <para>
    /// The tokenizer supports full delimited identifiers, with escaping of square brackets, special characters
    /// inside square brackets.
    /// </para>
    /// <para>
    /// The tokenizer assumes that it will be given correct SQL and so does not check for malformed tokens. For
    /// example '+123+456E0.1' would parse as a valid numeric literal.
    /// </para>
    /// </remarks>
    public class SqlTokenizer
    {
        private readonly string sql;
        private int currentCharOffset;

        /// <summary>
        /// Initializes an instance with the SQL to be tokenized.
        /// </summary>
        /// <param name="sql">The SQL string to be tokenized.</param>
        public SqlTokenizer(string sql)
        {
            if (sql == null)
            {
                throw new ArgumentNullException("sql");
            }

            this.sql = sql;
        }

        /// <summary>
        /// Gets the bookmark indicating the current position in the input string.
        /// </summary>
        /// <value>The bookmark indicating the current position in the input string.</value>
        public SqlTokenizerBookmark Bookmark
        {
            get
            {
                return new SqlTokenizerBookmark(this.currentCharOffset);
            }
        }

        private char CurrentChar
        {
            get
            {
                return this.sql[this.currentCharOffset];
            }
        }

        private char NextChar
        {
            get
            {
                char ans = (char)0;
                if (this.currentCharOffset <= this.sql.Length - 2)
                {
                    ans = this.sql[this.currentCharOffset + 1];
                }

                return ans;
            }
        }

        /// <summary>
        /// Moves the tokenizer to the given bookmark, so that the next token parsed will be the one that
        /// was next when the bookmark was recorded.
        /// </summary>
        /// <param name="bookmark">The bookmark to go to.</param>
        public void GoToBookmark(SqlTokenizerBookmark bookmark)
        {
            if (bookmark == null)
            {
                throw new ArgumentNullException("bookmark");
            }

            this.currentCharOffset = bookmark.Offset;
        }

        /// <summary>
        /// Parses the next token in the SQL that was passed to the constructor.
        /// </summary>
        /// <returns>The next <see cref="SqlToken"/> or <c>null</c> if there are no more tokens.</returns>
        public SqlToken ParseNextToken()
        {
            SqlToken ans = null;
            if (!this.AtEnd() && this.SkipWhitespace())
            {
                if (this.IsStartOfOperator())
                {
                    ans = this.ProcessOperator();
                }
                else if (this.IsStartOfStringLiteral())
                {
                    ans = this.ProcessStringLiteral();
                }
                else if (this.IsStartOfVariable())
                {
                    ans = this.ProcessVariable();
                }
                else if (this.IsStartOfWord())
                {
                    ans = this.ProcessWord();
                }
                else if (this.IsStartOfHexadecimalNumber())
                {
                    ans = this.ProcessHexadecimalNumber();
                }
                else if (this.IsStartOfNumber())
                {
                    ans = this.ProcessNumber();
                }
            }

            return ans;
        }

        private SqlToken ProcessOperator()
        {
            SqlToken ans = new SqlToken(SqlTokenType.Operator, new string(this.CurrentChar, 1));
            this.MoveToNext();
            return ans;
        }

        private bool IsStartOfOperator()
        {
            char c = this.CurrentChar;
            return c == ',' || c == '=' || c == '(' || c == ')';
        }

        private SqlToken ProcessVariable()
        {
            StringBuilder tokenValue = new StringBuilder();
            do
            {
                tokenValue.Append(this.CurrentChar);
                if (!this.MoveToNext())
                {
                    break;
                }
            }
            while (this.IsContinuationOfVariable());
            return new SqlToken(SqlTokenType.Variable, tokenValue.ToString());
        }

        private bool IsStartOfVariable()
        {
            return this.CurrentChar == '@';
        }

        private bool IsContinuationOfVariable()
        {
            char c = this.CurrentChar;
            return char.IsLetterOrDigit(c) || c == '_';
        }

        private SqlToken ProcessWord()
        {
            int delimitLevel = 0;
            StringBuilder tokenValue = new StringBuilder();
            do
            {
                tokenValue.Append(this.CurrentChar);
                if (this.CurrentChar == '[')
                {
                    delimitLevel++;
                }
                else if (this.CurrentChar == ']')
                {
                    delimitLevel--;
                }

                if (!this.MoveToNext())
                {
                    break;
                }
            }
            while (this.IsContinuationOfWord(delimitLevel > 0));
            return new SqlToken(SqlTokenType.Word, tokenValue.ToString());
        }

        private bool IsStartOfWord()
        {
            char c = this.CurrentChar;
            return char.IsLetter(c) || c == '_' || c == '[';
        }

        private bool IsContinuationOfWord(bool insideDelimited)
        {
            bool ans;
            char c = this.CurrentChar;
            if (insideDelimited)
            {
                ans = true;
            }
            else
            {
                ans = char.IsLetterOrDigit(c) || c == '.' || c == '_' || c == '[' || c == ']';
            }

            return ans;
        }

        private SqlToken ProcessStringLiteral()
        {
            StringBuilder tokenValue = new StringBuilder();
            char quote = this.CurrentChar;
            while (this.MoveToNext())
            {
                char c = this.CurrentChar;
                if (c == quote && this.NextChar == quote)
                {
                    this.MoveToNext();
                }
                else if (c == quote)
                {
                    this.MoveToNext();
                    break;
                }

                tokenValue.Append(c);
            }

            return new SqlToken(SqlTokenType.StringLiteral, tokenValue.ToString());
        }

        // Leaves current char on the starting quote
        private bool IsStartOfStringLiteral()
        {
            char first = this.CurrentChar;
            char c = first;
            if (c == 'N')
            {
                c = this.NextChar;
            }

            bool ans = c == '\'' || c == '"';
            if (ans && first != c)
            {
                this.MoveToNext();
            }

            return ans;
        }

        private SqlToken ProcessNumber()
        {
            StringBuilder tokenValue = new StringBuilder();
            do
            {
                tokenValue.Append(this.CurrentChar);
                if (!this.MoveToNext())
                {
                    break;
                }
            }
            while (this.IsContinuationOfNumber());
            return new SqlToken(SqlTokenType.NumberLiteral, tokenValue.ToString());
        }

        private bool IsStartOfNumber()
        {
            char c = this.CurrentChar;
            return char.IsDigit(c) || c == '+' || c == '-';
        }

        private bool IsContinuationOfNumber()
        {
            char c = this.CurrentChar;
            return char.IsDigit(c) || c == '.' || c == 'E' || c == '+' || c == '-';
        }

        private SqlToken ProcessHexadecimalNumber()
        {
            StringBuilder tokenValue = new StringBuilder();
            while (!this.AtEnd() && this.IsContinuationOfHexadecimalNumber())
            {
                tokenValue.Append(this.CurrentChar);
                if (!this.MoveToNext())
                {
                    break;
                }
            }

            return new SqlToken(SqlTokenType.HexadecimalLiteral, tokenValue.ToString());
        }

        // Leaves current char on the first character after the 0x
        private bool IsStartOfHexadecimalNumber()
        {
            char first = this.CurrentChar;
            char c = first;
            if (c == '0')
            {
                c = this.NextChar;
            }

            bool ans = c == 'x';
            if (ans && first != c)
            {
                this.MoveToNext();
                this.MoveToNext();
            }

            return ans;
        }

        private bool IsContinuationOfHexadecimalNumber()
        {
            char c = this.CurrentChar;
            return char.IsDigit(c) || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F');
        }

        /// <summary>
        /// Skips white space.
        /// </summary>
        /// <returns>True if not at the end of the string with the current character positioned
        /// at the first non-whitespace character. Returns false if the end of the string is reached.</returns>
        private bool SkipWhitespace()
        {
            bool ans = false;
            do
            {
                if (!char.IsWhiteSpace(this.CurrentChar))
                {
                    ans = true;
                    break;
                }
            }
            while (this.MoveToNext());
            return ans;
        }

        private bool AtEnd()
        {
            bool ans = false;
            if (this.currentCharOffset >= this.sql.Length)
            {
                ans = true;
            }

            return ans;
        }

        // Returns false if at the end of the string
        private bool MoveToNext()
        {
            bool ans = true;
            if (this.currentCharOffset >= this.sql.Length - 1)
            {
                this.currentCharOffset = this.sql.Length;
                ans = false;
            }
            else
            {
                this.currentCharOffset++;
            }

            return ans;
        }
    }
}
