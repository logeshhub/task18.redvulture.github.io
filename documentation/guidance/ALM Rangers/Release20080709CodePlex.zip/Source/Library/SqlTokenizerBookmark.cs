//---------------------------------------------------------------------
// <copyright file="SqlTokenizerBookmark.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
//     THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
//     OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
//     LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//     FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>The SqlTokenizerBookmark type.</summary>
//---------------------------------------------------------------------

namespace Microsoft.DatabaseLoadTest.Library
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    /// <summary>
    /// Opaque type used to allow the <see cref="SqlTokenizer"/> to go back over previously parsed text.
    /// </summary>
    public class SqlTokenizerBookmark
    {
        private int offset;

        internal SqlTokenizerBookmark(int offset)
        {
            this.offset = offset;
        }

        /// <summary>
        /// Gets the offset that was recorded as the bookmark position.
        /// </summary>
        internal int Offset
        {
            get { return this.offset; }
        }
    }
}
