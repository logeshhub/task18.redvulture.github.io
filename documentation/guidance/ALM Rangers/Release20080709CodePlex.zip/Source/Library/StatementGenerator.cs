//---------------------------------------------------------------------
// <copyright file="StatementGenerator.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
//     THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
//     OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
//     LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//     FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>The StatementGenerator type.</summary>
//---------------------------------------------------------------------

namespace Microsoft.DatabaseLoadTest.Library
{
    using System;
    using System.CodeDom;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Data.SqlTypes;
    using System.Diagnostics;
    using System.Globalization;
    using System.Text;

    /// <summary>
    /// Delegate that is allows the parameters to be customised before the final call.
    /// </summary>
    /// <param name="body">The collection of statements to which the customisation code has to be added.</param>
    /// <param name="parameterVariables">List of references to the variables which define the parameters.</param>
    /// <param name="parsedParameters">List of <see cref="ParsedSqlParameter"/> objects representing the parameters.</param>
    public delegate void CustomiseParameters(CodeStatementCollection body, IList<CodeVariableReferenceExpression> parameterVariables, IList<ParsedSqlParameter> parsedParameters);

    /// <summary>
    /// Generates code for a <see cref="ParsedSqlCommand"/>.
    /// </summary>
    public class StatementGenerator : IItemGenerator
    {
        private readonly CustomiseParameters customiseParametersCallback;
        private CodeStatementCollection bodyCode;

        /// <summary>
        /// Initializes an instance of <see cref="StatementGenerator"/>.
        /// </summary>
        /// <param name="customiseParametersCallback">Called at the point where the caller may wish to insert parameter customisation code, but only if the call has input parameters.</param>
        public StatementGenerator(CustomiseParameters customiseParametersCallback)
        {
            this.customiseParametersCallback = customiseParametersCallback;
        }

        #region IItemGenerator Members

        /// <summary>
        /// Raised when the generator needs to get a <see cref="CodeTypeReference"/> for a type.
        /// </summary>
        /// <remarks>
        /// <para>
        /// Allows the generator to delegate the importing of namespaces to the caller.
        /// </para>
        /// </remarks>
        public event EventHandler<CodeTypeReferenceRequestEventArgs> CodeTypeRequestEvent;

        /// <summary>
        /// Initialises the generator.
        /// </summary>
        /// <param name="body">The statement body that the generator must add code to.</param>
        public void Initialise(CodeStatementCollection body)
        {
            this.bodyCode = body;
        }

        #endregion

        /// <summary>
        /// Generates the code to create the given SQL command.
        /// </summary>
        /// <param name="command">The SQL command to create code for.</param>
        /// <param name="connectionArgRef">A reference to the <see cref="SqlConnection"/> parameter to use.</param>
        public void GenerateSqlCommand(ParsedSqlCommand command, CodeExpression connectionArgRef)
        {
            if (command == null)
            {
                throw new ArgumentNullException("command");
            }

            // Generate the declaration of the SqlCommand variable and also create a reference to it for later use.
            CodeVariableDeclarationStatement cmdDeclaration = new CodeVariableDeclarationStatement(this.ProcessObjectType(typeof(SqlCommand)), "cmd", new CodePrimitiveExpression(null));
            this.bodyCode.Add(cmdDeclaration);
            CodeVariableReferenceExpression cmdReference = new CodeVariableReferenceExpression(cmdDeclaration.Name);

            // Generate the try-finally
            CodeTryCatchFinallyStatement tryFinallyStatement = new CodeTryCatchFinallyStatement();
            this.bodyCode.Add(tryFinallyStatement);

            // Generate the Try statements

            // Generate the creation of a new SqlCommand

            tryFinallyStatement.TryStatements.Add(new CodeAssignStatement(cmdReference, new CodeObjectCreateExpression(this.ProcessObjectType(typeof(SqlCommand)))));

            // Generate assign of connection

            tryFinallyStatement.TryStatements.Add(new CodeAssignStatement(new CodeFieldReferenceExpression(cmdReference, "Connection"), connectionArgRef));

            // Generate assign of command type

            CodeTypeReferenceExpression commandType = new CodeTypeReferenceExpression(this.ProcessObjectType(typeof(CommandType)));

            // Generate assign of command text

            tryFinallyStatement.TryStatements.Add(new CodeAssignStatement(new CodeFieldReferenceExpression(cmdReference, "CommandType"), new CodeFieldReferenceExpression(commandType, command.CommandType.ToString())));

            tryFinallyStatement.TryStatements.Add(new CodeAssignStatement(new CodeFieldReferenceExpression(cmdReference, "CommandText"), new CodePrimitiveExpression(command.CommandText)));

            this.GenerateParameters(command, cmdReference, tryFinallyStatement.TryStatements);

            // Generate call to database

            tryFinallyStatement.TryStatements.Add(new CodeMethodInvokeExpression(cmdReference, "ExecuteNonQuery"));

            // Generate the Finally statements

            // Generate if cmd is not null
            CodeExpression cmdNotEqualsNull = new CodeBinaryOperatorExpression(cmdReference, CodeBinaryOperatorType.IdentityInequality, new CodePrimitiveExpression(null));
            CodeMethodInvokeExpression cmdDispose = new CodeMethodInvokeExpression(cmdReference, "Dispose");
            CodeConditionStatement ifCmdNotNull = new CodeConditionStatement();
            ifCmdNotNull.Condition = cmdNotEqualsNull;
            ifCmdNotNull.TrueStatements.Add(cmdDispose);
            tryFinallyStatement.FinallyStatements.Add(ifCmdNotNull);
        }

        /// <summary>
        /// Given a SQL parameter identifier generates a C# identifier for the same parameter.
        /// </summary>
        /// <param name="sqlIdentifier">The SQL parameter identifier name, must start with @.</param>
        /// <returns>The SQL parameter identifier name.</returns>
        private static string GetCSharpParameterName(string sqlIdentifier)
        {
            string ans;

            Debug.Assert(sqlIdentifier[0] == '@');
            ans = sqlIdentifier.Substring(1);

            return ans;
        }

        private void GenerateParameters(ParsedSqlCommand command, CodeVariableReferenceExpression cmdReference, CodeStatementCollection body)
        {
            // Generate parameter declarations with initializers for the input parameters

            List<CodeVariableReferenceExpression> inputOutputParameterVariableReferences = new List<CodeVariableReferenceExpression>();
            List<CodeVariableReferenceExpression> inputOutputParameterValueVariableReferences = new List<CodeVariableReferenceExpression>();
            List<CodeVariableReferenceExpression> allParameterVariableReferences = new List<CodeVariableReferenceExpression>();
            List<CodeVariableReferenceExpression> customisationVariableReferences = new List<CodeVariableReferenceExpression>();
            List<ParsedSqlParameter> customisationParameters = new List<ParsedSqlParameter>();

            // Generate SqlParameter objects for each parameter

            foreach (ParsedSqlParameter p in command.Parameters)
            {
                CodeVariableReferenceExpression parameterVariableReference = null;
                switch (p.Direction)
                {
                    case ParameterDirection.Input:
                        {
                            parameterVariableReference = this.GenerateInputParameter(body, p);
                            customisationVariableReferences.Add(parameterVariableReference);
                            customisationParameters.Add(p);
                            break;
                        }

                    case ParameterDirection.Output:
                        {
                            CodeVariableReferenceExpression dummy;
                            parameterVariableReference = this.GenerateNonInputOnlyParameter(body, out dummy, p);
                            break;
                        }

                    case ParameterDirection.InputOutput:
                        {
                            CodeVariableReferenceExpression parameterValueReference;
                            parameterVariableReference = this.GenerateNonInputOnlyParameter(body, out parameterValueReference, p);
                            inputOutputParameterVariableReferences.Add(parameterVariableReference);
                            inputOutputParameterValueVariableReferences.Add(parameterValueReference);
                            customisationVariableReferences.Add(parameterValueReference);
                            customisationParameters.Add(p);
                            break;
                        }
                }

                allParameterVariableReferences.Add(parameterVariableReference);
            }


            // Customisation call needs to go here to allow the input parameters to be modified.

            if (this.customiseParametersCallback != null && (customisationVariableReferences.Count > 0))
            {
                this.customiseParametersCallback(body, customisationVariableReferences.ToArray(), customisationParameters);
            }

            // Generate reset of input-output value based on result of customisation call

            for (int i = 0; i < command.InputOutputParameters.Count; i++)
            {
                CodeAssignStatement reassign = new CodeAssignStatement(new CodeFieldReferenceExpression(inputOutputParameterVariableReferences[i], "Value"), inputOutputParameterValueVariableReferences[i]);
                body.Add(reassign);
            }

            // Generate addition of parameters to the parameter collection

            for (int i = 0; i < command.Parameters.Count; i++)
            {
                ParsedSqlParameter p = command.Parameters[i];
                switch (p.Direction)
                {
                    case ParameterDirection.Input:
                        {
                            CodeMethodReferenceExpression addValueMethod = new CodeMethodReferenceExpression(new CodeMethodReferenceExpression(cmdReference, "Parameters"), "AddWithValue");
                            CodeMethodInvokeExpression addValueMethodCall = new CodeMethodInvokeExpression(addValueMethod, new CodePrimitiveExpression(p.Name), new CodeVariableReferenceExpression(allParameterVariableReferences[i].VariableName));
                            if (p.Positional)
                            {
                                // Reset parameter name to blank to generate a positional call because we do not know the
                                // real name of the parameter.
                                body.Add(new CodeAssignStatement(new CodeFieldReferenceExpression(addValueMethodCall, "ParameterName"), new CodeFieldReferenceExpression(new CodeTypeReferenceExpression(this.ProcessObjectType(typeof(String))), "Empty")));
                            }
                            else
                            {
                                body.Add(addValueMethodCall);
                            }
                            break;
                        }

                    case ParameterDirection.Output:
                    case ParameterDirection.InputOutput:
                        {
                            CodeMethodReferenceExpression addMethodCall = new CodeMethodReferenceExpression(new CodeMethodReferenceExpression(cmdReference, "Parameters"), "Add");
                            body.Add(new CodeMethodInvokeExpression(addMethodCall, new CodeVariableReferenceExpression(allParameterVariableReferences[i].VariableName)));
                            break;
                        }

                }
            }
        }

        private CodeVariableReferenceExpression GenerateInputParameter(CodeStatementCollection body, ParsedSqlParameter p)
        {
            CodeVariableReferenceExpression ans;

            CodeVariableDeclarationStatement parameterVariableDeclaration = new CodeVariableDeclarationStatement(this.ProcessObjectType(p.NetType), GetCSharpParameterName(p.Name), this.GenerateParameterValue(p.Value));
            body.Add(parameterVariableDeclaration);
            ans = new CodeVariableReferenceExpression(parameterVariableDeclaration.Name);

            return ans;
        }

        private CodeVariableReferenceExpression GenerateNonInputOnlyParameter(CodeStatementCollection body, out CodeVariableReferenceExpression outputParameterValueVariableReference, ParsedSqlParameter p)
        {
            CodeVariableReferenceExpression ans;

            outputParameterValueVariableReference = null;

            CodeObjectCreateExpression newSqlParam = new CodeObjectCreateExpression(this.ProcessObjectType(typeof(SqlParameter)));
            CodeVariableDeclarationStatement parameterVariableDeclaration = new CodeVariableDeclarationStatement(this.ProcessObjectType(typeof(SqlParameter)), GetCSharpParameterName(p.Name), newSqlParam);
            body.Add(parameterVariableDeclaration);
            ans = new CodeVariableReferenceExpression(parameterVariableDeclaration.Name);
            CodeAssignStatement assignName = new CodeAssignStatement(new CodeFieldReferenceExpression(ans, "ParameterName"), new CodePrimitiveExpression(p.Name));
            body.Add(assignName);
            CodeAssignStatement assignType = new CodeAssignStatement(new CodeFieldReferenceExpression(ans, "DbType"), new CodeFieldReferenceExpression(new CodeTypeReferenceExpression(this.ProcessObjectType(typeof(DbType))), p.Type.ToString()));
            body.Add(assignType);
            CodeAssignStatement assignDirection = new CodeAssignStatement(new CodeFieldReferenceExpression(ans, "Direction"), new CodeFieldReferenceExpression(new CodeTypeReferenceExpression(this.ProcessObjectType(typeof(ParameterDirection))), p.Direction.ToString()));
            body.Add(assignDirection);
            CodeAssignStatement assignSize = new CodeAssignStatement(new CodeFieldReferenceExpression(ans, "Size"), new CodeFieldReferenceExpression(new CodeTypeReferenceExpression(this.ProcessObjectType(typeof(Int32))), "MaxValue"));
            body.Add(assignSize);
            if (p.Direction == ParameterDirection.InputOutput)
            {
                CodeVariableDeclarationStatement parameterValueVariableDeclaration = new CodeVariableDeclarationStatement(this.ProcessObjectType(p.NetType), GetCSharpParameterName(p.Name) + "Value", this.GenerateParameterValue(p.Value));
                body.Add(parameterValueVariableDeclaration);
                outputParameterValueVariableReference = new CodeVariableReferenceExpression(parameterValueVariableDeclaration.Name);
            }

            return ans;
        }

        private CodeExpression GenerateParameterValue(object parameterValue)
        {
            CodeExpression ans;
            if (parameterValue == null)
            {
                ans = new CodePrimitiveExpression(null);
            }
            else if (parameterValue == DBNull.Value)
            {
                ans = new CodeFieldReferenceExpression(new CodeTypeReferenceExpression(this.ProcessObjectType(typeof(DBNull))), "Value");
            }
            else if (typeof(INullable).IsInstanceOfType(parameterValue))
            {
                ans = new CodeFieldReferenceExpression(new CodeTypeReferenceExpression(this.ProcessObjectType(parameterValue.GetType())), "Null");
            }
            else if (parameterValue.GetType() == typeof(byte[]))
            {
                CodeArrayCreateExpression newByteArray = new CodeArrayCreateExpression();
                newByteArray.CreateType = this.ProcessObjectType(typeof(byte[]));
                foreach (byte b in (byte[])parameterValue)
                {
                    newByteArray.Initializers.Add(new CodePrimitiveExpression(b));
                }

                ans = newByteArray;
            }
            else if (parameterValue.GetType() == typeof(Guid))
            {
                CodeObjectCreateExpression newGuid = new CodeObjectCreateExpression();
                newGuid.CreateType = this.ProcessObjectType(typeof(Guid));
                newGuid.Parameters.Add(new CodePrimitiveExpression(parameterValue.ToString()));
                ans = newGuid;
            }
            else if (parameterValue.GetType() == typeof(DateTime))
            {
                CodeObjectCreateExpression newDateTime = new CodeObjectCreateExpression();
                newDateTime.CreateType = this.ProcessObjectType(typeof(DateTime));
                DateTime dt = (DateTime)parameterValue;
                newDateTime.Parameters.Add(new CodePrimitiveExpression(dt.Year));
                newDateTime.Parameters.Add(new CodePrimitiveExpression(dt.Month));
                newDateTime.Parameters.Add(new CodePrimitiveExpression(dt.Day));
                newDateTime.Parameters.Add(new CodePrimitiveExpression(dt.Hour));
                newDateTime.Parameters.Add(new CodePrimitiveExpression(dt.Minute));
                newDateTime.Parameters.Add(new CodePrimitiveExpression(dt.Second));
                ans = newDateTime;
            }
            else
            {
                ans = new CodePrimitiveExpression(parameterValue);
            }

            return ans;
        }

        /// <summary>
        /// Gets the type reference and adds the namespace to the import collection if it
        /// is not already there.
        /// </summary>
        /// <param name="objectType">Type of the object.</param>
        /// <returns>Reference to the object's type.</returns>
        private CodeTypeReference ProcessObjectType(Type objectType)
        {
            List<CodeTypeReference> genericParameters = new List<CodeTypeReference>();

            foreach (Type t in objectType.GetGenericArguments())
            {
                genericParameters.Add(this.ProcessObjectType(t));
            }

            CodeTypeReference ans = null;
            CodeTypeReferenceRequestEventArgs request = new CodeTypeReferenceRequestEventArgs(objectType, genericParameters.ToArray());
            if (this.CodeTypeRequestEvent != null)
            {
                this.CodeTypeRequestEvent(this, request);
                ans = request.CodeTypeReference;
            }
            else
            {
                ans = new CodeTypeReference(objectType.Name, genericParameters.ToArray());
            }

            return ans;
        }
    }
}
