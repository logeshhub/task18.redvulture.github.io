//---------------------------------------------------------------------
// <copyright file="TraceFileProcessor.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
//     THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
//     OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
//     LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//     FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>The TraceFileProcessor type.</summary>
//---------------------------------------------------------------------


// TODO: Multiple connections. Option to store connections in a static table to model connection leakage.
// TODO: Process multiple traces together to re-use connections across tests?

namespace Microsoft.DatabaseLoadTest.Library
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.IO;
    using System.Text;

    using Microsoft.SqlServer.Management.Trace;
    using System.Globalization;

    /// <summary>
    /// Processes a trace file and creates the files.
    /// </summary>
    public static class TraceFileProcessor
    {
        /// <summary>
        /// Event raised when the processor is about to parse some SQL that the parser has recognised as the next command.
        /// </summary>
        public static event EventHandler<SqlEventArgs> ParsingSql;

        /// <summary>
        /// Event raised prior to processing a trace record, used to determine if the record should be processed.
        /// </summary>
        /// <remarks>
        /// The parser assumes that all relevant records should be processed. It is up to
        /// the event handler to set the <see cref="TraceRecordFilterEventArgs.Process"/> property
        /// to false if the record should not be processed.
        /// </remarks>
        public static event EventHandler<TraceRecordFilterEventArgs> ProcessingTraceRecord;

        /// <summary>
        /// Processes a SQL Profiler trace and produces a pair of files containing the corresponding unit test code.
        /// </summary>
        /// <remarks>
        /// <para>
        /// The unit test file names are based on the scenario name.
        /// </para>
        /// </remarks>
        /// <param name="scenarioName">The name to be given to the scenario being tested.</param>
        /// <param name="traceFile">The file containing the trace.</param>
        /// <param name="config">The configuration to be used.</param>
        public static void ProcessTraceFile(string scenarioName, string traceFile, DbLoadTestConfiguration config)
        {
            if (!File.Exists(traceFile))
            {
                throw new InvalidOperationException(string.Format(CultureInfo.CurrentCulture, Messages.TraceFileNotFound, traceFile));
            }

            // Can't use using because Dispose will throw a NullReferenceException if there is an error.
            TraceFile reader = new TraceFile();
            try
            {
                try
                {
                    reader.InitializeAsReader(traceFile);
                }
                catch (SqlTraceException ste)
                {
                    throw new InvalidOperationException(string.Format(CultureInfo.CurrentCulture, Messages.TraceFileCannotBeInitialisedForReading, traceFile), ste);
                }

                ProcessTraceFile(scenarioName, reader, scenarioName + ".cs", scenarioName + ".stubs", config);
            }
            finally
            {
                try
                {
                    reader.Dispose();
                }
                catch (NullReferenceException)
                {
                    // Discard this exception as it is thrown if there is an error opening the trace
                }
            }
        }

        /// <summary>
        /// Processes a SQL Profiler trace and produces a pair of files containing the corresponding unit test code.
        /// </summary>
        /// <remarks>
        /// <para>
        /// This overload is intended for test purposes only.
        /// </para>
        /// <para>
        /// The unit test file names are based on the scenario name.
        /// </para>
        /// </remarks>
        /// <param name="scenarioName">The name to be given to the scenario being tested.</param>
        /// <param name="reader">The reader for the trace.</param>
        /// <param name="config">The configuration to be used.</param>
        public static void ProcessTraceFile(string scenarioName, IDataReader reader, DbLoadTestConfiguration config)
        {
                ProcessTraceFile(scenarioName, reader, scenarioName + ".cs", scenarioName + ".stubs", config);
        }

        /// <summary>
        /// Processes a SQL Profiler trace and produces a pair of files containing the corresponding unit test code.
        /// </summary>
        /// <param name="scenarioName">The name to be given to the scenario being tested.</param>
        /// <param name="reader">The reader for the trace.</param>
        /// <param name="mainFileName">The file to contain the main unit tests.</param>
        /// <param name="stubFileName">The file to contain the customisation stubs for the unit tests.</param>
        /// <param name="config">The configuration to be used.</param>
        private static void ProcessTraceFile(string scenarioName, IDataReader reader, string mainFileName, string stubFileName, DbLoadTestConfiguration config)
        {
            if (!Utility.IsValidIdentifier(scenarioName))
            {
                throw new InvalidOperationException(string.Format(CultureInfo.CurrentCulture, Messages.InvalidScenarioIdentifier, scenarioName));
            }
            else
            {
                ICustomCodeGeneration codeGen = null;

                if (config.customCodeGenerator != null)
                {
                    string assemblyQualifiedName = config.customCodeGenerator.type + "," + config.customCodeGenerator.assembly;
                    try
                    {
                        Type customGeneratorType = Type.GetType(assemblyQualifiedName, true, false);
                        codeGen = Activator.CreateInstance(customGeneratorType) as ICustomCodeGeneration;
                        if (codeGen == null)
                        {
                            throw new InvalidOperationException(string.Format(CultureInfo.CurrentCulture, Messages.CustomCodeGenNoInterface, assemblyQualifiedName));
                        }
                    }
                    catch (IOException fle)
                    {
                        throw new InvalidOperationException(string.Format(CultureInfo.CurrentCulture, Messages.CustomCodeGenLoadError, assemblyQualifiedName, fle.Message));
                    }
                    catch (TypeLoadException tle)
                    {
                        throw new InvalidOperationException(string.Format(CultureInfo.CurrentCulture, Messages.CustomCodeGenLoadError, assemblyQualifiedName, tle.Message));
                    }
                }

                UnitTestGenerator utg = new UnitTestGenerator(scenarioName, scenarioName, scenarioName + "Tests", TestMethodMode.ScenarioMethodOnly, OperationTimerMode.IncludeOperationTimers);

                TraceParser parser = new TraceParser(reader);
                parser.ProcessingTraceRecord += delegate(object sender, TraceRecordFilterEventArgs trfea)
                {
                    if (ProcessingTraceRecord != null)
                    {
                        ProcessingTraceRecord(null, trfea);
                    }
                };

                utg.GeneratingCall += delegate(object sender, GenerateCallEventArgs gcea)
                {
                    if (codeGen != null)
                    {
                        gcea.Handled = codeGen.GenerateCall(gcea.Command, gcea.ScenarioMethod, gcea.StubType);
                    }
                };

                SqlParser sqlParser = new SqlParser();
                while (true)
                {
                    TraceRecord traceRecord = parser.Parse();
                    if (traceRecord == null)
                    {
                        break;
                    }

                    string lastSqlParsed = traceRecord.TextData;
                    if (ParsingSql != null)
                    {
                        ParsingSql(null, new SqlEventArgs(lastSqlParsed));
                    }

                    ParsedSqlCommand cmd = sqlParser.ParseTraceRecord(traceRecord);
                    try
                    {
                        utg.GenerateCall(cmd);
                    }
                    catch (Exception ex)
                    {
                        throw new InvalidOperationException(string.Format(CultureInfo.CurrentCulture, Messages.Processor_ErrorProcessingParsedCommand, lastSqlParsed, ex.Message), ex);
                    }
                }

                string mainTempFile = Path.GetTempFileName();
                string stubTempFile = Path.GetTempFileName();
                try
                {
                    using (StreamWriter mainStream = new StreamWriter(mainTempFile))
                    {
                        using (StreamWriter stubStream = new StreamWriter(stubTempFile))
                        {
                            utg.WriteCode(mainStream, stubStream);
                        }
                    }

                    File.Copy(mainTempFile, mainFileName, true);
                    File.Copy(stubTempFile, stubFileName, true);
                }
                finally
                {
                    File.Delete(mainTempFile);
                    File.Delete(stubTempFile);
                }
            }
        }
    }
}
