//---------------------------------------------------------------------
// <copyright file="TraceParser.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
//     THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
//     OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
//     LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//     FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>The TraceParser type.</summary>
//---------------------------------------------------------------------

namespace Microsoft.DatabaseLoadTest.Library
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Diagnostics;
    using System.Globalization;
    using System.Text;

    using Microsoft.SqlServer.Management.Trace;

    /// <summary>
    /// Parses SQL trace data.
    /// </summary>
    /// <remarks>
    /// <para>
    /// It is the responsibility of the parser to extract only the trace records that require code to be generated
    /// from them.
    /// </para>
    /// <para>
    /// The trace passed to the parser must contain the following columns, each required event class must include these
    /// columns:
    /// </para>
    /// <list type="bullet">
    /// <item>EventClass</item>
    /// <item>TextData</item>
    /// <item>SPID</item>
    /// <item>DatabaseName - if this is omitted then the trace is assumed to be all for the same database</item>
    /// </list>
    /// <para>
    /// The trace must contain the following event classes, each class must enable the columns listed above:
    /// </para>
    /// <list type="bullet">
    /// <item>SQL:BatchStarting</item>
    /// <item>RPC:Starting</item>
    /// </list>
    /// <para>
    /// Accordingly it implements the following rules:
    /// </para>
    /// <list type="number">
    /// <item>
    /// All entries relating to the master, model and msdb databases are ignored.
    /// </item>
    /// <item>
    /// All entries with no database name at all are ignored.
    /// </item>
    /// <item>
    /// All calls to sp_reset_connection are ignored.
    /// </item>
    /// </list>
    /// </remarks>
    public class TraceParser
    {
        private const int ColumnNotPresent = -1;

        private const string EventClassColumnName = "EventClass";
        private const string TextDataColumnName = "TextData";
        private const string DatabaseNameColumnName = "DatabaseName";
        private const string SpidColumnName = "SPID";

        private readonly IDataReader reader;

        private readonly int eventClassOffset;
        private readonly int textDataOffset;
        private readonly int databaseNameOffset;
        private readonly int spidOffset;

        /// <summary>
        /// Initializes a new <see cref="TraceParser"/>instance with a reader for a trace file.
        /// </summary>
        /// <param name="reader">The reader to be used to read the trace records.</param>
        /// <exception cref="ArgumentNullException">Thrown if <paramref name="reader"/> is null.</exception>
        /// <exception cref="InvalidOperationException">Thrown if <paramref name="reader"/> does not contain the required columns.</exception>
        public TraceParser(IDataReader reader)
        {
            if (reader == null)
            {
                throw new ArgumentNullException("reader");
            }

            this.reader = reader;

            this.eventClassOffset = GetColumnOffset(this.reader, EventClassColumnName, false);
            this.textDataOffset = GetColumnOffset(this.reader, TextDataColumnName, false);
            this.databaseNameOffset = GetColumnOffset(this.reader, DatabaseNameColumnName, true);
            this.spidOffset = GetColumnOffset(this.reader, SpidColumnName, false);
        }

        /// <summary>
        /// Event raised prior to processing a trace record, used to determine if the record should be processed.
        /// </summary>
        /// <remarks>
        /// The parser assumes that all relevant records should be processed. It is up to
        /// the event handler to set the <see cref="TraceRecordFilterEventArgs.Process"/> property
        /// to false if the record should not be processed.
        /// </remarks>
        public event EventHandler<TraceRecordFilterEventArgs> ProcessingTraceRecord;

        /// <summary>
        /// Parses the trace file until it gets the next record which should be processed.
        /// </summary>
        /// <returns>A <see cref="TraceRecord"/> representing the record to be processed.</returns>
        public TraceRecord Parse()
        {
            TraceRecord ans = null;
            while (ans == null && this.reader.Read())
            {
                TraceRecord traceRecord = this.ReadTraceRecord();
                Trace.WriteLine(string.Format(CultureInfo.CurrentCulture, "Trace record read. Event Class: {0}", traceRecord.EventClass));
                if (traceRecord.EventClass == TraceRecord.SqlBatchStartingEventClass || traceRecord.EventClass == TraceRecord.RpcStartingEventClass)
                {
                    TraceRecordFilterEventArgs filter = new TraceRecordFilterEventArgs();
                    filter.TraceRecord = traceRecord;
                    filter.Process = true;
                    if (this.ProcessingTraceRecord != null)
                    {
                        this.ProcessingTraceRecord(this, filter);
                    }

                    if (filter.Process)
                    {
                        ans = traceRecord;
                        break;
                    }
                }
                else
                {
                    Debug.WriteLine(string.Format(CultureInfo.CurrentCulture, "Ignoring because event class is {0}", traceRecord.EventClass));
                }
            }

            return ans;
        }

        private static int GetColumnOffset(IDataReader reader, string columnName, bool optionalColumn)
        {
            int ans = ColumnNotPresent;
            try
            {
                ans = reader.GetOrdinal(columnName);
            }
            catch (SqlTraceException e)
            {
                if (!optionalColumn)
                {
                    throw new InvalidOperationException(string.Format(CultureInfo.CurrentCulture, Messages.ParserMissingColumn, columnName), e);
                }
            }

            return ans;
        }

        private TraceRecord ReadTraceRecord()
        {
            string eventClass = this.reader.GetString(this.eventClassOffset);
            string databaseName = null;
            string textData = null;
            int spid = -1;

            if (eventClass == TraceRecord.SqlBatchStartingEventClass || eventClass == TraceRecord.RpcStartingEventClass)
            {
                databaseName = this.ReadColumn(this.databaseNameOffset, Messages.DatabaseNameMustBePopulated);
                textData = this.reader.GetString(this.textDataOffset);
                spid = this.reader.GetInt32(this.spidOffset);
            }

            TraceRecord traceRecord = new TraceRecord(eventClass, databaseName, textData, spid);

            return traceRecord;
        }

        private string ReadColumn(int offset, string errorMessageIfNotPresent)
        {
            string ans = null;
            if (offset != ColumnNotPresent)
            {
                if (this.reader[offset] == null || this.reader.IsDBNull(offset) || string.IsNullOrEmpty(this.reader.GetString(offset)))
                {
                    throw new InvalidOperationException(errorMessageIfNotPresent);
                }
                else
                {
                    ans = this.reader.GetString(this.databaseNameOffset);
                }
            }

            return ans;
        }
    }
}
