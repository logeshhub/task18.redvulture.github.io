//---------------------------------------------------------------------
// <copyright file="TraceRecord.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
//     THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
//     OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
//     LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//     FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>The TraceRecord type.</summary>
//---------------------------------------------------------------------

namespace Microsoft.DatabaseLoadTest.Library
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    /// <summary>
    /// Contains the essential fields from a trace record.
    /// </summary>
    public sealed class TraceRecord
    {
        /// <summary>
        /// The event class for SQL:BatchStarting.
        /// </summary>
        public const string SqlBatchStartingEventClass = "SQL:BatchStarting";

        /// <summary>
        /// The event class for RPC:Starting.
        /// </summary>
        public const string RpcStartingEventClass = "RPC:Starting";

        /// <summary>
        /// The event class for Audit Login.
        /// </summary>
        public const string AuditLoginEventClass = "Audit Login";

        /// <summary>
        /// The event class for Audit Logout.
        /// </summary>
        public const string AuditLogoutEventClass = "Audit Logout";

        private readonly string textData;
        private readonly string eventClass;
        private readonly string databaseName;
        private readonly int spid;

        /// <summary>
        /// Initializes an instance of a <see cref="TraceRecord"/>.
        /// </summary>
        /// <param name="eventClass">The event class of the record.</param>
        /// <param name="databaseName">The name of the database the record pertains to.</param>
        /// <param name="textData">The text of the record, usually the query.</param>
        /// <param name="spid">The spid that identifies the connection.</param>
        public TraceRecord(string eventClass, string databaseName, string textData, int spid)
        {
            this.eventClass = eventClass;
            this.databaseName = databaseName;
            this.textData = textData;
            this.spid = spid;
        }

        /// <summary>
        /// Gets the event class of the record.
        /// </summary>
        /// <value>The event class of the record.</value>
        public string EventClass
        {
            get { return this.eventClass; }
        }

        /// <summary>
        /// Gets the name of the database the record pertains to.
        /// </summary>
        /// <value>The name of the database the record pertains to.</value>
        public string DatabaseName
        {
            get { return this.databaseName; }
        }

        /// <summary>
        /// Gets the text of the record, usually the query.
        /// </summary>
        /// <value>The text of the record, usually the query.</value>
        public string TextData
        {
            get { return this.textData; }
        }

        /// <summary>
        /// Gets the SPID of the connection the record pertains to.
        /// </summary>
        /// <value>The SPID of the connection the record pertains to.</value>
        public int Spid
        {
            get { return this.spid; }
        }
    }
}
