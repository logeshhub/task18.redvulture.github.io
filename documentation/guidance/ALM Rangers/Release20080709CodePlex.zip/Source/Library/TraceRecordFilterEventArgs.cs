//---------------------------------------------------------------------
// <copyright file="TraceRecordFilterEventArgs.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
//     THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
//     OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
//     LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//     FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>The TraceRecordFilterEventArgs type.</summary>
//---------------------------------------------------------------------

namespace Microsoft.DatabaseLoadTest.Library
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    /// <summary>
    /// Event arguments used to decide if a particular trace record should be processed or filtered out.
    /// </summary>
    public class TraceRecordFilterEventArgs : EventArgs
    {
        private TraceRecord traceRecord;
        private bool process;

        /// <summary>
        /// Gets or sets the trace record.
        /// </summary>
        /// <value>The trace record.</value>
        public TraceRecord TraceRecord
        {
            get { return this.traceRecord; }
            set { this.traceRecord = value; }
        }

        /// <summary>
        /// Gets or sets a value indicating whether the record should be processed or not.
        /// </summary>
        /// <value>True if the record should be processed, false if it should be filtered out.</value>
        public bool Process
        {
            get { return this.process; }
            set { this.process = value; }
        }
    }
}
