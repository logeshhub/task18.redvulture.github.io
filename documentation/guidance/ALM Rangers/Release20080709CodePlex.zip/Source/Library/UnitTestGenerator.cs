//---------------------------------------------------------------------
// <copyright file="UnitTestGenerator.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
//     THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
//     OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
//     LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//     FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>The UnitTestGenerator type.</summary>
//---------------------------------------------------------------------

namespace Microsoft.DatabaseLoadTest.Library
{
    using System;
    using System.CodeDom;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Diagnostics;
    using System.Text;
    using System.Globalization;

    /// <summary>
    /// Generates unit tests for database load testing.
    /// </summary>
    public class UnitTestGenerator : UnitTestGeneratorBase
    {
        private readonly TestMethodMode testMethodMode;
        private readonly OperationTimerMode operationTimerMode;

        private CodeExpression connectionReference;

        private StatementGenerator sg;

        /// <summary>
        /// Initializes an instance of <see cref="UnitTestGenerator"/>.
        /// </summary>
        /// <param name="scenarioName">The name of the scenario.</param>
        /// <param name="namespaceName">The name of the namespace in which to place the unit test class.</param>
        /// <param name="unitTestClassName">The name to be given to the unit test class.</param>
        /// <param name="testMethodMode">Whether to include the test methods for the individual operations or not.</param>
        /// <param name="operationTimerMode">Whether to include timers for the individual operations or not.</param>
        public UnitTestGenerator(string scenarioName, string namespaceName, string unitTestClassName, TestMethodMode testMethodMode, OperationTimerMode operationTimerMode)
            : base(scenarioName, namespaceName, unitTestClassName)
        {
            this.testMethodMode = testMethodMode;
            this.operationTimerMode = operationTimerMode;

            // Adding using for SqlClient

            MainTestNamespace.Imports.Add(new CodeNamespaceImport("System"));
            StubTestNamespace.Imports.Add(new CodeNamespaceImport("System"));
            MainTestNamespace.Imports.Add(new CodeNamespaceImport("System.Data"));
            StubTestNamespace.Imports.Add(new CodeNamespaceImport("System.Data"));
            MainTestNamespace.Imports.Add(new CodeNamespaceImport("System.Data.SqlClient"));
            StubTestNamespace.Imports.Add(new CodeNamespaceImport("System.Data.SqlClient"));

            // Declare the connection variable in the main file (and create reference)

            CodeMemberField connectionVariable = new CodeMemberField("SqlConnection", "_connection");
            connectionVariable.Attributes = MemberAttributes.Private;
            MainTestType.Members.Add(connectionVariable);

            this.connectionReference = new CodeFieldReferenceExpression(null, connectionVariable.Name);

            // Create the connection in the stub TestInitialize method

            StubTestInitializer.Statements.Add(new CodeAssignStatement(this.connectionReference, new CodeObjectCreateExpression("SqlConnection")));

            // Open the connection in the stub TestInitialize method

            StubTestInitializer.Statements.Add(new CodeMethodInvokeExpression(new CodeMethodReferenceExpression(this.connectionReference, "Open")));

            // Dispose the connection in the stub TestCleanup method

            StubTestCleanup.Statements.Add(new CodeMethodInvokeExpression(new CodeMethodReferenceExpression(this.connectionReference, "Dispose")));
        }

        /// <summary>
        /// Raised before generating the code for a particular database call.
        /// </summary>
        /// <remarks>
        /// The handler can indicate that it has generated its own code to suppress default generation by setting
        /// <see cref="GenerateCallEventArgs.Handled"/>.
        /// </remarks>
        public event EventHandler<GenerateCallEventArgs> GeneratingCall;

        /// <summary>
        /// Generates the code to add a SQL call to the test.
        /// </summary>
        /// <param name="parsedSqlCommand">The command to generate code for.</param>
        public void GenerateCall(ParsedSqlCommand parsedSqlCommand)
        {
            if (parsedSqlCommand == null)
            {
                throw new ArgumentNullException("parsedSqlCommand");
            }

            bool handled = false;

            if (this.GeneratingCall != null)
            {
                GenerateCallEventArgs args = new GenerateCallEventArgs(parsedSqlCommand, ScenarioMethod, StubTestType);
                this.GeneratingCall(this, args);
                handled = args.Handled;
            }
            
            if (!handled && parsedSqlCommand.CommandText.StartsWith("--"))
            {
                string[] comments = parsedSqlCommand.CommandText.Split('\n');
                foreach (string comment in comments)
                {
                    ScenarioMethod.Statements.Add(new CodeCommentStatement(comment.Substring(2).TrimStart()));
                }

                handled = true;
            }

            if (!handled)
            {
                CodeMemberMethod basicMethod = this.GenerateBasicMethod(parsedSqlCommand, this.GetMethodName(parsedSqlCommand));
                MainTestType.Members.Add(basicMethod);
                if (this.testMethodMode == TestMethodMode.IncludeIndividualOperations)
                {
                    MainTestType.Members.Add(GenerateUnitTestMethod(basicMethod.Name + "Test", basicMethod));
                }

                GenerateScenarioUnitTestMethodCall(ScenarioMethod, basicMethod);
            }
        }

        private static void GenerateCustomisationMethodCall(CodeMethodReferenceExpression customisationMethod, CodeStatementCollection body, IList<CodeVariableReferenceExpression> parameterVariables, IList<ParsedSqlParameter> parsedParameters)
        {
            Debug.Assert(parameterVariables.Count == parsedParameters.Count);
            CodeDirectionExpression[] customisationParameters = new CodeDirectionExpression[parsedParameters.Count];
            for (int i = 0; i < parsedParameters.Count; i++)
            {
                customisationParameters[i] = new CodeDirectionExpression(FieldDirection.Ref, parameterVariables[i]);
            }

            CodeMethodInvokeExpression customisationCall = new CodeMethodInvokeExpression(customisationMethod, customisationParameters);
            body.Add(customisationCall);
        }

        private static void GenerateScenarioUnitTestMethodCall(CodeMemberMethod scenarioMethod, CodeMemberMethod method)
        {
            scenarioMethod.Statements.Add(new CodeMethodInvokeExpression(new CodeMethodReferenceExpression(null, method.Name)));
        }

        private CodeMemberMethod GenerateBasicMethod(ParsedSqlCommand command, string generatedMethodName)
        {
            CodeMemberMethod ans = new CodeMemberMethod();
            ans.Name = generatedMethodName;
            ans.Attributes = MemberAttributes.Private | MemberAttributes.Final;

            this.sg = new StatementGenerator(delegate(CodeStatementCollection body, IList<CodeVariableReferenceExpression> parameterVariables, IList<ParsedSqlParameter> parsedParameters)
            {
                Debug.Assert(parameterVariables.Count == parsedParameters.Count);
                CodeMethodReferenceExpression stubRef = this.GenerateCustomisationStubMethod(generatedMethodName, parameterVariables, parsedParameters);
                GenerateCustomisationMethodCall(stubRef, body, parameterVariables, parsedParameters);
            });
            this.sg.CodeTypeRequestEvent += new EventHandler<CodeTypeReferenceRequestEventArgs>(this.CodeTypeReferenceRequestEventHandler);
            if (this.operationTimerMode == OperationTimerMode.NoOperationTimers)
            {
                this.sg.Initialise(ans.Statements);
            }
            else
            {
                this.sg.Initialise(GenerateOperationTimerCode(ans.Statements, ScenarioName + "_" + generatedMethodName));
            }

            this.sg.GenerateSqlCommand(command, this.connectionReference);

            return ans;
        }

        private CodeMethodReferenceExpression GenerateCustomisationStubMethod(string basicMethodName, IList<CodeVariableReferenceExpression> parameterVariableReferences, IList<ParsedSqlParameter> parameters)
        {
            Debug.Assert(parameterVariableReferences.Count == parameters.Count);
            CodeMemberMethod methodStub = new CodeMemberMethod();
            methodStub.Name = "Customise" + basicMethodName;
            methodStub.Attributes = MemberAttributes.Private | MemberAttributes.Final;
            for (int i = 0; i < parameters.Count; i++)
            {
                ParsedSqlParameter p = parameters[i];
                CodeParameterDeclarationExpression parameterDeclaration = new CodeParameterDeclarationExpression();
                parameterDeclaration.Type = GetReferencedTypeReference(p.NetType);
                parameterDeclaration.Name = parameterVariableReferences[i].VariableName;
                parameterDeclaration.Direction = FieldDirection.Ref;
                methodStub.Parameters.Add(parameterDeclaration);
            }

            StubTestType.Members.Add(methodStub);
            return new CodeMethodReferenceExpression(null, methodStub.Name);
        }

        ////private static CodeMemberMethod GenerateScenarioUnitTestMethod(string scenarioName)
        ////{
        ////    CodeMemberMethod ans = new CodeMemberMethod();
        ////    ans.Name = scenarioName;
        ////    ans.Attributes = MemberAttributes.Public | MemberAttributes.Final;
        ////    ans.CustomAttributes.Add(new CodeAttributeDeclaration("TestMethod"));

        ////    // Body is added for each service call

        ////    return ans;
        ////}

        private void CodeTypeReferenceRequestEventHandler(object sender, CodeTypeReferenceRequestEventArgs o)
        {
            o.CodeTypeReference = GetReferencedTypeReference(o.RequestedType, o.GenericParameters);
            this.AddImport(o.RequestedType);
        }

        private string GetMethodName(ParsedSqlCommand command)
        {
            Debug.Assert(command.CommandType == CommandType.Text || command.CommandType == CommandType.StoredProcedure);
            string ans;

            if (command.CommandType == CommandType.Text)
            {
                ans = Resources.DefaultMethodName;
            }
            else
            {
                ans = Utility.MakeSafeIdentifier(command.CommandText);
                if (!string.IsNullOrEmpty(ans))
                {
                    // capitalise first character
                    ans = char.ToUpperInvariant(ans[0]) + ans.Substring(1);
                }
                else
                {
                    ans = Resources.DefaultMethodName;
                }
            }

            return this.GetMethodName(ans);
        }
    }
}
