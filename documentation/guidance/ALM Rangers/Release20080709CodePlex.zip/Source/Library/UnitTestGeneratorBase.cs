//---------------------------------------------------------------------
// <copyright file="UnitTestGeneratorBase.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
//     THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
//     OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
//     LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//     FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>The UnitTestGeneratorBase type.</summary>
//---------------------------------------------------------------------

namespace Microsoft.DatabaseLoadTest.Library
{
    using System;
    using System.CodeDom;
    using System.CodeDom.Compiler;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Globalization;
    using System.IO;
    using System.Reflection;
    using System.Text;
    using System.Text.RegularExpressions;

    /// <summary>
    /// Base class for any class that generates unit tests.
    /// </summary>
    public abstract class UnitTestGeneratorBase
    {
        private const string IndentString = "    ";

        private readonly string scenarioName;

        private CodeCompileUnit mainCcu;
        private CodeCompileUnit stubCcu;
        private CodeMemberMethod scenarioMethod;
        private CodeMemberMethod stubTestInitializer;
        private CodeMemberMethod stubTestCleanup;
        private CodeNamespace mainTestNamespace;
        private CodeTypeDeclaration mainTestType;
        private CodeTypeDeclaration stubTestType;
        private CodeNamespace stubTestNamespace;
        private Dictionary<string, int> prototypeTable = new Dictionary<string, int>();

        /// <summary>
        /// Initializes an instance of the class.
        /// </summary>
        /// <param name="scenarioName">The name of the scenario.</param>
        /// <param name="namespaceName">The name of the namespace in which to place the unit test class.</param>
        /// <param name="unitTestClassName">The name to be given to the unit test class.</param>
        protected UnitTestGeneratorBase(string scenarioName, string namespaceName, string unitTestClassName)
        {
            this.scenarioName = scenarioName;
            this.mainCcu = new CodeCompileUnit();
            this.mainTestNamespace = new CodeNamespace(namespaceName);
            this.mainCcu.Namespaces.Add(this.mainTestNamespace);

            this.stubCcu = new CodeCompileUnit();
            this.stubTestNamespace = new CodeNamespace(namespaceName);
            this.stubCcu.Namespaces.Add(this.stubTestNamespace);

            this.mainTestType = this.GenerateMainTestClass(this.scenarioName, unitTestClassName);
            this.stubTestType = this.GenerateStubTestClass(unitTestClassName);

            this.mainTestNamespace.Imports.Add(new CodeNamespaceImport("Microsoft.VisualStudio.TestTools.UnitTesting"));
        }

        /// <summary>
        /// Gets the name of the scenario.
        /// </summary>
        /// <value>The name of the scenario.</value>
        protected string ScenarioName
        {
            get { return this.scenarioName; }
        }

        /// <summary>
        /// Gets the method that contains the overall scenario.
        /// </summary>
        /// <value>The method that contains the overall scenario.</value>
        protected CodeMemberMethod ScenarioMethod
        {
            get { return this.scenarioMethod; }
        }

        /// <summary>
        /// Gets the [TestInitialize] method.
        /// </summary>
        /// <value>The [TestInitialize] method.</value>
        protected CodeMemberMethod StubTestInitializer
        {
            get { return this.stubTestInitializer; }
        }

        /// <summary>
        /// Gets the [TestCleanup] method.
        /// </summary>
        /// <value>The [TestCleanup] method.</value>
        protected CodeMemberMethod StubTestCleanup
        {
            get { return this.stubTestCleanup; }
        }

        /// <summary>
        /// Gets the namespace in the main code file.
        /// </summary>
        /// <value>The namespace in the main code file.</value>
        protected CodeNamespace MainTestNamespace
        {
            get { return this.mainTestNamespace; }
        }

        /// <summary>
        /// Gets the namespace in the stub code file.
        /// </summary>
        /// <value>The namespace in the stub code file.</value>
        protected CodeNamespace StubTestNamespace
        {
            get { return this.stubTestNamespace; }
        }

        /// <summary>
        /// Gets the test class in the main code file.
        /// </summary>
        /// <value>The test class in the main code file.</value>
        protected CodeTypeDeclaration MainTestType
        {
            get { return this.mainTestType; }
        }

        /// <summary>
        /// Gets the test class in the stub code file.
        /// </summary>
        /// <value>The test class in the stub code file.</value>
        protected CodeTypeDeclaration StubTestType
        {
            get { return this.stubTestType; }
        }

        /// <summary>
        /// Writes the code that has been generated so far to a main unit test file and a stubs file.
        /// </summary>
        /// <param name="mainFileTextWriter">The main file to be written.</param>
        /// <param name="stubFileTextWriter">The stubs file.</param>
        public void WriteCode(TextWriter mainFileTextWriter, TextWriter stubFileTextWriter)
        {
            IndentedTextWriter tw = null;

            try
            {
                CodeDomProvider provider = new Microsoft.CSharp.CSharpCodeProvider();
                using (tw = new IndentedTextWriter(mainFileTextWriter, "    "))
                {
                    CodeGeneratorOptions cgo = new CodeGeneratorOptions();
                    cgo.BracingStyle = "C";
                    cgo.IndentString = IndentString;
                    try
                    {
                        provider.GenerateCodeFromCompileUnit(this.mainCcu, tw, cgo);
                    }
                    catch (ArgumentException ae)
                    {
                        Regex r = new Regex(@"Invalid Primitive Type: (?<DataType>\S+). Consider using CodeObjectCreateExpression.");
                        Match m = r.Match(ae.Message);
                        if (m.Success)
                        {
                            throw new InvalidOperationException(string.Format(CultureInfo.CurrentCulture, Messages.UTGenerator_TypeNotSupported, m.Result("${DataType}")));
                        }
                        else
                        {
                            throw;
                        }
                    }

                    tw.Close();
                }

                // Any namespaces in the main class to be copied across to the stub as they will be needed there too.
                foreach (CodeNamespaceImport n in this.mainTestNamespace.Imports)
                {
                    this.stubTestNamespace.Imports.Add(n);
                }

                using (tw = new IndentedTextWriter(stubFileTextWriter, "    "))
                {
                    CodeGeneratorOptions cgo = new CodeGeneratorOptions();
                    cgo.BracingStyle = "C";
                    provider.GenerateCodeFromCompileUnit(this.stubCcu, tw, cgo);
                    tw.Close();
                }
            }
            finally
            {
                if (tw != null)
                {
                    tw.Close();
                }
            }
        }

        /// <summary>
        /// Gets the <see cref="CodeTypeReference"/> for a type.
        /// </summary>
        /// <param name="t">The type to get the reference for.</param>
        /// <returns>The <see cref="CodeTypeReference"/> for the type.</returns>
        protected static CodeTypeReference GetReferencedTypeReference(Type t)
        {
            List<CodeTypeReference> genericParameters = new List<CodeTypeReference>();
            foreach (Type gt in t.GetGenericArguments())
            {
                genericParameters.Add(new CodeTypeReference(gt.Name));
            }

            CodeTypeReference ans = new CodeTypeReference(t.Name, genericParameters.ToArray());
            return ans;
        }

        /// <summary>
        /// Gets the <see cref="CodeTypeReference"/> for a type.
        /// </summary>
        /// <param name="t">The type to get the reference for.</param>
        /// <param name="genericParameters">Any generic type parameters for <paramref name="t"/>.</param>
        /// <returns>The <see cref="CodeTypeReference"/> for the type.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1011")]
        protected static CodeTypeReference GetReferencedTypeReference(Type t, params CodeTypeReference[] genericParameters)
        {
            if (t == null)
            {
                throw new ArgumentNullException("t");
            }

            CodeTypeReference ans = new CodeTypeReference(t.Name, genericParameters);
            return ans;
        }

        /// <summary>
        /// Gets the <see cref="CodeTypeReference"/> for a type.
        /// </summary>
        /// <param name="t">The type to get the reference for.</param>
        /// <param name="genericParameters">Any generic type parameters for <paramref name="t"/>.</param>
        /// <returns>The <see cref="CodeTypeReference"/> for the referenced type.</returns>
        protected static CodeTypeReference GetReferencedTypeReference(string t, params Type[] genericParameters)
        {
            CodeTypeReference ans = new CodeTypeReference(t);
            foreach (Type gp in genericParameters)
            {
                ans.TypeArguments.Add(new CodeTypeReference(gp));
            }

            return ans;
        }


        /// <summary>
        /// Generates a test method that encapsulates the basic test method.
        /// </summary>
        /// <param name="methodName">The name to be given to the unit test method.</param>
        /// <param name="basicMethod">The basic method to be called.</param>
        /// <returns>The generated unit test method.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1011")]
        protected static CodeMemberMethod GenerateUnitTestMethod(string methodName, CodeMemberMethod basicMethod)
        {
            if (basicMethod == null)
            {
                throw new ArgumentNullException("basicMethod");
            }

            CodeMemberMethod ans = new CodeMemberMethod();
            ans.Name = methodName;
            ans.Attributes = MemberAttributes.Public | MemberAttributes.Final;
            ans.CustomAttributes.Add(new CodeAttributeDeclaration("TestMethod"));

            CodeMethodReferenceExpression method = new CodeMethodReferenceExpression(null, basicMethod.Name);
            CodeMethodInvokeExpression call = new CodeMethodInvokeExpression(method);
            ans.Statements.Add(call);

            return ans;
        }

        /// <summary>
        /// Creates an operation timer code block.
        /// </summary>
        /// <param name="body">The location where the block has to be placed.</param>
        /// <param name="timerName">The name to be given to the timer.</param>
        /// <returns>The location where the timed code has to be placed.</returns>
        protected static CodeStatementCollection GenerateOperationTimerCode(CodeStatementCollection body, string timerName)
        {
            if (body == null)
            {
                throw new ArgumentNullException("body");
            }

            CodeMethodInvokeExpression startTimer = new CodeMethodInvokeExpression(new CodeMethodReferenceExpression(GetTestContextReference(), "BeginTimer"), new CodePrimitiveExpression(timerName));
            CodeMethodInvokeExpression endTimer = new CodeMethodInvokeExpression(new CodeMethodReferenceExpression(GetTestContextReference(), "EndTimer"), new CodePrimitiveExpression(timerName));

            body.Add(startTimer);
            CodeTryCatchFinallyStatement timerBlock = new CodeTryCatchFinallyStatement();
            body.Add(timerBlock);
            timerBlock.FinallyStatements.Add(endTimer);
            return timerBlock.TryStatements;
        }

        /// <summary>
        /// Adds a namespace import for a type if it is not already imported.
        /// </summary>
        /// <param name="t">The type for which the namespace is to be imported.</param>
        protected void AddImport(Type t)
        {
            AddImport(this.mainTestNamespace, t);
            AddImport(this.stubTestNamespace, t);
        }

        /// <summary>
        /// Computes the name to be used for a method based on the prototype name. If a method already exists with the
        /// prototype name then the existing method is suffixed with a digit and subsequent calls for the same prototype
        /// add further digits.
        /// </summary>
        /// <param name="baseName">The base name of the method.</param>
        /// <returns>The name to be used for a method based on the prototype name.</returns>
        protected string GetMethodName(string baseName)
        {
            string ans = baseName;

            if (this.prototypeTable.ContainsKey(baseName))
            {
                int currentCount = this.prototypeTable[baseName];
                currentCount++;
                this.prototypeTable[baseName] = currentCount;
                ans = ans + currentCount.ToString(CultureInfo.InvariantCulture);
            }
            else
            {
                this.prototypeTable.Add(baseName, 1);
            }

            return ans;
        }

        private static void GenerateTestContextProperty(CodeTypeDeclaration testType)
        {
            CodeMemberField backingVariable = new CodeMemberField("TestContext", "_testContext");
            backingVariable.Attributes = MemberAttributes.Private;
            testType.Members.Add(backingVariable);

            CodeMemberProperty testContextProp = new CodeMemberProperty();
            testContextProp.Type = new CodeTypeReference("TestContext");
            testContextProp.Name = "TestContext";
            testContextProp.Attributes = MemberAttributes.Public | MemberAttributes.Final;
            testContextProp.GetStatements.Add(new CodeMethodReturnStatement(new CodeFieldReferenceExpression(new CodeThisReferenceExpression(), backingVariable.Name)));
            testContextProp.SetStatements.Add(new CodeAssignStatement(new CodeFieldReferenceExpression(new CodeThisReferenceExpression(), backingVariable.Name), new CodeVariableReferenceExpression("value")));

            testType.Members.Add(testContextProp);
        }

        private static CodeMemberMethod GenerateScenarioUnitTestMethod(string scenarioName)
        {
            CodeMemberMethod ans = new CodeMemberMethod();
            ans.Name = scenarioName;
            ans.Attributes = MemberAttributes.Public | MemberAttributes.Final;
            ans.CustomAttributes.Add(new CodeAttributeDeclaration("TestMethod"));

            // Body is added for each service call

            return ans;
        }

        private static CodeFieldReferenceExpression GetTestContextReference()
        {
            return new CodeFieldReferenceExpression(null, "_testContext");
        }

        private static void AddImport(CodeNamespace ns, Type t)
        {
            bool alreadyImported = false;
            foreach (CodeNamespaceImport import in ns.Imports)
            {
                if (import.Namespace == t.Namespace)
                {
                    alreadyImported = true;
                }
            }

            if (!alreadyImported)
            {
                ns.Imports.Add(new CodeNamespaceImport(t.Namespace));
            }
        }

        private CodeTypeDeclaration GenerateMainTestClass(string nameOfScenario, string unitTestClassName)
        {
            CodeTypeDeclaration testType = new CodeTypeDeclaration(unitTestClassName);
            this.mainTestNamespace.Types.Add(testType);
            testType.IsClass = true;
            testType.IsPartial = true;
            testType.TypeAttributes = TypeAttributes.Public;
            testType.CustomAttributes.Add(new CodeAttributeDeclaration("TestClass"));

            GenerateTestContextProperty(testType);

            this.scenarioMethod = GenerateScenarioUnitTestMethod(nameOfScenario);
            testType.Members.Add(this.scenarioMethod);

            return testType;
        }

        private CodeTypeDeclaration GenerateStubTestClass(string unitTestClassName)
        {
            CodeTypeDeclaration testType = new CodeTypeDeclaration(unitTestClassName);
            this.stubTestNamespace.Types.Add(testType);
            testType.IsClass = true;
            testType.IsPartial = true;
            testType.TypeAttributes = TypeAttributes.Public;

            this.stubTestInitializer = new CodeMemberMethod();
            this.stubTestInitializer.Attributes = MemberAttributes.Public | MemberAttributes.Final;
            this.stubTestInitializer.Name = "InitializeTest";
            this.stubTestInitializer.CustomAttributes.Add(new CodeAttributeDeclaration("TestInitialize"));
            testType.Members.Add(this.stubTestInitializer);

            this.stubTestCleanup = new CodeMemberMethod();
            this.stubTestCleanup.Attributes = MemberAttributes.Public | MemberAttributes.Final;
            this.stubTestCleanup.Name = "CleanupTest";
            this.stubTestCleanup.CustomAttributes.Add(new CodeAttributeDeclaration("TestCleanup"));
            testType.Members.Add(this.stubTestCleanup);

            return testType;
        }

        ////private static string ToCamelCase(string p)
        ////{
        ////    string ans = p;
        ////    if (!string.IsNullOrEmpty(p) && char.IsUpper(p[0]))
        ////    {
        ////        ans = (char.ToLower(p[0], CultureInfo.InvariantCulture)).ToString();
        ////        if (p.Length > 1) ans += p.Substring(1);
        ////    }
        ////    return ans;
        ////}
    }
}
