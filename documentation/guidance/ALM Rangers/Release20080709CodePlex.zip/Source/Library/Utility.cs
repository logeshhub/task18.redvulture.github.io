//---------------------------------------------------------------------
// <copyright file="Utility.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
//     THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
//     OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
//     LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//     FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>The Utility type.</summary>
//---------------------------------------------------------------------

namespace Microsoft.DatabaseLoadTest.Library
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using System.Text.RegularExpressions;

    /// <summary>
    /// Miscellaneous utility methods.
    /// </summary>
    public static class Utility
    {
        /// <summary>
        /// Regular expression that matches a C# identifier.
        /// </summary>
        public const string IdentifierPatternString = LeadingCharacterPatternString + SubsequentCharacterPatternString + @"*";

        private const string LeadingCharacterPatternString = @"(\p{Lu}|\p{Ll}|\p{Lt}|\p{Lm}|\p{Lo}|\p{Nl}|_)";
        private const string SubsequentCharacterPatternString = @"(\p{Lu}|\p{Ll}|\p{Lt}|\p{Lm}|\p{Lo}|\p{Nl}|\p{Mn}|\p{Mc}|\p{Nd}|\p{Pc})";

        private static Regex cSharpIdentifierPattern = new Regex(@"^" + IdentifierPatternString + @"$");
        private static Regex leadingCharacterPattern = new Regex(LeadingCharacterPatternString);
        private static Regex subsequentCharacterPattern = new Regex(SubsequentCharacterPatternString);

        /// <summary>
        /// Checks that a string represents a valid C# identifier.
        /// </summary>
        /// <param name="identifier">The string to check.</param>
        /// <returns>True if the string is a valid C# identifier, false otherwise.</returns>
        public static bool IsValidIdentifier(string identifier)
        {
            bool ans = cSharpIdentifierPattern.IsMatch(identifier);
            return ans;
        }

        /// <summary>
        /// Turns a string into a valid C# identifier, filtering out any invalid characters.
        /// </summary>
        /// <param name="identifier">The string to convert.</param>
        /// <returns>A valid C# identifier.</returns>
        public static string MakeSafeIdentifier(string identifier)
        {
            if (identifier == null)
            {
                throw new ArgumentNullException("identifier");
            }

            StringBuilder ans = new StringBuilder(identifier.Length);

            bool foundValidLeadingCharacter = false;
            for (int i = 0; i < identifier.Length; i++)
            {
                Match m;
                if (!foundValidLeadingCharacter)
                {
                    m = leadingCharacterPattern.Match(identifier, i, 1);
                    if (m.Success)
                    {
                        foundValidLeadingCharacter = true;
                    }
                }
                else
                {
                    m = subsequentCharacterPattern.Match(identifier, i, 1);
                }

                if (m.Success)
                {
                    ans.Append(m.Value);
                }
            }

            return ans.ToString();
        }
    }
}
