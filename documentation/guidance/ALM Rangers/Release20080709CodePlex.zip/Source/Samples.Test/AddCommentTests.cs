//---------------------------------------------------------------------
// <copyright file="AddCommentTests.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
//     THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
//     OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
//     LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//     FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>The GenerateCallEventArgs type.</summary>
//---------------------------------------------------------------------

namespace Microsoft.DatabaseLoadTest.Samples.Test
{
    using System;
    using System.CodeDom;
    using System.Data;
    using System.Text;
    using System.Collections.Generic;

    using Microsoft.VisualStudio.TestTools.UnitTesting;

    using Microsoft.DatabaseLoadTest.Library;

    [TestClass]
    public class AddCommentTests
    {
        [TestMethod]
        public void SampleAddComment_AddsCommentWhenRightStoredProcedureCallIsPassed()
        {
            ParsedSqlCommand command = new ParsedSqlCommand("[dbo].[AddAComment]", CommandType.StoredProcedure, new List<ParsedSqlParameter>(new ParsedSqlParameter[] { new ParsedSqlParameter("p", DbType.String, "Test Comment", ParameterDirection.Input) }));
            CodeMemberMethod scenarioMethod = new CodeMemberMethod();
            CodeTypeDeclaration stubType = new CodeTypeDeclaration();

            ICustomCodeGeneration ac = new AddComment();
            bool handled = ac.GenerateCall(command, scenarioMethod, stubType);

            Assert.IsTrue(handled);
            Assert.AreEqual<int>(1, scenarioMethod.Statements.Count);
            Assert.IsInstanceOfType(scenarioMethod.Statements[0], typeof(CodeCommentStatement));
            CodeCommentStatement stmt = (CodeCommentStatement)scenarioMethod.Statements[0];
            Assert.AreEqual<string>("Test Comment", stmt.Comment.Text);

            Assert.AreEqual<int>(0, stubType.Members.Count);
        }

        [TestMethod]
        public void SampleAddComment_AddsNothingWhenRightStoredProcedureCallIsNotPassed()
        {
            ParsedSqlCommand command = new ParsedSqlCommand("[dbo].[AddSomethingElse]", CommandType.StoredProcedure, new List<ParsedSqlParameter>(new ParsedSqlParameter[] { new ParsedSqlParameter("p", DbType.String, "Test Comment", ParameterDirection.Input) }));
            CodeMemberMethod scenarioMethod = new CodeMemberMethod();
            CodeTypeDeclaration stubType = new CodeTypeDeclaration();

            ICustomCodeGeneration ac = new AddComment();
            bool handled = ac.GenerateCall(command, scenarioMethod, stubType);

            Assert.IsFalse(handled);
            Assert.AreEqual<int>(0, scenarioMethod.Statements.Count);

            Assert.AreEqual<int>(0, stubType.Members.Count);
        }
    }
}
