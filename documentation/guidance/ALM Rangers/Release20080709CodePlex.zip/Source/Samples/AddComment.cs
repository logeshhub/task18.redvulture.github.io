﻿//---------------------------------------------------------------------
// <copyright file="AddComment.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
//     THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
//     OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
//     LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//     FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>The AddComment type.</summary>
//---------------------------------------------------------------------

namespace Microsoft.DatabaseLoadTest.Samples
{
    using System;
    using System.CodeDom;
    using System.Collections.Generic;
    using System.Data;
    using System.Text;

    using Microsoft.DatabaseLoadTest.Library;

    /// <summary>
    /// Sample that turns calls to [dbo].[AddAComment] into comments in the scenario method. Useful for marking out
    /// sections of a large trace.
    /// </summary>
    public class AddComment : ICustomCodeGeneration
    {
        /// <summary>
        /// Generates a comment if the stored procedure is [dbo].[AddAComment]. The comment is the first parameter to the
        /// stored procedure.
        /// </summary>
        /// <param name="command">The command for which code is to be generated.</param>
        /// <param name="scenarioMethod">The method that contains the scenario calls.</param>
        /// <param name="stubType">The type that represent the separate customisation code partial type.</param>
        /// <returns>True if code was generated, false of default code generation must be done.</returns>
        public bool GenerateCall(ParsedSqlCommand command, System.CodeDom.CodeMemberMethod scenarioMethod, System.CodeDom.CodeTypeDeclaration stubType)
        {
            bool ans = false;

            if (command.CommandType == CommandType.StoredProcedure && command.CommandText == "[dbo].[AddAComment]")
            {
                scenarioMethod.Statements.Add(new CodeCommentStatement(command.Parameters[0].Value.ToString()));
                ans = true;
            }

            return ans;
        }
    }
}
