//---------------------------------------------------------------------
// <copyright file="Program.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
//     THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
//     OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
//     LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//     FITNESS FOR A PARTICULAR PURPOSE.
// </copyright>
// <summary>Simple test harness.</summary>
//---------------------------------------------------------------------

namespace SpikeConsoleApp
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Data.SqlTypes;
    using System.IO;
    using System.Text;
    using System.Xml;

    using Microsoft.SqlServer.Management.Trace;
    using Microsoft.DatabaseLoadTest.Library;

    public class Program
    {
        private static string connectionString = "Database=Scratch;Server=(local);Integrated Security=SSPI;pooling=true";

        public static void Main(string[] args)
        {
            ////TestAddAComment();
            ////ParseSample();
            ////ReadTrace();
            ////TestNonParameterisedQueries();
            ////TestParameterisedQueries();
            ////TestParameterisedQueriesWithPrepare();
            ////TestParameterisedQueriesWithDataTypes();
            ////TestParameterisedStoredProceduresWithDataTypes();
            ////TestParameterisedStoredProceduresWithDataTypesOutput();
            ////TestParameterisedSqlWithDataTypesOutput();
            ////TestParameterisedSqlWithDataTypesInputOutput();
            ////TestParameterisedStoredProceduresWithDataTypesAndPositionalCall();
            TestParameterisedSqlWithPositionalParameter();
            ////TestParameterisedSqlInputOutputParameter();
            ////TestParameterisedStoredProcedureInputOutputParameter();
            ////TestParameterisedStoredProcedureInputOutputParameterInitialisedToDBNull();
            ////TestParameterisedStoredProcedureInputOutputParameterInitialisedToNull();
            ////TestParameterisedSqlWithNullableNullAndDBNull();
            ////TestParameterisedSqlTypesOptions();
        }

        private static void TestParameterisedSqlWithNullableNullAndDBNull()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;

                cmd.CommandText = @"SELECT @DBNullAssignedToObject, NullableAssignedNull, @SqlIntAssignedNull, @StraightNull, @StraightDBNull";
                cmd.CommandType = CommandType.Text;
                object a1 = DBNull.Value;
                Nullable<Int32> a2 = null;
                SqlInt32 a3 = SqlInt32.Null;
                Nullable<SqlInt32> a4 = null;
                cmd.Parameters.AddWithValue("@DBNullAssignedToObject", a1);
                cmd.Parameters.AddWithValue("@NullableAssignedNull", a2);
                cmd.Parameters.AddWithValue("@SqlIntAssignedNull", a3);
                cmd.Parameters.AddWithValue("@NullableSqlIntAssignedNull", a4);
                cmd.Parameters.AddWithValue("@StraightNull", null);
                cmd.Parameters.AddWithValue("@StraightDBNull", DBNull.Value);
                cmd.ExecuteNonQuery();

                conn.Close();
            }
        }

        private static void TestParameterisedSqlTypesOptions()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;

                cmd.CommandText = @"SELECT 1";
                cmd.CommandType = CommandType.Text;
                Nullable<SqlInt32> defaultValue = null;
                Nullable<SqlInt32> nullValue = SqlInt32.Null;
                Nullable<SqlInt32> actualValue = 9;
                Nullable<SqlString> defaultValueStr = null;
                Nullable<SqlString> nullValueStr = SqlString.Null;
                Nullable<SqlString> actualValueStr = "abc";
                cmd.Parameters.AddWithValue("@defaultValue", defaultValue);
                cmd.Parameters.AddWithValue("@nullValue", nullValue);
                cmd.Parameters.AddWithValue("@actualValue", actualValue);
                cmd.Parameters.AddWithValue("@defaultValueStr", defaultValueStr);
                cmd.Parameters.AddWithValue("@nullValueStr", nullValueStr);
                cmd.Parameters.AddWithValue("@actualValueStr", actualValueStr);
                cmd.ExecuteNonQuery();

                conn.Close();
            }
        }

        private static void TestParameterisedSqlWithPositionalParameter()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;

                //cmd.CommandText = @"SELECT @p";
                //cmd.CommandType = CommandType.Text;
                //cmd.Parameters.AddWithValue("@g", "abc");
                //cmd.ExecuteNonQuery();

                cmd.CommandText = @"sp_executesql";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@p", "SELECT @p").ParameterName = string.Empty;
                cmd.Parameters.AddWithValue("@p", "@p varchar").ParameterName = string.Empty;
                cmd.Parameters.AddWithValue("@p", "abc").ParameterName = string.Empty;
                cmd.ExecuteNonQuery();

                conn.Close();
            }
        }

        private static void TestParameterisedSqlInputOutputParameter()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;

                cmd.CommandText = @"select @p=@p+1";
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@p", 1).Direction = ParameterDirection.InputOutput;
                cmd.ExecuteNonQuery();

                conn.Close();
            }
        }

        private static void TestParameterisedStoredProcedureInputOutputParameter()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;

                cmd.CommandText = @"[dbo].[p_Increment]";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@p", 1).Direction = ParameterDirection.InputOutput;
                cmd.ExecuteNonQuery();

                conn.Close();
            }
        }

        private static void TestParameterisedStoredProcedureInputOutputParameterInitialisedToNull()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;

                cmd.CommandText = @"[dbo].[p_Increment]";
                cmd.CommandType = CommandType.StoredProcedure;
                SqlParameter p = new SqlParameter("@p", null);
                p.Size = Int32.MaxValue;
                p.DbType = DbType.Int32;
                p.Direction = ParameterDirection.InputOutput;
                cmd.Parameters.Add(p);
                cmd.ExecuteNonQuery();

                conn.Close();
            }
        }

        private static void TestParameterisedStoredProcedureInputOutputParameterInitialisedToDBNull()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;

                cmd.CommandText = @"[dbo].[p_Increment]";
                cmd.CommandType = CommandType.StoredProcedure;
                SqlParameter p = new SqlParameter("@p", DBNull.Value);
                p.Size = Int32.MaxValue;
                p.DbType = DbType.Int32;
                p.Direction = ParameterDirection.InputOutput;
                cmd.Parameters.Add(p);
                cmd.ExecuteNonQuery();

                conn.Close();
            }
        }

        private static void ParseSample()
        {
            using (TraceFile reader = new TraceFile())
            {
                reader.InitializeAsReader(@"C:\Users\rjarratt\Documents\Projects\VSTSDB\MySampleTrace.trc");
                //reader.InitializeAsReader(@"C:\Users\rjarratt\Documents\Projects\VSTSDB\SampleLoginTrace.trc");
                TraceParser p = new TraceParser(reader);
                TraceRecord traceRecord;
                do
                {
                    traceRecord = p.Parse();
                    if (traceRecord != null)
                    {
                        Console.WriteLine(traceRecord.TextData);
                    }
                }
                while (traceRecord != null);
            }
        }

        private static void ReadTrace()
        {
            using (TraceFile reader = new TraceFile())
            {
                reader.InitializeAsReader(@"C:\Users\rjarratt\Documents\Projects\VSTSDB\MySampleTrace.trc");
                DataTable schema = reader.GetSchemaTable();
                foreach (DataRow r in schema.Rows)
                {
                    Console.WriteLine("{0} {1}", r["ColumnName"], r["DataType"]);
                }
                while (reader.Read())
                {
                    Console.WriteLine("Class: {0} Data: {1}", reader["EventClass"], reader["TextData"]);
                }
            }
        }

        private static void TestNonParameterisedQueries()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                NonParameterisedSql(conn);
                NonParameterisedStoredProcedure(conn);
                conn.Close();
            }
        }

        private static void NonParameterisedSql(SqlConnection conn)
        {
            SqlCommand cmd = null;
            try
            {
                cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"INSERT Scratch (Id,MyData) VALUES (1,'insert1'); /* test comment */ INSERT Scratch (Id,MyData) VALUES (2,'insert2') -- final comment";
                cmd.ExecuteNonQuery();
            }
            finally
            {
                if (cmd != null)
                {
                    cmd.Dispose();
                }
            }
        }

        private static void NonParameterisedStoredProcedure(SqlConnection conn)
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.Connection = conn;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "exec p_InsertScratch 1, 'sp'";
                cmd.ExecuteNonQuery();
            }

        }

        private static void TestParameterisedQueries()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;

                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"INSERT Scratch (Id,MyData) VALUES (@Id,@Data)";
                cmd.Parameters.Clear();
                cmd.Parameters.Add(new SqlParameter("@Id", 1));
                cmd.Parameters.Add(new SqlParameter("@Data", "param"));
                cmd.ExecuteNonQuery();

                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"INSERT Scratch (Id,MyData) VALUES (@Id,@Data); INSERT Scratch (Id,MyData) VALUES (9,'99')";
                cmd.Parameters.Clear();
                cmd.Parameters.Add(new SqlParameter("@Id", 1));
                cmd.Parameters.Add(new SqlParameter("@Data", "param"));
                cmd.ExecuteNonQuery();

                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "[p_InsertScratch]";
                cmd.Parameters.Clear();
                cmd.Parameters.Add(new SqlParameter("@Id", 1));
                cmd.Parameters.Add(new SqlParameter("@Data", "param"));
                cmd.ExecuteNonQuery();

                // Pass parameter as a string
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "[p_InsertScratch]";
                cmd.Parameters.Clear();
                cmd.Parameters.Add(new SqlParameter("@Id", "1"));
                cmd.Parameters.Add(new SqlParameter("@Data", "param"));
                cmd.ExecuteNonQuery();

                // Nullable type
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "PRINT @p1";
                cmd.Parameters.Clear();
                cmd.Parameters.Add(new SqlParameter("@p1", (Nullable<Int64>)1));
                cmd.ExecuteNonQuery();

                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "[p_NoParameters]";
                cmd.Parameters.Clear();
                SqlDataReader r = cmd.ExecuteReader(); // TODO: How to differentiate between calls that return data and calls that do not.
                r.Close();

                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "[p_OutParameter]";
                cmd.Parameters.Clear();
                SqlParameter outParam1 = new SqlParameter("@ap1", 1);
                outParam1.Direction = ParameterDirection.Output;
                cmd.Parameters.Add(outParam1);
                SqlParameter outParam2 = new SqlParameter("@ap2", 1);
                outParam2.Direction = ParameterDirection.Output;
                cmd.Parameters.Add(outParam2);
                cmd.ExecuteNonQuery();

                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "SELECT @p=COUNT(*), @p2=2 FROM Scratch";
                cmd.Parameters.Clear();
                outParam1 = new SqlParameter("@p", SqlDbType.Int, 1);
                outParam1.Direction = ParameterDirection.Output;
                cmd.Parameters.Add(outParam1);
                outParam2 = new SqlParameter("@p2", SqlDbType.Int, 1);
                outParam2.Direction = ParameterDirection.Output;
                cmd.Parameters.Add(outParam2);
                cmd.ExecuteNonQuery();

                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "SELECT @p='abc'";
                cmd.Parameters.Clear();
                outParam1 = new SqlParameter("@p", SqlDbType.VarChar, 10);
                outParam1.Direction = ParameterDirection.Output;
                cmd.Parameters.Add(outParam1);
                cmd.ExecuteNonQuery();

                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "SELECT @p=1.6";
                cmd.Parameters.Clear();
                outParam1 = new SqlParameter("@p", SqlDbType.Decimal, 10);
                outParam1.Direction = ParameterDirection.Output;
                cmd.Parameters.Add(outParam1);
                cmd.ExecuteNonQuery();

                // Anonymous parameter (no name)
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "[p_InsertScratch]";
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@p1", 1).ParameterName = string.Empty;
                cmd.Parameters.AddWithValue("@p1", "param").ParameterName = string.Empty;
                cmd.ExecuteNonQuery();

                conn.Close();
            }

        }

        private static void TestParameterisedQueriesWithPrepare()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;

                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"INSERT Scratch (Id,MyData) VALUES (@Id,@Data); SELECT @out=1";
                cmd.Parameters.Clear();
                SqlParameter id = new SqlParameter();
                id.ParameterName = "@Id";
                id.DbType = DbType.Int32;
                id.Value = 1;
                SqlParameter data = new SqlParameter();
                data.ParameterName = "@data";
                data.DbType = DbType.String;
                data.Value = "param";
                data.Size = 6;
                SqlParameter outParam = new SqlParameter();
                outParam.ParameterName = "@out";
                outParam.DbType = DbType.Int32;
                outParam.Direction = ParameterDirection.Output;
                cmd.Parameters.Add(id);
                cmd.Parameters.Add(data);
                cmd.Parameters.Add(outParam);
                cmd.Prepare();
                cmd.ExecuteNonQuery();
                id.Value = 2;
                data.Value = "param2";
                cmd.ExecuteNonQuery();

                conn.Close();
            }

        }
        private static void TestParameterisedQueriesWithDataTypes()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;

                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"PRINT @p -- Int64";
                cmd.Parameters.Clear();
                cmd.Parameters.Add(new SqlParameter("@p", (Int64)1));
                cmd.ExecuteNonQuery();

                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"PRINT @p -- Int32";
                cmd.Parameters.Clear();
                cmd.Parameters.Add(new SqlParameter("@p", (Int32)1));
                cmd.ExecuteNonQuery();

                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"PRINT @p -- Int16";
                cmd.Parameters.Clear();
                cmd.Parameters.Add(new SqlParameter("@p", (Int16)1));
                cmd.ExecuteNonQuery();

                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"PRINT @p -- Byte";
                cmd.Parameters.Clear();
                cmd.Parameters.Add(new SqlParameter("@p", (Byte)1));
                cmd.ExecuteNonQuery();

                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"PRINT @p -- Boolean";
                cmd.Parameters.Clear();
                cmd.Parameters.Add(new SqlParameter("@p", true));
                cmd.ExecuteNonQuery();

                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"PRINT @p -- Decimal";
                cmd.Parameters.Clear();
                cmd.Parameters.Add(new SqlParameter("@p", 5.1m));
                cmd.ExecuteNonQuery();

                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"PRINT @p -- Double";
                cmd.Parameters.Clear();
                cmd.Parameters.Add(new SqlParameter("@p", (Double)9.9));
                cmd.ExecuteNonQuery();

                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"PRINT @p -- Single";
                cmd.Parameters.Clear();
                cmd.Parameters.Add(new SqlParameter("@p", (Single)8.8));
                cmd.ExecuteNonQuery();

                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"PRINT @p -- DateTime";
                cmd.Parameters.Clear();
                cmd.Parameters.Add(new SqlParameter("@p", new DateTime(2007, 6, 1, 12, 0, 0)));
                cmd.ExecuteNonQuery();

                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"PRINT @p -- String";
                cmd.Parameters.Clear();
                cmd.Parameters.Add(new SqlParameter("@p", "abc"));
                cmd.ExecuteNonQuery();

                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"PRINT @p -- Binary";
                cmd.Parameters.Clear();
                cmd.Parameters.Add(new SqlParameter("@p", new byte[] { 0, 1, 2, 3 }));
                cmd.ExecuteNonQuery();

                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"PRINT @p -- Object";
                cmd.Parameters.Clear();
                cmd.Parameters.Add(new SqlParameter("@p", (Object)1));
                cmd.ExecuteNonQuery();

                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"PRINT @p -- Guid";
                cmd.Parameters.Clear();
                cmd.Parameters.Add(new SqlParameter("@p", Guid.NewGuid()));
                cmd.ExecuteNonQuery();

                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"PRINT @p -- Xml";
                cmd.Parameters.Clear();
                SqlXml xmlValue = new SqlXml(new XmlTextReader(new StringReader("<root><abc>def</abc></root>")));
                cmd.Parameters.Add(new SqlParameter("@p", xmlValue));
                cmd.ExecuteNonQuery();

                conn.Close();
            }

        }


        private static void TestParameterisedStoredProceduresWithDataTypes()
        {
            TestStoredProcedureWithDataType("bigint", (Int64)1);
            TestStoredProcedureWithDataType("int", (Int32)1);
            TestStoredProcedureWithDataType("smallint", (Int16)1);
            TestStoredProcedureWithDataType("tinyint", (Byte)1);
            TestStoredProcedureWithDataType("bit", true);
            TestStoredProcedureWithDataType("decimal(10,2)", 5.1m);
            TestStoredProcedureWithDataType("numeric(5,1)", 5.2m);
            TestStoredProcedureWithDataType("money", 5.3m);
            TestStoredProcedureWithDataType("smallmoney", 5.4m);
            TestStoredProcedureWithDataType("float", (double)6.5E15);
            TestStoredProcedureWithDataType("real", (Single)6.1E10);
            TestStoredProcedureWithDataType("datetime", new DateTime(2007, 6, 18, 12, 0, 0));
            TestStoredProcedureWithDataType("smalldatetime", new DateTime(2007, 6, 18, 12, 0, 0));
            TestStoredProcedureWithDataType("char(10)", "abc");
            TestStoredProcedureWithDataType("nchar(10)", "abc");
            TestStoredProcedureWithDataType("varchar(10)", "abc");
            TestStoredProcedureWithDataType("nvarchar(10)", "abc");
            TestStoredProcedureWithDataType("text", "abc");
            TestStoredProcedureWithDataType("ntext", "abc");
            TestStoredProcedureWithDataType("binary", new byte[] { 0, 1, 2, 3 });
            TestStoredProcedureWithDataType("varbinary", new byte[] { 0, 1, 2, 3 });
            TestStoredProcedureWithDataType("image", new byte[] { 0, 1, 2, 3 });
            TestStoredProcedureWithDataType("timestamp", new byte[] { 0, 1, 2, 3 });
            TestStoredProcedureWithDataType("sql_variant", 1);
            TestStoredProcedureWithDataType("uniqueidentifier", Guid.NewGuid());
        }

        private static void TestStoredProcedureWithDataType(string sqlType, object value)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;

                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"DROP PROCEDURE [p_test]";
                try
                {
                    cmd.ExecuteNonQuery();
                }
                catch (SqlException)
                {
                    // may not exist first time through
                }
                cmd.CommandText = @"CREATE PROCEDURE [p_test] @p " + sqlType + " AS ";
                //cmd.CommandText = @"CREATE PROCEDURE [p_test] @p " + sqlType + " AS DECLARE @t " + sqlType + " SET @t=@p";
                //cmd.CommandText = @"CREATE PROCEDURE [p_test] @p " + sqlType + " AS PRINT @p";
                cmd.ExecuteNonQuery();

                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "[p_test]";
                cmd.Parameters.AddWithValue("@p", value);
                cmd.ExecuteNonQuery();

                //cmd.CommandType = CommandType.StoredProcedure;
                //cmd.CommandText = "[p_test]";
                //cmd.Parameters.Clear();
                //cmd.Parameters.Add("@p", value.ToString());
                //cmd.ExecuteNonQuery();

                conn.Close();
            }
        }

        private static void TestParameterisedStoredProceduresWithDataTypesAndPositionalCall()
        {
            TestStoredProcedureWithDataTypeCallWithPositionalParameter("bigint", (Int64)1);
            TestStoredProcedureWithDataTypeCallWithPositionalParameter("int", (Int32)1);
            TestStoredProcedureWithDataTypeCallWithPositionalParameter("smallint", (Int16)1);
            TestStoredProcedureWithDataTypeCallWithPositionalParameter("tinyint", (Byte)1);
            TestStoredProcedureWithDataTypeCallWithPositionalParameter("bit", true);
            TestStoredProcedureWithDataTypeCallWithPositionalParameter("decimal(10,2)", 5.1m);
            TestStoredProcedureWithDataTypeCallWithPositionalParameter("numeric(5,1)", 5.2m);
            TestStoredProcedureWithDataTypeCallWithPositionalParameter("money", 5.3m);
            TestStoredProcedureWithDataTypeCallWithPositionalParameter("smallmoney", 5.4m);
            TestStoredProcedureWithDataTypeCallWithPositionalParameter("float", (double)6.5E15);
            TestStoredProcedureWithDataTypeCallWithPositionalParameter("real", (Single)6.1E10);
            TestStoredProcedureWithDataTypeCallWithPositionalParameter("datetime", new DateTime(2007, 6, 18, 12, 0, 0));
            TestStoredProcedureWithDataTypeCallWithPositionalParameter("smalldatetime", new DateTime(2007, 6, 18, 12, 0, 0));
            TestStoredProcedureWithDataTypeCallWithPositionalParameter("char(10)", "abc");
            TestStoredProcedureWithDataTypeCallWithPositionalParameter("nchar(10)", "abc");
            TestStoredProcedureWithDataTypeCallWithPositionalParameter("varchar(10)", "abc");
            TestStoredProcedureWithDataTypeCallWithPositionalParameter("nvarchar(10)", "abc");
            TestStoredProcedureWithDataTypeCallWithPositionalParameter("text", "abc");
            TestStoredProcedureWithDataTypeCallWithPositionalParameter("ntext", "abc");
            TestStoredProcedureWithDataTypeCallWithPositionalParameter("binary", new byte[] { 0, 1, 2, 3 });
            TestStoredProcedureWithDataTypeCallWithPositionalParameter("varbinary", new byte[] { 0, 1, 2, 3 });
            TestStoredProcedureWithDataTypeCallWithPositionalParameter("image", new byte[] { 0, 1, 2, 3 });
            TestStoredProcedureWithDataTypeCallWithPositionalParameter("timestamp", new byte[] { 0, 1, 2, 3 });
            TestStoredProcedureWithDataTypeCallWithPositionalParameter("sql_variant", 1);
            TestStoredProcedureWithDataTypeCallWithPositionalParameter("uniqueidentifier", Guid.NewGuid());
        }

        private static void TestStoredProcedureWithDataTypeCallWithPositionalParameter(string sqlType, object value)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;

                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"DROP PROCEDURE [p_test]";
                try
                {
                    cmd.ExecuteNonQuery();
                }
                catch (SqlException)
                {
                    // may not exist first time through
                }
                cmd.CommandText = @"CREATE PROCEDURE [p_test] @p " + sqlType + " AS ";
                //cmd.CommandText = @"CREATE PROCEDURE [p_test] @p " + sqlType + " AS DECLARE @t " + sqlType + " SET @t=@p";
                //cmd.CommandText = @"CREATE PROCEDURE [p_test] @p " + sqlType + " AS PRINT @p";
                cmd.ExecuteNonQuery();

                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "[p_test]";
                cmd.Parameters.AddWithValue("@something", value).ParameterName = string.Empty;
                cmd.ExecuteNonQuery();

                //cmd.CommandType = CommandType.StoredProcedure;
                //cmd.CommandText = "[p_test]";
                //cmd.Parameters.Clear();
                //cmd.Parameters.Add("@p", value.ToString());
                //cmd.ExecuteNonQuery();

                conn.Close();
            }
        }

        private static void TestParameterisedStoredProceduresWithDataTypesOutput()
        {

            TestStoredProcedureWithDataTypeOutput(DbType.Int64, "bigint", "1", 0);
            TestStoredProcedureWithDataTypeOutput(DbType.Decimal, "decimal(10,2)", "5.1", 0);
            TestStoredProcedureWithDataTypeOutput(DbType.Double, "float", "6.5E15", 0);
            TestStoredProcedureWithDataTypeOutput(DbType.DateTime, "datetime", "'Jul  6 2007  8:25AM'", 0);
            TestStoredProcedureWithDataTypeOutput(DbType.String, "char(10)", "'abc'", 0);
            TestStoredProcedureWithDataTypeOutput(DbType.String, "varchar(10)", "'abc'", 0);
            TestStoredProcedureWithDataTypeOutput(DbType.String, "text", "'abc'", 0);
            TestStoredProcedureWithDataTypeOutput(DbType.Binary, "binary", "0x000102030405", 0);
            TestStoredProcedureWithDataTypeOutput(DbType.Binary, "varbinary", "0x000102030405", 0);
            TestStoredProcedureWithDataTypeOutput(DbType.Guid, "uniqueidentifier", "'" + Guid.NewGuid().ToString() + "'", 0);
        }

        private static void TestParameterisedSqlWithDataTypesOutput()
        {

            TestSqlWithDataTypeOutput(DbType.Int64, "bigint", "1", 0, 2);
            TestSqlWithDataTypeOutput(DbType.Decimal, "decimal(10,2)", "5.1", 0, 99.9);
            TestSqlWithDataTypeOutput(DbType.Double, "float", "6.5E15", 0, 9.0E10);
            TestSqlWithDataTypeOutput(DbType.DateTime, "datetime", "'Jul  6 2007  8:25AM'", 0, DateTime.Now);
            TestSqlWithDataTypeOutput(DbType.String, "char(10)", "'abc'", 0, "def");
            TestSqlWithDataTypeOutput(DbType.String, "varchar(10)", "'abc'", 0, "def");
            TestSqlWithDataTypeOutput(DbType.String, "text", "'abc'", 0, "def");
            TestSqlWithDataTypeOutput(DbType.Binary, "binary", "0x000102030405", 0, new byte[] { 0xff, 0xff, 0xff, 0xff });
            TestSqlWithDataTypeOutput(DbType.Binary, "varbinary", "0x000102030405", 0, new byte[] { 0xff, 0xff, 0xff, 0xff });
            TestSqlWithDataTypeOutput(DbType.Guid, "uniqueidentifier", "'" + Guid.NewGuid().ToString() + "'", 0, Guid.NewGuid());
        }

        private static void TestParameterisedSqlWithDataTypesInputOutput()
        {

            TestSqlWithDataTypeInputOutput(DbType.Int64, "bigint", "1", 0, 2);
            TestSqlWithDataTypeInputOutput(DbType.Decimal, "decimal(10,2)", "5.1", 0, 99.9);
            TestSqlWithDataTypeInputOutput(DbType.Double, "float", "6.5E15", 0, 9.0E10);
            TestSqlWithDataTypeInputOutput(DbType.DateTime, "datetime", "'Jul  6 2007  8:25AM'", 0, DateTime.Now);
            TestSqlWithDataTypeInputOutput(DbType.String, "char(10)", "'abc'", 0, "def");
            TestSqlWithDataTypeInputOutput(DbType.String, "varchar(10)", "'abc'", 0, "def");
            TestSqlWithDataTypeInputOutput(DbType.String, "text", "'abc'", 0, "def");
            TestSqlWithDataTypeInputOutput(DbType.Binary, "binary", "0x000102030405", 0, new byte[] { 0xff, 0xff, 0xff, 0xff });
            TestSqlWithDataTypeInputOutput(DbType.Binary, "varbinary", "0x000102030405", 0, new byte[] { 0xff, 0xff, 0xff, 0xff });
            TestSqlWithDataTypeInputOutput(DbType.Guid, "uniqueidentifier", "'" + Guid.NewGuid().ToString() + "'", 0, Guid.NewGuid());
        }

        private static void TestStoredProcedureWithDataTypeOutput(DbType dbType, string sqlType, object value, int size)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;

                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"DROP PROCEDURE [p_test]";
                try
                {
                    cmd.ExecuteNonQuery();
                }
                catch (SqlException)
                {
                    // may not exist first time through
                }
                cmd.CommandText = @"CREATE PROCEDURE [p_test] @p " + sqlType + " OUTPUT AS SELECT @p=" + value.ToString();
                cmd.ExecuteNonQuery();

                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "[p_test]";
                SqlParameter p = new SqlParameter();
                p.ParameterName = "@p";
                p.DbType = dbType;
                p.Direction = ParameterDirection.Output;
                p.Size = int.MaxValue;
                //p.Value = String.Empty;
                cmd.Parameters.Add(p);
                cmd.ExecuteNonQuery();

                conn.Close();
            }
        }

        private static void TestSqlWithDataTypeOutput(DbType dbType, string sqlType, object value, int size, object initialValue)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;

                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "SELECT @p=" + value.ToString();
                SqlParameter p = new SqlParameter();
                p.ParameterName = "@p";
                p.DbType = dbType;
                p.Direction = ParameterDirection.Output;
                p.Size = int.MaxValue;
                cmd.Parameters.Add(p);
                cmd.ExecuteNonQuery();

                conn.Close();
            }
        }

        private static void TestSqlWithDataTypeInputOutput(DbType dbType, string sqlType, object value, int size, object initialValue)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;

                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "SELECT @p=" + value.ToString();
                SqlParameter p = new SqlParameter();
                p.ParameterName = "@p";
                p.DbType = dbType;
                p.Direction = ParameterDirection.InputOutput;
                p.Size = int.MaxValue;
                p.Value = initialValue;
                //p.Value = String.Empty;
                cmd.Parameters.Add(p);
                cmd.ExecuteNonQuery();

                conn.Close();
            }
        }

        private static void TestAddAComment()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;

                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"DROP PROCEDURE [dbo].[AddAComment]";
                try
                {
                    cmd.ExecuteNonQuery();
                }
                catch (SqlException)
                {
                    // may not exist first time through
                }

                cmd.CommandText = @"CREATE PROCEDURE [dbo].[AddAComment] @p varchar AS SET NOCOUNT ON";
                cmd.ExecuteNonQuery();

                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "[dbo].[AddAComment]";
                SqlParameter p = new SqlParameter();
                p.ParameterName = "@p";
                p.DbType = DbType.String;
                p.Value = "Test comment";
                cmd.Parameters.Add(p);
                cmd.ExecuteNonQuery();

                conn.Close();
            }
        }


    }
}
