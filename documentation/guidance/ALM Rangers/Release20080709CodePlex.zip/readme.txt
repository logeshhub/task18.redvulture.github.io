Release of 29th January 2008
============================

Fixes
-----

Now copes with mixed positional and named parameters passed to text and stored procedure queries.

Other Notes
-----------

Input/Output values not supported.

Positional parameters passed to text queries (as opposed to stored procs) make a naming assumption

Build includes the [dbo].[AddAComment] hack, this is not part of the checked in code

Release of 20th May 2008
========================

Fixes
-----

Generalised the support of custom code generation so that the [dbo].[AddAComment] hack can be removed.

Other Notes
-----------

Input/Output values not supported.

Positional parameters passed to text queries (as opposed to stored procs) make a naming assumption

The [dbo].[AddAComment] hack has been removed and provided as a sample





Release of 9th July 2008
========================

Fixes
-----

The profile replaces some calls with comments for security reasons, like calls to sp_setapprole for example. These are now
handled by putting the comment straight into the scenario method.

Better support for special characters inside delimited identifiers (i.e. inside square brackets)

Enhancements
------------

Input/Output parameters now supported.

Null handling significantly altered. Can now represent missing value (set @p=default) and NULL separately. This has
necessitated changing to use the SqlTypes for representing parameters.


Other Notes
-----------

Profiler trace requirements have changed and now requires the Audit Login and Audit Logout events, the template has been
updated accordingly.This is in preparation for processing multiple connections.

Parameters now generated in the order of appearance, rather than by parameter direction. This will invalidate any
old customisation files.