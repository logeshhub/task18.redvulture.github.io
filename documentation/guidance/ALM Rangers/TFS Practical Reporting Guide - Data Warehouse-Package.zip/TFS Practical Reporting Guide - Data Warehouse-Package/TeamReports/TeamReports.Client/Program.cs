﻿//------------------------------------------------------------------------------
// <copyright file="Program.cs" company="Microsoft">
// Copyright © Microsoft Corporation. All Rights Reserved.
// This code released under the terms of the Microsoft Public License (MS-PL, http://opensource.org/licenses/ms-pl.html.)
// This is sample code only, do not use in production environments 
// </copyright>
//------------------------------------------------------------------------------
namespace Microsoft.ALMRangers.VsarReportGuide.TeamReportsService.Client
{
    using System;
    using TeamReports;

    public static class Program
    {
        /// <summary>
        /// The Main method 
        /// </summary>
        /// <param name="args">Command line arguments</param>
        public static void Main(string[] args)
        {
            using (var client = new BuildReportsClient())
            {
                var buildSteps = client.GetBuildStepDurationReport("*TeamProjectCollectionUri", "TeamProjectName", "BuildDefinitionName", BuildStepDurationReportOption.All);

                foreach (var step in buildSteps)
                {
                    Console.WriteLine("Build Step {0} - Duration {1}", step.Name, step.Duration);
                }
            }
        }
    }
}
