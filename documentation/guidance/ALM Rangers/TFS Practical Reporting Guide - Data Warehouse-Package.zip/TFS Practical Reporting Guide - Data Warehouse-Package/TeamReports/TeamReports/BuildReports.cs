﻿//------------------------------------------------------------------------------
// <copyright file="BuildReports.cs" company="Microsoft">
// Copyright © Microsoft Corporation. All Rights Reserved.
// This code released under the terms of the Microsoft Public License (MS-PL, http://opensource.org/licenses/ms-pl.html.)
// This is sample code only, do not use in production environments 
// </copyright>
//------------------------------------------------------------------------------
namespace Microsoft.ALMRangers.VsarReportGuide.TeamReports
{
    using System;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.Linq;
    using TeamFoundation.Build.Client;
    using TeamFoundation.Build.Common;
    using TeamFoundation.Client;   

    /// <summary>
    /// The BuildReports class provides functionality for all Build Reports created from Team Foundation Server's service
    /// </summary>    
    public class BuildReports : IBuildReports
    {
        /// <summary>
        /// Returns the Build Step Duration report for a given build
        /// </summary>
        /// <param name="projectCollectionUri">The Project collection Uri</param>
        /// <param name="teamProjectName">The Team Project Name</param>
        /// <param name="buildDefinitionName">The build definition name for the build for which the report should return the build duration. Only the latest build is extracted.</param>
        /// <param name="reportOption">An enumeration that determines which steps should be returned</param>
        /// <returns>A list of build steps with their respective duration</returns>
        public IEnumerable<BuildStep> GetBuildStepDurationReport(string projectCollectionUri, string teamProjectName, string buildDefinitionName, BuildStepDurationReportOption reportOption)
        {
            ValidateBuildStepDurationParameters(projectCollectionUri, teamProjectName, buildDefinitionName);

            var buildCollections = new Collection<BuildStep>();
            var teamCollection = GetTeamCollection(projectCollectionUri);
            
            var buildserver = teamCollection.GetService<IBuildServer>();
            var buildDefinitionSpec = buildserver.CreateBuildDefinitionSpec(teamProjectName, buildDefinitionName);

            var buildDetails = buildserver.QueryBuilds(buildDefinitionSpec);
            if (buildDetails != null && buildDetails.Count() > 0)
            {
                var build = buildDetails.OrderByDescending(s => s.StartTime).FirstOrDefault();
                if (build != null)
                {
                    this.GetBuildAgentName(build);
                    build.Information
                        .GetSortedNodes(new BuildInformationComparer())
                        .ForEach(item => AddBuildInformation(buildCollections, item));                                    
                }
            }

            return buildCollections;
        }

        private static void ValidateBuildStepDurationParameters(string projectCollectionUri, string teamProjectName, string buildDefinitionName)
        {
            if (string.IsNullOrWhiteSpace(projectCollectionUri))
            {
                throw new ArgumentNullException("projectCollectionUri");
            }

            if (string.IsNullOrWhiteSpace(teamProjectName))
            {
                throw new ArgumentNullException("teamProjectName");
            }

            if (string.IsNullOrWhiteSpace(buildDefinitionName))
            {
                throw new ArgumentNullException("buildDefinitionName");
            }

            if (!Uri.IsWellFormedUriString(projectCollectionUri, UriKind.Absolute))
            {
                throw new ArgumentException("Malformed Uri", "projectCollectionUri");
            }
        }
        
        private static TfsTeamProjectCollection GetTeamCollection(string projectCollectionUri)
        {
            var teamCollection = TfsTeamProjectCollectionFactory.GetTeamProjectCollection(new Uri(projectCollectionUri, UriKind.Absolute));
            teamCollection.EnsureAuthenticated();
            return teamCollection;
        }

        private static void AddBuildInformation(Collection<BuildStep> collection, IBuildInformationNode buildInformation)
        {   
            if (buildInformation.Fields.ContainsKey("StartTime") && buildInformation.Fields.ContainsKey("FinishTime") && buildInformation.Fields.ContainsKey("DisplayText"))
            {
                collection.Add(new BuildStep
                {
                        Name = buildInformation.Fields["DisplayText"],
                        StartTime = DateTime.Parse(buildInformation.Fields["StartTime"]),
                        EndTime = DateTime.Parse(buildInformation.Fields["FinishTime"]),
                        Duration = DateTime.Parse(buildInformation.Fields["FinishTime"]) - DateTime.Parse(buildInformation.Fields["StartTime"])                    
                    });
            }                
        }

        private string GetBuildAgentName(IBuildDetail build)
        {   
            var buildInformationNodes = build.Information.GetNodesByType("AgentScopeActivityTracking", true);
            if (buildInformationNodes != null)
            {
                var node = buildInformationNodes.Find(s => s.Fields.ContainsKey(InformationFields.ReservedAgentName));                
                return node != null ? node.Fields[InformationFields.ReservedAgentName] : string.Empty;
            }

            return string.Empty;
        }

        internal class BuildInformationComparer : IComparer<IBuildInformationNode>
        {
            public int Compare(IBuildInformationNode itemToCompare, IBuildInformationNode itemToCompareWith)
            {
                if (itemToCompare.Id > itemToCompareWith.Id)
                {
                    return 1;
                }
                
                if (itemToCompare.Id == itemToCompareWith.Id)
                {
                    return 0;
                }

                return -1;
            }
        }
    }
}
