﻿//------------------------------------------------------------------------------
// <copyright file="BuildStep.cs" company="Microsoft">
// Copyright © Microsoft Corporation. All Rights Reserved.
// This code released under the terms of the Microsoft Public License (MS-PL, http://opensource.org/licenses/ms-pl.html.)
// This is sample code only, do not use in production environments 
// </copyright>
//------------------------------------------------------------------------------
namespace Microsoft.ALMRangers.VsarReportGuide.TeamReports
{
    using System;
    using System.Runtime.Serialization;

    /// <summary>
    /// The BuildStep class encapsulates a single Build Step in a build report
    /// </summary>
    [DataContract]
    public class BuildStep
    {
        /// <summary>
        /// Gets or sets the name of the Build Step
        /// </summary>
        [DataMember]
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the Start Time of the Build Step
        /// </summary>
        [DataMember]
        public DateTime StartTime { get; set; }

        /// <summary>
        /// Gets or sets the End Time of the Build Step
        /// </summary>
        [DataMember]
        public DateTime? EndTime { get; set; }

        /// <summary>
        /// Gets or sets the Duration of the build Step
        /// </summary>
        [DataMember]
        public TimeSpan? Duration { get; set; }
    }
}
