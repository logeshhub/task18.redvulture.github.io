﻿//------------------------------------------------------------------------------
// <copyright file="BuildStepDurationReportOption.cs" company="Microsoft">
// Copyright © Microsoft Corporation. All Rights Reserved.
// This code released under the terms of the Microsoft Public License (MS-PL, http://opensource.org/licenses/ms-pl.html.)
// This is sample code only, do not use in production environments 
// </copyright>
//------------------------------------------------------------------------------
namespace Microsoft.ALMRangers.VsarReportGuide.TeamReports
{
    using System.Runtime.Serialization;

    /// <summary>
    /// Enumeration option for Build Steps Duration report. Indicates which build steps should be returned
    /// </summary>
    [DataContract]    
    public enum BuildStepDurationReportOption
    {
        /// <summary>
        /// Duration of all build steps would be returned
        /// </summary>
        [EnumMember]
        All,

        /// <summary>
        /// Duration of the ten slowest build steps would be returned
        /// </summary>
        [EnumMember]
        SlowestTenSteps,

        /// <summary>
        /// Duration of the ten fastest build steps would be returned
        /// </summary>
        [EnumMember]
        FastestTenSteps        
    }
}
