﻿//------------------------------------------------------------------------------
// <copyright file="IBuildReports.cs" company="Microsoft">
// Copyright © Microsoft Corporation. All Rights Reserved.
// This code released under the terms of the Microsoft Public License (MS-PL, http://opensource.org/licenses/ms-pl.html.)
// This is sample code only, do not use in production environments 
// </copyright>
//------------------------------------------------------------------------------
namespace Microsoft.ALMRangers.VsarReportGuide.TeamReports
{
    using System.Collections.Generic;
    using System.ServiceModel;

    /// <summary>
    /// The IBuildReports service interface provide methods for a the various build reports created from Team Foundation Server's service
    /// </summary>
    [ServiceContract]
    public interface IBuildReports
    {
        /// <summary>
        /// Returns the Build Step Duration report for a given build
        /// </summary>
        /// <param name="projectCollectionUri">The Project collection Uri</param>
        /// <param name="teamProjectName">The Team Project Name</param>
        /// <param name="buildDefinitionName">The build definition name for the build for which the report should return the build duration. Only the latest build is extracted.</param>
        /// <param name="reportOption">An enumeration  that determines which steps should be returned</param>
        /// <returns>A list of build steps with their respective duration</returns>
        [OperationContract]
        IEnumerable<BuildStep> GetBuildStepDurationReport(string projectCollectionUri, string teamProjectName, string buildDefinitionName, BuildStepDurationReportOption reportOption);
    }
}
