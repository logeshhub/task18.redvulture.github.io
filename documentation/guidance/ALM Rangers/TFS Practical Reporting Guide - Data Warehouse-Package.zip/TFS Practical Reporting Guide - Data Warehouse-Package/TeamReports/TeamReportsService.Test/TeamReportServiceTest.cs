﻿//------------------------------------------------------------------------------
// <copyright file="TeamReportServiceTest.cs" company="Microsoft">
// Copyright © Microsoft Corporation. All Rights Reserved.
// This code released under the terms of the Microsoft Public License (MS-PL, http://opensource.org/licenses/ms-pl.html.)
// This is sample code only, do not use in production environments 
// </copyright>
//------------------------------------------------------------------------------
namespace Microsoft.ALMRangers.VsarReportGuide.TeamReportsService.Test
{
    using System.Configuration;
    using System.ServiceModel;
    using TeamReports;
    using VisualStudio.TestTools.UnitTesting;

    /// <summary>
    /// Unit Test class for Team Report Services
    /// </summary>
    [TestClass]
    public class TeamReportServiceTest
    {
        [TestMethod]
        [TestCategory("IntegrationTest")]
        public void CallGetBuildStepDurationReportService()
        {
            string serviceUrl = ConfigurationManager.AppSettings["BuildReportsServiceUrl"];
            var binding = new BasicHttpBinding();
            var endpointAddress = new EndpointAddress(serviceUrl);
            var factory = new ChannelFactory<IBuildReports>(binding, endpointAddress);            
            IBuildReports buildReports = factory.CreateChannel();

            var result = buildReports.GetBuildStepDurationReport(@"https://vstf-eu-dub-01.partners.extranet.microsoft.com:8443/tfs/MCSISD", "NW7DaySwitch", "Rel_3.2.0", BuildStepDurationReportOption.SlowestTenSteps);
            Assert.IsNotNull(result);
        }
        
        [TestMethod]        
        public void CallGetBuildStepDurationReportMethod()
        {
            IBuildReports buildReports = new BuildReports();
            var result = buildReports.GetBuildStepDurationReport(@"https://vstf-eu-dub-01.partners.extranet.microsoft.com:8443/tfs/MCSISD", "NW7DaySwitch", "Rel_3.2.0", BuildStepDurationReportOption.SlowestTenSteps);
            Assert.IsNotNull(result);
        }
    }
}
