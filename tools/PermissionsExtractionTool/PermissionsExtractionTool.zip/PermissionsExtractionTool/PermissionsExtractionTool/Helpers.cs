﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="Helpers.cs" company="Microsoft Corporation">
//   Microsoft Visual Studio ALM Rangers
// </copyright>
// <summary>
//   The helpers.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace Microsoft.ALMRangers.PermissionsExtractionTool
{
    using System.Collections.Generic;
    using System.Linq;

    using TeamFoundation;
    using TeamFoundation.Build.Common;
    using TeamFoundation.Server;
    using TeamFoundation.VersionControl.Common;

    /// <summary>
    /// The helpers.
    /// </summary>
    public static class Helpers
    {
        #region Static Fields

        /// <summary>
        /// The permissions.
        /// </summary>
        private static readonly List<Permission> Permissions = new List<Permission>
                                                                   {
                                                                       // Team Project
                                                                       new Permission(PermissionScope.TeamProject, "Create test runs", "PublishTestResults", PermissionActionIdConstants.PublishTestResults, AuthorizationProjectPermissions.PublishTestResults, string.Empty), 
                                                                       new Permission(PermissionScope.TeamProject, "Delete team project", "Delete", PermissionActionIdConstants.Delete, AuthorizationProjectPermissions.Delete, string.Empty), 
                                                                       new Permission(PermissionScope.TeamProject, "Delete test runs", "DeleteTestResults", PermissionActionIdConstants.DeleteTestResults, AuthorizationProjectPermissions.DeleteTestResults, string.Empty), 
                                                                       new Permission(PermissionScope.TeamProject, "Edit project-level information", "GenericWrite", PermissionActionIdConstants.GenericWrite, AuthorizationProjectPermissions.GenericWrite, string.Empty), 
                                                                       new Permission(PermissionScope.TeamProject, "Manage test configurations", "ManageTestConfigurations", PermissionActionIdConstants.ManageTestConfigurations, AuthorizationProjectPermissions.ManageTestConfigurations, string.Empty), 
                                                                       new Permission(PermissionScope.TeamProject, "Manage test environments", "ManageTestEnvironments", PermissionActionIdConstants.ManageTestEnvironments, AuthorizationProjectPermissions.ManageTestEnvironments, string.Empty), 
                                                                       new Permission(PermissionScope.TeamProject, "View project-level information", "GenericRead", PermissionActionIdConstants.GenericRead, AuthorizationProjectPermissions.GenericRead, string.Empty), 
                                                                       new Permission(PermissionScope.TeamProject, "View test runs", "ViewTestResults", PermissionActionIdConstants.ViewTestResults, AuthorizationProjectPermissions.ViewTestResults, string.Empty), 

                                                                       //// Team Build
                                                                       new Permission(PermissionScope.TeamBuild, "Administer build permissions", "AdministerBuildPermissions", PermissionStringConstants.AdministerBuildPermissions, BuildPermissions.AdministerBuildPermissions, string.Empty), 
                                                                       new Permission(PermissionScope.TeamBuild, "Delete build definition", "DeleteBuildDefinition", PermissionStringConstants.DeleteBuildDefinition, BuildPermissions.DeleteBuildDefinition, string.Empty), 
                                                                       new Permission(PermissionScope.TeamBuild, "Delete builds", "DeleteBuilds", PermissionStringConstants.DeleteBuilds, BuildPermissions.DeleteBuilds, string.Empty), 
                                                                       new Permission(PermissionScope.TeamBuild, "Destroy builds", "DestroyBuilds", PermissionStringConstants.DestroyBuilds, BuildPermissions.DestroyBuilds, string.Empty), 
                                                                       new Permission(PermissionScope.TeamBuild, "Edit build definition", "EditBuildDefinition", PermissionStringConstants.EditBuildDefinition, BuildPermissions.EditBuildDefinition, string.Empty), 
                                                                       new Permission(PermissionScope.TeamBuild, "Edit build quality", "EditBuildQuality", PermissionStringConstants.EditBuildQuality, BuildPermissions.EditBuildQuality, string.Empty), 
                                                                       new Permission(PermissionScope.TeamBuild, "Manage build qualities", "ManageBuildQualities", PermissionStringConstants.ManageBuildQualities, BuildPermissions.ManageBuildQualities, string.Empty), 
                                                                       new Permission(PermissionScope.TeamBuild, "Manage build queue", "ManageBuildQueue", PermissionStringConstants.ManageBuildQueue, BuildPermissions.ManageBuildQueue, string.Empty), 
                                                                       new Permission(PermissionScope.TeamBuild, "Override check-in validation by build", "OverrideBuildCheckInValidation", PermissionStringConstants.OverrideBuildCheckInValidation, BuildPermissions.OverrideBuildCheckInValidation, string.Empty), 
                                                                       new Permission(PermissionScope.TeamBuild, "Queue builds", "QueueBuilds", PermissionStringConstants.QueueBuilds, BuildPermissions.QueueBuilds, string.Empty), 
                                                                       new Permission(PermissionScope.TeamBuild, "Retain indefinitely", "RetainIndefinitely", PermissionStringConstants.RetainIndefinitely, BuildPermissions.RetainIndefinitely, string.Empty), 
                                                                       new Permission(PermissionScope.TeamBuild, "Stop builds", "StopBuilds", PermissionStringConstants.StopBuilds, BuildPermissions.StopBuilds, string.Empty), 
                                                                       new Permission(PermissionScope.TeamBuild, "Update build information", "UpdateBuildInformation", PermissionStringConstants.UpdateBuildInformation, BuildPermissions.UpdateBuildInformation, string.Empty), 
                                                                       new Permission(PermissionScope.TeamBuild, "View build definition", "ViewBuildDefinition", PermissionStringConstants.ViewBuildDefinition, BuildPermissions.ViewBuildDefinition, string.Empty), 
                                                                       new Permission(PermissionScope.TeamBuild, "View builds", "ViewBuilds", PermissionStringConstants.ViewBuilds, BuildPermissions.ViewBuilds, string.Empty), 

                                                                       // Work Item Areas
                                                                       new Permission(PermissionScope.WorkItemAreas, "Create child nodes", "CreateChildren", PermissionActionIdConstants.CreateChildren, AuthorizationCssNodePermissions.CreateChildren, string.Empty), 
                                                                       new Permission(PermissionScope.WorkItemAreas, "Delete this node", "Delete", PermissionActionIdConstants.Delete, AuthorizationCssNodePermissions.Delete, string.Empty), 
                                                                       new Permission(PermissionScope.WorkItemAreas, "Edit this node", "GenericWrite", PermissionActionIdConstants.GenericWrite, AuthorizationCssNodePermissions.GenericWrite, string.Empty), 
                                                                       new Permission(PermissionScope.WorkItemAreas, "Edit work items in this node", "WorkItemWrite", PermissionActionIdConstants.WorkItemWrite, AuthorizationCssNodePermissions.WorkItemWrite, string.Empty), 
                                                                       new Permission(PermissionScope.WorkItemAreas, "Manage test plans", "ManageTestPlans", PermissionActionIdConstants.ManageTestPlans, AuthorizationCssNodePermissions.ManageTestPlans, string.Empty), 
                                                                       new Permission(PermissionScope.WorkItemAreas, "View permissions for this node", "GenericRead", PermissionActionIdConstants.GenericRead, AuthorizationCssNodePermissions.GenericRead, string.Empty), 
                                                                       new Permission(PermissionScope.WorkItemAreas, "View work items in this node", "WorkItemRead", PermissionActionIdConstants.WorkItemRead, AuthorizationCssNodePermissions.WorkItemRead, string.Empty), 

                                                                       // Work Item Iterations
                                                                       new Permission(PermissionScope.WorkItemIterations, "Create child nodes", "CreateChildren", PermissionActionIdConstants.CreateChildren, AuthorizationIterationNodePermissions.CreateChildren, string.Empty), 
                                                                       new Permission(PermissionScope.WorkItemIterations, "Delete this node", "Delete", PermissionActionIdConstants.Delete, AuthorizationIterationNodePermissions.Delete, string.Empty), 
                                                                       new Permission(PermissionScope.WorkItemIterations, "Edit this node", "GenericWrite", PermissionActionIdConstants.GenericWrite, AuthorizationIterationNodePermissions.GenericWrite, string.Empty), 
                                                                       new Permission(PermissionScope.WorkItemIterations, "View permissions for this node", "GenericRead", PermissionActionIdConstants.GenericRead, AuthorizationIterationNodePermissions.GenericRead, string.Empty), 

                                                                       // Source Control
                                                                       new Permission(PermissionScope.SourceControl, "Administer labels", "LabelOther", VersionedItemPermissions.LabelOther.ToString(), (int)VersionedItemPermissions.LabelOther, string.Empty), 
                                                                       new Permission(PermissionScope.SourceControl, "Check in", "Checkin", VersionedItemPermissions.Checkin.ToString(), (int)VersionedItemPermissions.Checkin, string.Empty), 
                                                                       new Permission(PermissionScope.SourceControl, "Check in other users' changes", "CheckinOther", VersionedItemPermissions.CheckinOther.ToString(), (int)VersionedItemPermissions.CheckinOther, string.Empty), 
                                                                       new Permission(PermissionScope.SourceControl, "Check out", "PendChange", VersionedItemPermissions.PendChange.ToString(), (int)VersionedItemPermissions.PendChange, string.Empty), 
                                                                       new Permission(PermissionScope.SourceControl, "Label", "Label", VersionedItemPermissions.Label.ToString(), (int)VersionedItemPermissions.Label, string.Empty),                                                                        
                                                                       new Permission(PermissionScope.SourceControl, "Lock", "Lock", VersionedItemPermissions.Lock.ToString(), (int)VersionedItemPermissions.Lock, string.Empty), 
                                                                       new Permission(PermissionScope.SourceControl, "Manage branch", "ManageBranch", VersionedItemPermissions.ManageBranch.ToString(), (int)VersionedItemPermissions.ManageBranch, string.Empty), 
                                                                       new Permission(PermissionScope.SourceControl, "Manage permissions", "AdminProjectRights", VersionedItemPermissions.AdminProjectRights.ToString(), (int)VersionedItemPermissions.AdminProjectRights, string.Empty), 
                                                                       new Permission(PermissionScope.SourceControl, "Merge", "Merge", VersionedItemPermissions.Merge.ToString(), (int)VersionedItemPermissions.Merge, string.Empty), 
                                                                       new Permission(PermissionScope.SourceControl, "Read", "Read", VersionedItemPermissions.Read.ToString(), (int)VersionedItemPermissions.Read, string.Empty), 
                                                                       new Permission(PermissionScope.SourceControl, "Revise other users' changes", "ReviseOther", VersionedItemPermissions.ReviseOther.ToString(), (int)VersionedItemPermissions.ReviseOther, string.Empty), 
                                                                       new Permission(PermissionScope.SourceControl, "Undo other users' changes", "UndoOther", VersionedItemPermissions.UndoOther.ToString(), (int)VersionedItemPermissions.UndoOther, string.Empty), 
                                                                       new Permission(PermissionScope.SourceControl, "Unlock other users' changes", "UnlockOther", VersionedItemPermissions.UnlockOther.ToString(), (int)VersionedItemPermissions.UnlockOther, string.Empty), 
                                                                   };

       #endregion

        #region Public Methods and Operators
        /// <summary>
        /// The get action details by name.
        /// </summary>
        /// <param name="actionNames">
        /// The action names.
        /// </param>
        /// <param name="permissionState">
        /// The permission state.
        /// </param>
        /// <param name="scope">
        /// The scope.
        /// </param>
        /// <returns>
        /// The <see cref="IEnumerable"/>.
        /// </returns>
        public static IEnumerable<Permission> GetActionDetailsByName(
            string actionNames, 
            string permissionState, 
            PermissionScope scope)
        {
            string[] actions = actionNames.Split(',');
            return (from item in actions
                    select (from constPermission in Permissions
                            where constPermission.InternalName == item.TrimStart() && constPermission.Scope == scope
                            select constPermission).FirstOrDefault()
                    into selectedPermission
                    where selectedPermission != null
                    select
                        new Permission(
                        scope, 
                        selectedPermission.DisplayName, 
                        selectedPermission.InternalName, 
                        selectedPermission.PermissionConstant, 
                        selectedPermission.PermissionId, 
                        permissionState)).ToList();
        }

        #endregion
    }
}